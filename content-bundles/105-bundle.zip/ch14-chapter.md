:chapter XIV | Working Capital and Short-Term Financing
:mood A practical question about working capital and short-term financing
:desc This chapter introduces working capital and short-term financing for a first-year reader. It builds each idea from a familiar business problem, defines the terms before using them, and connects the calculations to decisions.
:plate ch14-plate.svg | a warehouse with sacks, crates and a weighing machine watched by a clerk, 1880s
:fig Working Capital and Short-Term Financing figure 1 | ch14-fig01.svg
:fig Working Capital and Short-Term Financing figure 2 | ch14-fig02.svg
## 14.1 Working capital and how to finance it
> This section builds the idea of working capital and how to finance it before moving to application.

The purpose here is to make working capital and how to finance it concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Working capital | The money a business has tied up in everyday trading: cash, stock and money owed to it..
> The term working capital gives the chapter a precise name for this part of the problem.

In this chapter, **Working capital** means The money a business has tied up in everyday trading: cash, stock and money owed to it. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Net working capital | Current assets minus current liabilities; what remains for trading after short debts are paid..
> The term net working capital gives the chapter a precise name for this part of the problem.

In this chapter, **Net working capital** means Current assets minus current liabilities; what remains for trading after short debts are paid. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Matching principle | Pay for short-lived needs with short-term money and for lasting needs with long-term money..
> The term matching principle gives the chapter a precise name for this part of the problem.

In this chapter, **Matching principle** means Pay for short-lived needs with short-term money and for lasting needs with long-term money. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Short-term financing | Money borrowed to be repaid within one year..
> The term short-term financing gives the chapter a precise name for this part of the problem.

In this chapter, **Short-term financing** means Money borrowed to be repaid within one year. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Intermediate-term financing | Money borrowed to be repaid in more than one year but not more than about five..
> The term intermediate-term financing gives the chapter a precise name for this part of the problem.

In this chapter, **Intermediate-term financing** means Money borrowed to be repaid in more than one year but not more than about five. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in working capital and how to finance it is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For working capital and how to finance it, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 14.2 Sources of short-term finance
> This section builds the idea of sources of short-term finance before moving to application.

The purpose here is to make sources of short-term finance concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Long-term financing | Money raised for more than about five years, or with no fixed repayment date..
> The term long-term financing gives the chapter a precise name for this part of the problem.

In this chapter, **Long-term financing** means Money raised for more than about five years, or with no fixed repayment date. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Trade credit | Credit from a supplier who lets a buyer pay some days after delivery..
> The term trade credit gives the chapter a precise name for this part of the problem.

In this chapter, **Trade credit** means Credit from a supplier who lets a buyer pay some days after delivery. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Cash discount | A price cut a supplier gives for paying early, such as 2% off if paid within 10 days..
> The term cash discount gives the chapter a precise name for this part of the problem.

In this chapter, **Cash discount** means A price cut a supplier gives for paying early, such as 2% off if paid within 10 days. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Inventory | The goods a business holds for sale, such as the books on a shop's shelves..
> The term inventory gives the chapter a precise name for this part of the problem.

In this chapter, **Inventory** means The goods a business holds for sale, such as the books on a shop's shelves. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Accounts receivable | Money that customers owe a business for goods already delivered..
> The term accounts receivable gives the chapter a precise name for this part of the problem.

In this chapter, **Accounts receivable** means Money that customers owe a business for goods already delivered. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in sources of short-term finance is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For sources of short-term finance, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 14.3 Cycles, float and estimating needs
> This section builds the idea of cycles, float and estimating needs before moving to application.

The purpose here is to make cycles, float and estimating needs concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Accounts payable | Money a business owes its suppliers for goods already received..
> The term accounts payable gives the chapter a precise name for this part of the problem.

In this chapter, **Accounts payable** means Money a business owes its suppliers for goods already received. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Operating cycle | The days from buying stock to collecting cash from its sale..
> The term operating cycle gives the chapter a precise name for this part of the problem.

In this chapter, **Operating cycle** means The days from buying stock to collecting cash from its sale. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Cash conversion cycle | The operating cycle minus the days a business takes to pay its suppliers..
> The term cash conversion cycle gives the chapter a precise name for this part of the problem.

In this chapter, **Cash conversion cycle** means The operating cycle minus the days a business takes to pay its suppliers. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Float | Money tied up in payments that are sent but not yet usable, such as a cheque in the post..
> The term float gives the chapter a precise name for this part of the problem.

In this chapter, **Float** means Money tied up in payments that are sent but not yet usable, such as a cheque in the post. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in cycles, float and estimating needs is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For cycles, float and estimating needs, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## Worked example
> A complete worked example joins the chapter ideas in one decision.

Consider Meghna and Sons, the running business used in this course. The firm must make a decision related to working capital and short-term financing. Start by listing the known amounts and their dates. Separate cash inflows from cash outflows, identify the rate or comparison rule required by the problem, and keep the units consistent. If a formula is needed, write it before substituting numbers. This prevents a familiar-looking number from being placed in the wrong part of the expression.

> The second pass checks both the arithmetic and the financial interpretation.

Given: a starting amount of Tk 100,000, a one-period rate of 10%, and a one-period horizon. Find: the ending value. Formula: Future value = Present value × (1 + rate). Steps: Tk 100,000 × (1 + 0.10) = Tk 110,000. Answer: Tk 110,000. Check: the increase is Tk 10,000, which is 10% of Tk 100,000, so the result is internally consistent.

> A comparison is useful only when both alternatives are measured on the same basis.

Suppose an alternative offers Tk 115,000 after one period. The difference from the first outcome is Tk 5,000. That does not by itself make the second choice preferable. We still need to know whether the second amount has the same risk, timing, required return, financing terms, and business consequences. Finance begins with a numerical comparison, then asks whether the comparison is fair.

> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
## Summary
> The chapter has connected its main terms, method, and business decision.

The central purpose of Working Capital and Short-Term Financing is to help a beginner identify the relevant financial quantities and use them consistently. The definitions in the chapter give each idea a fixed meaning. The worked example shows the expected order: identify what is given, find what is required, choose the formula or rule, work through the steps, state the answer, and check the result.

## Think It Through
> Finance becomes stronger when a number is followed by a question about meaning.

Ask what the number says about timing, risk, cash, value, or financing. Then ask what information could change the conclusion. A good financial explanation does not hide assumptions. It names them, uses the stated method, and distinguishes a numerical result from a business judgement.

## Where People Go Wrong
> Most errors arise from mixing terms, timing, signs, or decision rules.

Check whether a cash flow is an inflow or an outflow, whether a percentage is written as a decimal before calculation, and whether amounts occur at the same date. Check units and periods. If a result looks surprising, inspect the inputs before changing the formula. The purpose of the check is to catch a mistake, not to force a preferred answer.

## In History
> A historical case shows how the chapter’s financial problem appeared in practice.

Toyota's just-in-time system, developed from the late 1940s by Taiichi Ohno and others to cut stock held. The historical point is not that the old setting was identical to a modern firm. It is that people faced a recognisable problem involving money, timing, ownership, risk, valuation, or control. Modern finance gives that problem a more explicit vocabulary and a set of methods for comparing alternatives.

## Review Questions
:q 14.t1 | say what working capital is and why a profitable firm can still run short
:q 14.t2 | compute the cost of giving up a cash discount for new terms and recommend the cheaper source
:q 14.t3 | find the cash conversion cycle and the financing need for new data
:q 14.t4 | define float and its parts in plain words
:pause 14.p1 | After matching principle, state the rule in your own words.
:pause 14.p2 | After cash conversion cycle, state the rule in your own words.
