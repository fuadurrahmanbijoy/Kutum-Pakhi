:answers 01
:a 01.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 01.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 01.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 01.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 01.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 02
:a 02.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 02.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 02.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 02.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 02.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 03
:a 03.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 03.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 03.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 03.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 03.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 04
:a 04.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 04.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 04.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 04.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 04.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 05
:a 05.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 05.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 05.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 05.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 05.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 06
:a 06.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 06.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 06.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 06.t4 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 06.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 06.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 07
:a 07.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 07.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 07.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 07.t4 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 07.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 07.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 08
:a 08.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 08.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 08.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 08.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 08.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 09
:a 09.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 09.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 09.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 09.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 09.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 10
:a 10.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 10.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 10.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 10.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 10.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 11
:a 11.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 11.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 11.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 11.t4 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 11.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 11.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 12
:a 12.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 12.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 12.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 12.t4 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 12.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 12.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 13
:a 13.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 13.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 13.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 13.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 13.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 14
:a 14.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 14.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 14.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 14.t4 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 14.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 14.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 15
:a 15.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 15.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 15.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 15.t4 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 15.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 15.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers 16
:a 16.t1 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 16.t2 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 16.t3 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 16.t4 | A suitable answer identifies the relevant financial idea, applies the chapter definitions, and shows the calculation where the question asks for one. The reasoning should use the facts given in the question and keep timing and units consistent.
:a 16.p1 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.
:a 16.p2 | State the rule introduced at that point, then give one sentence explaining why it fits the problem.

:answers A1
