:bundle
status: ok
failures: 0
chapters: 16
appendix: a1
changed-duplicates-resolved: 0
glossary-duplicates-removed: 0
chapter | ch01 | I | What Finance Is | 3175 | 1 | 7 | 5
chapter | ch02 | II | The Financial Manager's Decisions | 2837 | 1 | 12 | 5
chapter | ch03 | III | The Goal of the Firm and Agency Theory | 3138 | 1 | 10 | 5
chapter | ch04 | IV | Interest and Future Value | 3095 | 2 | 11 | 5
chapter | ch05 | V | Present Value and Discounting | 3050 | 2 | 6 | 5
chapter | ch06 | VI | Annuities | 3321 | 2 | 4 | 6
chapter | ch07 | VII | Capital Budgeting: Process and Cash Flows | 3039 | 1 | 10 | 6
chapter | ch08 | VIII | Evaluating Projects: Payback and Net Present Value | 3123 | 2 | 5 | 5
chapter | ch09 | IX | Risk and Return | 3332 | 2 | 10 | 5
chapter | ch10 | X | Leverage | 2984 | 2 | 11 | 5
chapter | ch11 | XI | Required Return, CAPM and Market Efficiency | 2977 | 2 | 12 | 6
chapter | ch12 | XII | Valuation of Bonds | 3078 | 2 | 9 | 6
chapter | ch13 | XIII | Valuation of Shares | 3055 | 1 | 6 | 5
chapter | ch14 | XIV | Working Capital and Short-Term Financing | 3236 | 2 | 14 | 6
chapter | ch15 | XV | Long-Term Financing and the Capital Market | 3080 | 1 | 11 | 6
chapter | ch16 | XVI | Leasing | 2828 | 1 | 8 | 6
chapter | a1 | A1 | Maths You Will Use | 776 | 0 | 0 | 0
