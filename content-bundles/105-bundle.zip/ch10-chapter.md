:chapter X | Leverage
:mood A practical question about leverage
:desc This chapter introduces leverage for a first-year reader. It builds each idea from a familiar business problem, defines the terms before using them, and connects the calculations to decisions.
:plate ch10-plate.svg | a long iron lever lifting a heavy stone block in a quarry, 1870s
:fig Leverage figure 1 | ch10-fig01.svg
:fig Leverage figure 2 | ch10-fig02.svg
## 10.1 Costs and the break-even point
> This section builds the idea of costs and the break-even point before moving to application.

The purpose here is to make costs and the break-even point concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Leverage | The use of a fixed cost or fixed payment so that a small change in sales causes a larger change in earnings..
> The term leverage gives the chapter a precise name for this part of the problem.

In this chapter, **Leverage** means The use of a fixed cost or fixed payment so that a small change in sales causes a larger change in earnings. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Fixed cost | A cost that stays the same however many units are sold, such as shop rent..
> The term fixed cost gives the chapter a precise name for this part of the problem.

In this chapter, **Fixed cost** means A cost that stays the same however many units are sold, such as shop rent. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Variable cost | A cost that rises and falls with the number of units sold, such as the price paid for each book..
> The term variable cost gives the chapter a precise name for this part of the problem.

In this chapter, **Variable cost** means A cost that rises and falls with the number of units sold, such as the price paid for each book. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in costs and the break-even point is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For costs and the break-even point, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 10.2 Operating leverage
> This section builds the idea of operating leverage before moving to application.

The purpose here is to make operating leverage concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Contribution margin | Selling price per unit minus variable cost per unit; it pays first for fixed costs, then gives profit..
> The term contribution margin gives the chapter a precise name for this part of the problem.

In this chapter, **Contribution margin** means Selling price per unit minus variable cost per unit; it pays first for fixed costs, then gives profit. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Break-even point | The sales volume at which total revenue equals total cost, so profit is zero..
> The term break-even point gives the chapter a precise name for this part of the problem.

In this chapter, **Break-even point** means The sales volume at which total revenue equals total cost, so profit is zero. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ EBIT | Earnings before interest and tax: sales minus operating costs..
> The term ebit gives the chapter a precise name for this part of the problem.

In this chapter, **EBIT** means Earnings before interest and tax: sales minus operating costs. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in operating leverage is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For operating leverage, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 10.3 Financial leverage
> This section builds the idea of financial leverage before moving to application.

The purpose here is to make financial leverage concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Operating leverage | The effect of fixed operating costs on how EBIT responds to sales.
> The term operating leverage gives the chapter a precise name for this part of the problem.

In this chapter, **Operating leverage** means The effect of fixed operating costs on how EBIT responds to sales. Measured by the degree of operating leverage (DOL), the percentage change in EBIT divided by the percentage change in sales. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Financial leverage | The effect of fixed financing payments on how owners' earnings respond to EBIT.
> The term financial leverage gives the chapter a precise name for this part of the problem.

In this chapter, **Financial leverage** means The effect of fixed financing payments on how owners' earnings respond to EBIT. Measured by the degree of financial leverage (DFL). The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Total leverage | The combined effect of operating and financial leverage on how owners' earnings respond to sales.
> The term total leverage gives the chapter a precise name for this part of the problem.

In this chapter, **Total leverage** means The combined effect of operating and financial leverage on how owners' earnings respond to sales. Measured by the degree of total leverage (DTL), which equals DOL times DFL. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in financial leverage is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For financial leverage, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 10.4 Total leverage and risk
> This section builds the idea of total leverage and risk before moving to application.

The purpose here is to make total leverage and risk concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Earnings per share | Earnings left for owners of common stock divided by the number of shares..
> The term earnings per share gives the chapter a precise name for this part of the problem.

In this chapter, **Earnings per share** means Earnings left for owners of common stock divided by the number of shares. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Preferred stock | Shares that pay a fixed dividend, which must be paid before any dividend on common stock..
> The term preferred stock gives the chapter a precise name for this part of the problem.

In this chapter, **Preferred stock** means Shares that pay a fixed dividend, which must be paid before any dividend on common stock. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in total leverage and risk is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For total leverage and risk, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## Worked example
> A complete worked example joins the chapter ideas in one decision.

Consider Meghna and Sons, the running business used in this course. The firm must make a decision related to leverage. Start by listing the known amounts and their dates. Separate cash inflows from cash outflows, identify the rate or comparison rule required by the problem, and keep the units consistent. If a formula is needed, write it before substituting numbers. This prevents a familiar-looking number from being placed in the wrong part of the expression.

> The second pass checks both the arithmetic and the financial interpretation.

Given: a starting amount of Tk 100,000, a one-period rate of 10%, and a one-period horizon. Find: the ending value. Formula: Future value = Present value × (1 + rate). Steps: Tk 100,000 × (1 + 0.10) = Tk 110,000. Answer: Tk 110,000. Check: the increase is Tk 10,000, which is 10% of Tk 100,000, so the result is internally consistent.

> A comparison is useful only when both alternatives are measured on the same basis.

Suppose an alternative offers Tk 115,000 after one period. The difference from the first outcome is Tk 5,000. That does not by itself make the second choice preferable. We still need to know whether the second amount has the same risk, timing, required return, financing terms, and business consequences. Finance begins with a numerical comparison, then asks whether the comparison is fair.

> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
## Summary
> The chapter has connected its main terms, method, and business decision.

The central purpose of Leverage is to help a beginner identify the relevant financial quantities and use them consistently. The definitions in the chapter give each idea a fixed meaning. The worked example shows the expected order: identify what is given, find what is required, choose the formula or rule, work through the steps, state the answer, and check the result.

## Think It Through
> Finance becomes stronger when a number is followed by a question about meaning.

Ask what the number says about timing, risk, cash, value, or financing. Then ask what information could change the conclusion. A good financial explanation does not hide assumptions. It names them, uses the stated method, and distinguishes a numerical result from a business judgement.

## Where People Go Wrong
> Most errors arise from mixing terms, timing, signs, or decision rules.

Check whether a cash flow is an inflow or an outflow, whether a percentage is written as a decimal before calculation, and whether amounts occur at the same date. Check units and periods. If a result looks surprising, inspect the inputs before changing the formula. The purpose of the check is to catch a mistake, not to force a preferred answer.

## In History
> A historical case shows how the chapter’s financial problem appeared in practice.

Long-Term Capital Management, whose heavy borrowing led to a rescue organised by the Federal Reserve Bank of New York on 23 September 1998. The historical point is not that the old setting was identical to a modern firm. It is that people faced a recognisable problem involving money, timing, ownership, risk, valuation, or control. Modern finance gives that problem a more explicit vocabulary and a set of methods for comparing alternatives.

## Review Questions
:q 10.t1 | say what leverage means and tell its three kinds apart with new data
:q 10.t2 | find the break-even point and degrees of operating, financial and total leverage for a new firm
:q 10.t3 | explain in plain words why high leverage raises risk
:pause 10.p1 | After break-even point, state the rule in your own words.
:pause 10.p2 | After degree of operating leverage, state the rule in your own words.
