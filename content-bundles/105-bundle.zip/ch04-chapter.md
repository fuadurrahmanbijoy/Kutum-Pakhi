:chapter IV | Interest and Future Value
:mood A practical question about interest and future value
:desc This chapter introduces interest and future value for a first-year reader. It builds each idea from a familiar business problem, defines the terms before using them, and connects the calculations to decisions.
:plate ch04-plate.svg | an hourglass, a coin purse and an open savings passbook arranged as a still life, 1850s
:fig Interest and Future Value figure 1 | ch04-fig01.svg
:fig Interest and Future Value figure 2 | ch04-fig02.svg
## 4.1 Why time changes the value of money
> This section builds the idea of why time changes the value of money before moving to application.

The purpose here is to make why time changes the value of money concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Time value of money | The idea that a taka received today is worth more than a taka received later..
> The term time value of money gives the chapter a precise name for this part of the problem.

In this chapter, **Time value of money** means The idea that a taka received today is worth more than a taka received later. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Opportunity cost | What you give up by choosing one use of money instead of the best alternative..
> The term opportunity cost gives the chapter a precise name for this part of the problem.

In this chapter, **Opportunity cost** means What you give up by choosing one use of money instead of the best alternative. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Interest | The payment a borrower makes to a lender for the use of money, or the reward a saver earns..
> The term interest gives the chapter a precise name for this part of the problem.

In this chapter, **Interest** means The payment a borrower makes to a lender for the use of money, or the reward a saver earns. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Interest rate | The interest for one period written as a percentage of the sum, for example 8% a year..
> The term interest rate gives the chapter a precise name for this part of the problem.

In this chapter, **Interest rate** means The interest for one period written as a percentage of the sum, for example 8% a year. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in why time changes the value of money is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For why time changes the value of money, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 4.2 Simple and compound interest
> This section builds the idea of simple and compound interest before moving to application.

The purpose here is to make simple and compound interest concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Principal sum | The original amount lent, borrowed or deposited, before any interest is added..
> The term principal sum gives the chapter a precise name for this part of the problem.

In this chapter, **Principal sum** means The original amount lent, borrowed or deposited, before any interest is added. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Simple interest | Interest calculated only on the principal sum, so it is the same every period..
> The term simple interest gives the chapter a precise name for this part of the problem.

In this chapter, **Simple interest** means Interest calculated only on the principal sum, so it is the same every period. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Compound interest | Interest calculated on the principal sum and also on interest already earned..
> The term compound interest gives the chapter a precise name for this part of the problem.

In this chapter, **Compound interest** means Interest calculated on the principal sum and also on interest already earned. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Future value | What a sum today will be worth at a later date when it earns interest..
> The term future value gives the chapter a precise name for this part of the problem.

In this chapter, **Future value** means What a sum today will be worth at a later date when it earns interest. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in simple and compound interest is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For simple and compound interest, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 4.3 Future value of a single sum
> This section builds the idea of future value of a single sum before moving to application.

The purpose here is to make future value of a single sum concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Compounding period | The length of time after which interest is added to the balance, such as a year or six months..
> The term compounding period gives the chapter a precise name for this part of the problem.

In this chapter, **Compounding period** means The length of time after which interest is added to the balance, such as a year or six months. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Timeline | A line marking each period, with the cash flow written at the point where it occurs..
> The term timeline gives the chapter a precise name for this part of the problem.

In this chapter, **Timeline** means A line marking each period, with the cash flow written at the point where it occurs. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Factor table | A table of ready-made multipliers that saves repeating a long calculation..
> The term factor table gives the chapter a precise name for this part of the problem.

In this chapter, **Factor table** means A table of ready-made multipliers that saves repeating a long calculation. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in future value of a single sum is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For future value of a single sum, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## Worked example
> A complete worked example joins the chapter ideas in one decision.

Consider Meghna and Sons, the running business used in this course. The firm must make a decision related to interest and future value. Start by listing the known amounts and their dates. Separate cash inflows from cash outflows, identify the rate or comparison rule required by the problem, and keep the units consistent. If a formula is needed, write it before substituting numbers. This prevents a familiar-looking number from being placed in the wrong part of the expression.

> The second pass checks both the arithmetic and the financial interpretation.

Given: a starting amount of Tk 100,000, a one-period rate of 10%, and a one-period horizon. Find: the ending value. Formula: Future value = Present value × (1 + rate). Steps: Tk 100,000 × (1 + 0.10) = Tk 110,000. Answer: Tk 110,000. Check: the increase is Tk 10,000, which is 10% of Tk 100,000, so the result is internally consistent.

> A comparison is useful only when both alternatives are measured on the same basis.

Suppose an alternative offers Tk 115,000 after one period. The difference from the first outcome is Tk 5,000. That does not by itself make the second choice preferable. We still need to know whether the second amount has the same risk, timing, required return, financing terms, and business consequences. Finance begins with a numerical comparison, then asks whether the comparison is fair.

> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
## Summary
> The chapter has connected its main terms, method, and business decision.

The central purpose of Interest and Future Value is to help a beginner identify the relevant financial quantities and use them consistently. The definitions in the chapter give each idea a fixed meaning. The worked example shows the expected order: identify what is given, find what is required, choose the formula or rule, work through the steps, state the answer, and check the result.

## Think It Through
> Finance becomes stronger when a number is followed by a question about meaning.

Ask what the number says about timing, risk, cash, value, or financing. Then ask what information could change the conclusion. A good financial explanation does not hide assumptions. It names them, uses the stated method, and distinguishes a numerical result from a business judgement.

## Where People Go Wrong
> Most errors arise from mixing terms, timing, signs, or decision rules.

Check whether a cash flow is an inflow or an outflow, whether a percentage is written as a decimal before calculation, and whether amounts occur at the same date. Check units and periods. If a result looks surprising, inspect the inputs before changing the formula. The purpose of the check is to catch a mistake, not to force a preferred answer.

## In History
> A historical case shows how the chapter’s financial problem appeared in practice.

Richard Price, the 1772 Appeal on the National Debt, and the British sinking fund of 1786 that his compound-interest argument helped to inspire. The historical point is not that the old setting was identical to a modern firm. It is that people faced a recognisable problem involving money, timing, ownership, risk, valuation, or control. Modern finance gives that problem a more explicit vocabulary and a set of methods for comparing alternatives.

## Review Questions
:q 04.t1 | explain why a taka today beats a taka next year, with new figures
:q 04.t2 | compute simple and compound interest on Tk 50,000 at 12% for four years
:q 04.t3 | use a factor table to find a future value for a new rate and period
:pause 04.p1 | After opportunity cost, state the rule in your own words.
:pause 04.p2 | After compound interest, state the rule in your own words.
