:chapter VI | Annuities
:mood A practical question about annuities
:desc This chapter introduces annuities for a first-year reader. It builds each idea from a familiar business problem, defines the terms before using them, and connects the calculations to decisions.
:plate ch06-plate.svg | a clerk counting out regular payments at a post-office window with a queue, 1880s
:fig Annuities figure 1 | ch06-fig01.svg
:fig Annuities figure 2 | ch06-fig02.svg
## 6.1 What an annuity is
> This section builds the idea of what an annuity is before moving to application.

The purpose here is to make what an annuity is concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Annuity | A series of equal payments made at equal intervals for a fixed number of periods..
> The term annuity gives the chapter a precise name for this part of the problem.

In this chapter, **Annuity** means A series of equal payments made at equal intervals for a fixed number of periods. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in what an annuity is is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For what an annuity is, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 6.2 Future value of an annuity
> This section builds the idea of future value of an annuity before moving to application.

The purpose here is to make future value of an annuity concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Ordinary annuity | An annuity whose payments fall at the end of each period..
> The term ordinary annuity gives the chapter a precise name for this part of the problem.

In this chapter, **Ordinary annuity** means An annuity whose payments fall at the end of each period. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in future value of an annuity is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For future value of an annuity, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 6.3 Present value of an annuity
> This section builds the idea of present value of an annuity before moving to application.

The purpose here is to make present value of an annuity concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Annuity due | An annuity whose payments fall at the start of each period..
> The term annuity due gives the chapter a precise name for this part of the problem.

In this chapter, **Annuity due** means An annuity whose payments fall at the start of each period. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in present value of an annuity is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For present value of an annuity, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 6.4 Solving for the payment
> This section builds the idea of solving for the payment before moving to application.

The purpose here is to make solving for the payment concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Instalment | One of a series of regular payments used to repay a loan or build a sum..
> The term instalment gives the chapter a precise name for this part of the problem.

In this chapter, **Instalment** means One of a series of regular payments used to repay a loan or build a sum. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in solving for the payment is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For solving for the payment, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## Worked example
> A complete worked example joins the chapter ideas in one decision.

Consider Meghna and Sons, the running business used in this course. The firm must make a decision related to annuities. Start by listing the known amounts and their dates. Separate cash inflows from cash outflows, identify the rate or comparison rule required by the problem, and keep the units consistent. If a formula is needed, write it before substituting numbers. This prevents a familiar-looking number from being placed in the wrong part of the expression.

> The second pass checks both the arithmetic and the financial interpretation.

Given: a starting amount of Tk 100,000, a one-period rate of 10%, and a one-period horizon. Find: the ending value. Formula: Future value = Present value × (1 + rate). Steps: Tk 100,000 × (1 + 0.10) = Tk 110,000. Answer: Tk 110,000. Check: the increase is Tk 10,000, which is 10% of Tk 100,000, so the result is internally consistent.

> A comparison is useful only when both alternatives are measured on the same basis.

Suppose an alternative offers Tk 115,000 after one period. The difference from the first outcome is Tk 5,000. That does not by itself make the second choice preferable. We still need to know whether the second amount has the same risk, timing, required return, financing terms, and business consequences. Finance begins with a numerical comparison, then asks whether the comparison is fair.

> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
## Summary
> The chapter has connected its main terms, method, and business decision.

The central purpose of Annuities is to help a beginner identify the relevant financial quantities and use them consistently. The definitions in the chapter give each idea a fixed meaning. The worked example shows the expected order: identify what is given, find what is required, choose the formula or rule, work through the steps, state the answer, and check the result.

## Think It Through
> Finance becomes stronger when a number is followed by a question about meaning.

Ask what the number says about timing, risk, cash, value, or financing. Then ask what information could change the conclusion. A good financial explanation does not hide assumptions. It names them, uses the stated method, and distinguishes a numerical result from a business judgement.

## Where People Go Wrong
> Most errors arise from mixing terms, timing, signs, or decision rules.

Check whether a cash flow is an inflow or an outflow, whether a percentage is written as a decimal before calculation, and whether amounts occur at the same date. Check units and periods. If a result looks surprising, inspect the inputs before changing the formula. The purpose of the check is to catch a mistake, not to force a preferred answer.

## In History
> A historical case shows how the chapter’s financial problem appeared in practice.

Johan de Witt, 1671 report to the States of Holland on valuing life annuities for the Dutch Republic. The historical point is not that the old setting was identical to a modern firm. It is that people faced a recognisable problem involving money, timing, ownership, risk, valuation, or control. Modern finance gives that problem a more explicit vocabulary and a set of methods for comparing alternatives.

## Review Questions
:q 06.t1 | say what makes a series of payments an annuity and name its two timing forms
:q 06.t2 | find the future value of an annuity for several rate and period pairs as ordinary and as due
:q 06.t3 | find the present value of a new instalment plan
:q 06.t4 | compute the yearly deposit needed for a stated goal
:pause 06.p1 | After annuity types, state the rule in your own words.
:pause 06.p2 | After future value of an ordinary annuity, state the rule in your own words.
