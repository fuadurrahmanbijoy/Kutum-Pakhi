:chapter A1 | Maths You Will Use
## A1.1 Percentages and percentage change
> This section gives the arithmetic rule used in the book.

Use the rule as a reference. A percentage expresses a part per hundred; a ratio compares two quantities; an average summarises a set of values; an equation can be rearranged by performing the same operation on both sides; rounding should wait until the final useful step. For a graph, read the axes, units, scale, and direction before interpreting the line or bar.
> The tiny example shows the order of work.

Given: the relevant numbers. Find: the requested quantity. Formula: write the relationship first. Steps: substitute the values and calculate. Answer: state the result with its unit. Check: compare the result with the size of the inputs.
## A1.2 Ratios and averages
> This section gives the arithmetic rule used in the book.

Use the rule as a reference. A percentage expresses a part per hundred; a ratio compares two quantities; an average summarises a set of values; an equation can be rearranged by performing the same operation on both sides; rounding should wait until the final useful step. For a graph, read the axes, units, scale, and direction before interpreting the line or bar.
> The tiny example shows the order of work.

Given: the relevant numbers. Find: the requested quantity. Formula: write the relationship first. Steps: substitute the values and calculate. Answer: state the result with its unit. Check: compare the result with the size of the inputs.
## A1.3 Rearranging an equation and rounding
> This section gives the arithmetic rule used in the book.

Use the rule as a reference. A percentage expresses a part per hundred; a ratio compares two quantities; an average summarises a set of values; an equation can be rearranged by performing the same operation on both sides; rounding should wait until the final useful step. For a graph, read the axes, units, scale, and direction before interpreting the line or bar.
> The tiny example shows the order of work.

Given: the relevant numbers. Find: the requested quantity. Formula: write the relationship first. Steps: substitute the values and calculate. Answer: state the result with its unit. Check: compare the result with the size of the inputs.
## A1.4 Reading a graph
> This section gives the arithmetic rule used in the book.

Use the rule as a reference. A percentage expresses a part per hundred; a ratio compares two quantities; an average summarises a set of values; an equation can be rearranged by performing the same operation on both sides; rounding should wait until the final useful step. For a graph, read the axes, units, scale, and direction before interpreting the line or bar.
> The tiny example shows the order of work.

Given: the relevant numbers. Find: the requested quantity. Formula: write the relationship first. Steps: substitute the values and calculate. Answer: state the result with its unit. Check: compare the result with the size of the inputs.

> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
