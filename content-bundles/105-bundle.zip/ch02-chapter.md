:chapter II | The Financial Manager's Decisions
:mood A practical question about the financial manager's decisions
:desc This chapter introduces the financial manager's decisions for a first-year reader. It builds each idea from a familiar business problem, defines the terms before using them, and connects the calculations to decisions.
:plate ch02-plate.svg | a banker at a high desk reviewing a ledger by gaslight, 1880s
:fig The Financial Manager's Decisions figure 1 | ch02-fig01.svg
## 2.1 The three big decisions
> This section builds the idea of the three big decisions before moving to application.

The purpose here is to make the three big decisions concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Financial manager | The person who decides how a business finds, uses and protects its money.
> The term financial manager gives the chapter a precise name for this part of the problem.

In this chapter, **Financial manager** means The person who decides how a business finds, uses and protects its money. In a small shop this may be the owner. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Investment decision | A choice about which assets to buy, such as stock, a van or a new shop, in order to earn more money..
> The term investment decision gives the chapter a precise name for this part of the problem.

In this chapter, **Investment decision** means A choice about which assets to buy, such as stock, a van or a new shop, in order to earn more money. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Financing decision | A choice about where the money comes from: owners' own funds, a loan, or new owners..
> The term financing decision gives the chapter a precise name for this part of the problem.

In this chapter, **Financing decision** means A choice about where the money comes from: owners' own funds, a loan, or new owners. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Dividend | A share of a company's profit paid out to its owners instead of being kept in the business..
> The term dividend gives the chapter a precise name for this part of the problem.

In this chapter, **Dividend** means A share of a company's profit paid out to its owners instead of being kept in the business. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in the three big decisions is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For the three big decisions, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 2.2 What a financial manager does
> This section builds the idea of what a financial manager does before moving to application.

The purpose here is to make what a financial manager does concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Dividend decision | A choice about how much profit to pay out to owners and how much to keep for the business..
> The term dividend decision gives the chapter a precise name for this part of the problem.

In this chapter, **Dividend decision** means A choice about how much profit to pay out to owners and how much to keep for the business. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Treasurer | The officer in charge of handling cash, raising money and keeping relations with banks..
> The term treasurer gives the chapter a precise name for this part of the problem.

In this chapter, **Treasurer** means The officer in charge of handling cash, raising money and keeping relations with banks. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Controller | The officer in charge of accounting records, reports and checking that money is used as planned..
> The term controller gives the chapter a precise name for this part of the problem.

In this chapter, **Controller** means The officer in charge of accounting records, reports and checking that money is used as planned. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Financial planning | Estimating the money a business will need and receive in future, and arranging how to meet the gap..
> The term financial planning gives the chapter a precise name for this part of the problem.

In this chapter, **Financial planning** means Estimating the money a business will need and receive in future, and arranging how to meet the gap. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in what a financial manager does is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For what a financial manager does, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## 2.3 Decisions on the balance sheet
> This section builds the idea of decisions on the balance sheet before moving to application.

The purpose here is to make decisions on the balance sheet concrete. A beginner should be able to name the problem, identify the quantities that matter, and explain why the method fits the problem. The discussion follows the chapter sequence rather than assuming earlier knowledge beyond the stated need.

@ Balance sheet | A statement listing what a business owns and what it owes on one date..
> The term balance sheet gives the chapter a precise name for this part of the problem.

In this chapter, **Balance sheet** means A statement listing what a business owns and what it owes on one date. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Asset | Something a business owns that has value, such as cash, stock or a van..
> The term asset gives the chapter a precise name for this part of the problem.

In this chapter, **Asset** means Something a business owns that has value, such as cash, stock or a van. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Liability | Money a business owes to others, such as a bank loan or an unpaid supplier bill..
> The term liability gives the chapter a precise name for this part of the problem.

In this chapter, **Liability** means Money a business owes to others, such as a bank loan or an unpaid supplier bill. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

@ Equity | What is left for the owners when liabilities are subtracted from assets..
> The term equity gives the chapter a precise name for this part of the problem.

In this chapter, **Equity** means What is left for the owners when liabilities are subtracted from assets. The important point is to use the term consistently. If the same business fact is described with a different everyday word, the calculation does not change, but the financial meaning can become less precise.

> The central question in decisions on the balance sheet is what changes when the underlying decision changes.

Begin with the cash or value that is actually being considered. Then identify its timing, its size, and the uncertainty around it where relevant. Next ask which comparison is valid. A financial rule is useful because it converts a business question into quantities that can be compared. The method is not a substitute for judgement; it gives judgement a disciplined base.

> A small numerical example shows how the idea works before a more realistic case.

Worked example: suppose a firm has a starting amount of Tk 100,000 and the relevant rate is 10% for one period. A one-period increase is Tk 10,000, so the ending amount is Tk 110,000. If the timing changes, the comparison changes too. The same discipline applies when the numbers are larger: state what is given, state what must be found, choose the formula, show the steps, state the answer, and check whether the result is sensible.

> The business meaning matters as much as the arithmetic.

A calculation can be correct and still answer the wrong question. For decisions on the balance sheet, keep the decision in view. Ask what the business is trying to buy, finance, protect, compare, or value. Then check the direction of the result. If a larger cost is treated as a benefit, or a later cash flow is treated as though it arrives today, the arithmetic can hide the error.

* * *
## Worked example
> A complete worked example joins the chapter ideas in one decision.

Consider Meghna and Sons, the running business used in this course. The firm must make a decision related to the financial manager's decisions. Start by listing the known amounts and their dates. Separate cash inflows from cash outflows, identify the rate or comparison rule required by the problem, and keep the units consistent. If a formula is needed, write it before substituting numbers. This prevents a familiar-looking number from being placed in the wrong part of the expression.

> The second pass checks both the arithmetic and the financial interpretation.

Given: a starting amount of Tk 100,000, a one-period rate of 10%, and a one-period horizon. Find: the ending value. Formula: Future value = Present value × (1 + rate). Steps: Tk 100,000 × (1 + 0.10) = Tk 110,000. Answer: Tk 110,000. Check: the increase is Tk 10,000, which is 10% of Tk 100,000, so the result is internally consistent.

> A comparison is useful only when both alternatives are measured on the same basis.

Suppose an alternative offers Tk 115,000 after one period. The difference from the first outcome is Tk 5,000. That does not by itself make the second choice preferable. We still need to know whether the second amount has the same risk, timing, required return, financing terms, and business consequences. Finance begins with a numerical comparison, then asks whether the comparison is fair.

> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
> A short restatement keeps the financial meaning attached to the calculation.

A useful check is to restate the decision without the formula. Say what the business owns, what it owes, what cash arrives, what cash leaves, and when each amount occurs. Then ask whether the comparison uses the same period and the same units. This habit makes later chapters easier because each method begins with a disciplined description of the cash or value being studied.
## Summary
> The chapter has connected its main terms, method, and business decision.

The central purpose of The Financial Manager's Decisions is to help a beginner identify the relevant financial quantities and use them consistently. The definitions in the chapter give each idea a fixed meaning. The worked example shows the expected order: identify what is given, find what is required, choose the formula or rule, work through the steps, state the answer, and check the result.

## Think It Through
> Finance becomes stronger when a number is followed by a question about meaning.

Ask what the number says about timing, risk, cash, value, or financing. Then ask what information could change the conclusion. A good financial explanation does not hide assumptions. It names them, uses the stated method, and distinguishes a numerical result from a business judgement.

## Where People Go Wrong
> Most errors arise from mixing terms, timing, signs, or decision rules.

Check whether a cash flow is an inflow or an outflow, whether a percentage is written as a decimal before calculation, and whether amounts occur at the same date. Check units and periods. If a result looks surprising, inspect the inputs before changing the formula. The purpose of the check is to catch a mistake, not to force a preferred answer.

## In History
> A historical case shows how the chapter’s financial problem appeared in practice.

General Motors in the 1920s: Donaldson Brown, who had come from DuPont, built financial controls linking return on investment to decisions. The historical point is not that the old setting was identical to a modern firm. It is that people faced a recognisable problem involving money, timing, ownership, risk, valuation, or control. Modern finance gives that problem a more explicit vocabulary and a set of methods for comparing alternatives.

## Review Questions
:q 02.t1 | name and tell apart the three decisions using a new business
:q 02.t2 | state the work of a treasurer and a controller
:q 02.t3 | build a balance sheet from a new list of items and check that it balances
:pause 02.p1 | After the three decisions, state the rule in your own words.
:pause 02.p2 | After the balance sheet, state the rule in your own words.
