:glossary 01
Finance | The activity of finding money, using it, and judging whether the result was worth it. A shop owner who borrows to buy stock does finance.
Cash flow | Money that actually moves into or out of a business. Paying a supplier Tk 5,000 is a cash flow of minus Tk 5,000.
Profit | What a business earns from sales after subtracting the costs of earning them. Sales of Tk 100 and costs of Tk 80 leave profit of Tk 20.
Operating efficiency | How much useful output a business gets from the money and effort it uses. A shop that sells more per taka of stock is more efficient.
Sole proprietorship | A business owned and run by one person, who keeps all profit and answers for all debts.
Partnership | A business owned by two or more people who agree to run it together and share its profit.
Company | A business set up as a legal person of its own, owned through shares, so the owners are separate from the business.

:glossary 02
Financial manager | The person who decides how a business finds, uses and protects its money. In a small shop this may be the owner.
Investment decision | A choice about which assets to buy, such as stock, a van or a new shop, in order to earn more money.
Financing decision | A choice about where the money comes from: owners' own funds, a loan, or new owners.
Dividend | A share of a company's profit paid out to its owners instead of being kept in the business.
Dividend decision | A choice about how much profit to pay out to owners and how much to keep for the business.
Treasurer | The officer in charge of handling cash, raising money and keeping relations with banks.
Controller | The officer in charge of accounting records, reports and checking that money is used as planned.
Financial planning | Estimating the money a business will need and receive in future, and arranging how to meet the gap.
Balance sheet | A statement listing what a business owns and what it owes on one date.
Asset | Something a business owns that has value, such as cash, stock or a van.
Liability | Money a business owes to others, such as a bank loan or an unpaid supplier bill.
Equity | What is left for the owners when liabilities are subtracted from assets.

:glossary 03
Profit maximisation | Aiming to make the largest profit possible, usually within one year.
Wealth maximisation | Aiming to raise the value of the owners' investment over time, taking account of when money arrives and how risky it is.
Shareholder | A person who owns part of a company by holding its shares.
Share price | The price at which one share of a company can be bought or sold today.
Stakeholder | Anyone affected by a firm's actions, such as staff, customers, lenders and the community.
Principal | A person who hires another to act for them. A shop owner who hires a manager is a principal.
Agent | A person who acts for a principal and makes decisions for the principal. A hired shop manager is an agent.
Agency problem | A conflict that arises when an agent's own interests differ from those of the principal.
Agency cost | A cost the principal bears to reduce the agency problem or from the loss it still causes.
Incentive | A reward, such as a bonus, that encourages a person to act in a chosen way.

:glossary 04
Time value of money | The idea that a taka received today is worth more than a taka received later.
Opportunity cost | What you give up by choosing one use of money instead of the best alternative.
Interest | The payment a borrower makes to a lender for the use of money, or the reward a saver earns.
Interest rate | The interest for one period written as a percentage of the sum, for example 8% a year.
Principal sum | The original amount lent, borrowed or deposited, before any interest is added.
Simple interest | Interest calculated only on the principal sum, so it is the same every period.
Compound interest | Interest calculated on the principal sum and also on interest already earned.
Future value | What a sum today will be worth at a later date when it earns interest.
Compounding period | The length of time after which interest is added to the balance, such as a year or six months.
Timeline | A line marking each period, with the cash flow written at the point where it occurs.
Factor table | A table of ready-made multipliers that saves repeating a long calculation.

:glossary 05
Present value | What a sum due in the future is worth today.
Discounting | Finding present value by removing the interest a sum could earn before it arrives.
Discount rate | The yearly percentage used in discounting; it states the return you could earn elsewhere.
Cash inflow | Money coming into a business or to an investor, shown as a positive number.
Cash outflow | Money going out of a business or from an investor, shown as a negative number.
Mixed stream | A series of cash flows of different sizes in different periods.

:glossary 06
Annuity | A series of equal payments made at equal intervals for a fixed number of periods.
Ordinary annuity | An annuity whose payments fall at the end of each period.
Annuity due | An annuity whose payments fall at the start of each period.
Instalment | One of a series of regular payments used to repay a loan or build a sum.

:glossary 07
Capital budgeting | Planning and choosing long-lasting investments by comparing the money they cost with the money they should bring.
Capital expenditure | Spending on an asset that will help a business for more than one year.
Independent project | A project that can be accepted or rejected without affecting any other project.
Mutually exclusive projects | Projects of which only one can be chosen, because choosing one rules out the other.
Relevant cash flow | A cash flow that changes because of the decision being studied.
Sunk cost | Money already spent that cannot be recovered whatever you decide now.
Initial investment | The cash flows at the start of a project to buy and prepare the asset.
Operating cash flow | The cash a project brings in each year after paying its cash costs and tax.
Terminal cash flow | The cash received or paid when a project ends, such as the sale of scrap.
Depreciation | The share of an asset's cost charged against income each year as the asset wears out.

:glossary 08
Payback period | The time a project takes to return its initial investment from its cash flows.
Discounted payback period | The payback time when each cash flow is first discounted to present value.
Net present value | The present value of all a project's future cash flows minus its initial investment.
Internal rate of return | The discount rate at which a project's net present value is exactly zero.
Profitability index | Present value of future cash flows divided by the initial investment.

:glossary 09
Return | The gain or loss from an investment, including income received and any change in value.
Rate of return | The return in one period divided by the sum invested, written as a percentage.
Risk | The chance that the actual result will differ from the result you expect.
Business risk | Risk that comes from the firm's own trade, such as falling sales or rising costs, before any borrowing.
Financial risk | Extra risk that comes from borrowing, because interest must be paid whatever the sales.
Probability distribution | A list of possible results with the chance of each, the chances adding to one.
Expected value | The average of possible results, each weighted by its probability.
Variance | The probability-weighted average of the squared gaps between each result and the expected value.
Standard deviation | The square root of the variance; it shows how far results typically stray from the expected value.
Coefficient of variation | Standard deviation divided by expected value, giving risk per unit of expected return.

:glossary 10
Leverage | The use of a fixed cost or fixed payment so that a small change in sales causes a larger change in earnings.
Fixed cost | A cost that stays the same however many units are sold, such as shop rent.
Variable cost | A cost that rises and falls with the number of units sold, such as the price paid for each book.
Contribution margin | Selling price per unit minus variable cost per unit; it pays first for fixed costs, then gives profit.
Break-even point | The sales volume at which total revenue equals total cost, so profit is zero.
EBIT | Earnings before interest and tax: sales minus operating costs.
Operating leverage | The effect of fixed operating costs on how EBIT responds to sales. Measured by the degree of operating leverage (DOL), the percentage change in EBIT divided by the percentage change in sales.
Financial leverage | The effect of fixed financing payments on how owners' earnings respond to EBIT. Measured by the degree of financial leverage (DFL).
Total leverage | The combined effect of operating and financial leverage on how owners' earnings respond to sales. Measured by the degree of total leverage (DTL), which equals DOL times DFL.
Earnings per share | Earnings left for owners of common stock divided by the number of shares.
Preferred stock | Shares that pay a fixed dividend, which must be paid before any dividend on common stock.

:glossary 11
Required return | The least return an investor will accept for taking a given risk.
Risk-free rate | The return on an investment with no risk of loss, such as a short-term government security.
Risk premium | The extra return demanded for taking risk instead of a risk-free investment.
Portfolio | A collection of investments held together by one investor.
Diversification | Spreading money across many investments so that one failure does less damage.
Systematic risk | Risk that affects all investments, such as a recession; it cannot be diversified away.
Unsystematic risk | Risk that affects one firm or industry only; diversification can remove it.
Beta | A number showing how strongly an investment's return moves with the market; 1.0 means it moves with the market.
Market return | The average return of all investments in a market during a period.
Capital asset pricing model | A formula for required return: risk-free rate plus beta times the market risk premium.
Security market line | The graph of the capital asset pricing model, with beta on one axis and required return on the other.
Efficient market | A market in which prices already reflect the available information.

:glossary 12
Valuation | Finding what an asset is worth today by adding the present values of the cash it will bring.
Bond | A loan made to a company or government, repaid on a set date, with interest paid on the way.
Face value | The amount a bond repays at its end, for example Tk 1,000.
Coupon rate | The yearly interest of a bond, as a percentage of its face value.
Maturity | The date on which a bond or loan must be repaid.
Yield to maturity | The yearly return an investor earns by buying a bond at today's price and holding it to maturity.
Premium bond | A bond that sells for more than its face value.
Discount bond | A bond that sells for less than its face value.
Semiannual interest | Interest paid twice a year, each payment being half the yearly amount.

:glossary 13
Common stock | Shares that give owners a vote and a claim on profit after all other claims are met.
Residual claim | The right to whatever is left after lenders and preferred owners have been paid.
Capital gain | The profit from selling an asset for more than its purchase price.
Perpetuity | A series of equal payments that continues for ever.
Dividend valuation model | A way of valuing a share as the present value of the dividends it is expected to pay.
Constant growth model | The dividend valuation model for dividends that grow at the same rate every year.

:glossary 14
Working capital | The money a business has tied up in everyday trading: cash, stock and money owed to it.
Net working capital | Current assets minus current liabilities; what remains for trading after short debts are paid.
Matching principle | Pay for short-lived needs with short-term money and for lasting needs with long-term money.
Short-term financing | Money borrowed to be repaid within one year.
Intermediate-term financing | Money borrowed to be repaid in more than one year but not more than about five.
Long-term financing | Money raised for more than about five years, or with no fixed repayment date.
Trade credit | Credit from a supplier who lets a buyer pay some days after delivery.
Cash discount | A price cut a supplier gives for paying early, such as 2% off if paid within 10 days.
Inventory | The goods a business holds for sale, such as the books on a shop's shelves.
Accounts receivable | Money that customers owe a business for goods already delivered.
Accounts payable | Money a business owes its suppliers for goods already received.
Operating cycle | The days from buying stock to collecting cash from its sale.
Cash conversion cycle | The operating cycle minus the days a business takes to pay its suppliers.
Float | Money tied up in payments that are sent but not yet usable, such as a cheque in the post.

:glossary 15
Term loan | A loan repaid in regular instalments over a fixed number of years, usually from a bank.
Collateral | An asset a lender may take if the borrower fails to repay.
Covenant | A condition in a loan agreement that the borrower promises to keep.
Debenture | A bond backed only by the issuer's general promise to pay, not by a particular asset.
Retained earnings | Profit kept in the business instead of being paid out as dividends.
Capital market | The market in which long-term money is raised by selling bonds and shares.
Initial public offering | A company's first sale of shares to the public.
Rights issue | An offer of new shares to existing shareholders, in proportion to their holdings.
Underwriter | An institution that promises to buy any shares of a new issue that the public does not.
Cost of capital | The return a firm must earn on its investments to satisfy those who supply its money.
Weighted average cost of capital | The average cost of a firm's different sources of money, each weighted by its share of the total.

:glossary 16
Lease | A contract in which the owner of an asset lets another party use it for regular payments.
Lessor | The owner who lets the asset out under a lease.
Lessee | The user who pays to use the asset under a lease.
Operating lease | A short lease, cancellable, where the lessor keeps most of the risks of owning the asset.
Financial lease | A long lease, not cancellable, that covers most of the asset's life and works like a loan.
Sale-and-leaseback | A deal in which a firm sells an asset it owns and leases it back from the buyer.
Tax shield | The tax saved because a cost, such as interest or depreciation, reduces taxable income.
After-tax cash outflow | A payment's cost after subtracting the tax it saves.

:glossary A1
