:chapter VII | Cooperative Societies
:mood How does the business idea become a workable decision?
:desc Teach what a cooperative society is, the principles it follows, the kinds found in Bangladesh, how it operates, and where it helps and falls short. The chapter builds the idea from ordinary experience to business practice.
:plate ch07-plate.svg | villagers loading sacks onto a cart outside a cooperative store, 1870s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 5, 'Partnership', section 5.1 'The Idea and Types of Partnership'; Chapter 6, 'Joint Stock Company', section 6.1 'The Company and Its Shares'

## The Idea and Principles of Cooperation

> The Idea and Principles of Cooperation begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about the idea and principles of cooperation. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Cooperative society | a business owned and run by its members, who join to meet a shared need rather than to earn the largest profit
> The definition gives the boundary of cooperative society before the example is applied.
The word **Cooperative society** means a business owned and run by its members, who join to meet a shared need rather than to earn the largest profit. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Surplus | the money left over after a cooperative pays its costs, which it shares or keeps for the members
> The definition gives the boundary of surplus before the example is applied.
The word **Surplus** means the money left over after a cooperative pays its costs, which it shares or keeps for the members. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Marketing cooperative | a society that gathers members' products, such as crops, and sells them for a better price
> The definition gives the boundary of marketing cooperative before the example is applied.
The word **Marketing cooperative** means a society that gathers members' products, such as crops, and sells them for a better price. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in The Idea and Principles of Cooperation is what the cooperative society, its aims and the principles it follows changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The cooperative society, its aims and the principles it follows. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in The Idea and Principles of Cooperation is what open membership and one member, one vote changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Open membership and one member, one vote. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in The Idea and Principles of Cooperation.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in The Idea and Principles of Cooperation.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in The Idea and Principles of Cooperation.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in The Idea and Principles of Cooperation.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in The Idea and Principles of Cooperation.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Case in this chapter is a members' purchasing society, an illustrative arrangement (membership rules differ by society and by law). On 3 February 2025 Meghna and Sons Limited joined the Dhaka Booksellers' Purchasing Society as one of 40 member shops. Each member holds one share of Tk 5,000, so share capital is Tk 200,000 (40 x 5,000). Each member has one vote. For the year ended 31 December 2025 the members bought books worth Tk 3,000,000 through the society. The society's surplus after costs was Tk 150,000. The general meeting voted to return 80% of the surplus to members as a patronage refund, Tk 120,000 (150,000 x 80/100), and to keep 20%, Tk 30,000, as a reserve. Meghna and Sons Limited bought books worth Tk 240,000 through the society, which is 8% of the total (240,000 / 3,000,000), so its refund was Tk 9,600 (120,000 x 8/100).


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* The Idea and Principles of Cooperation can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Types and Operation of Cooperatives

> Types and Operation of Cooperatives begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about types and operation of cooperatives. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Open membership | the rule that anyone who meets the society's basic conditions may join, with no unfair barrier
> The definition gives the boundary of open membership before the example is applied.
The word **Open membership** means the rule that anyone who meets the society's basic conditions may join, with no unfair barrier. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Patronage refund | a share of the surplus paid to members in proportion to the business they did with the society
> The definition gives the boundary of patronage refund before the example is applied.
The word **Patronage refund** means a share of the surplus paid to members in proportion to the business they did with the society. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Consumer cooperative | a society that buys goods in bulk and sells them to members at fair prices
> The definition gives the boundary of consumer cooperative before the example is applied.
The word **Consumer cooperative** means a society that buys goods in bulk and sells them to members at fair prices. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Types and Operation of Cooperatives is what kinds of cooperative found in bangladesh, including those that help farmers market their crops changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Kinds of cooperative found in Bangladesh, including those that help farmers market their crops. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Types and Operation of Cooperatives is what how a society is formed, financed, governed and shares its surplus changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: How a society is formed, financed, governed and shares its surplus. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Types and Operation of Cooperatives.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Types and Operation of Cooperatives.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Types and Operation of Cooperatives.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Types and Operation of Cooperatives.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Types and Operation of Cooperatives.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Types and Operation of Cooperatives can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Importance and Limits

> Importance and Limits begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about importance and limits. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Democratic control | the rule that each member has one vote, however many shares or how much business they bring
> The definition gives the boundary of democratic control before the example is applied.
The word **Democratic control** means the rule that each member has one vote, however many shares or how much business they bring. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Credit cooperative | a society that collects savings from members and lends to them on fair terms
> The definition gives the boundary of credit cooperative before the example is applied.
The word **Credit cooperative** means a society that collects savings from members and lends to them on fair terms. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Producer cooperative | a society in which members make goods together and share the work and the reward
> The definition gives the boundary of producer cooperative before the example is applied.
The word **Producer cooperative** means a society in which members make goods together and share the work and the reward. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Importance and Limits is what the importance of cooperatives and their limits changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The importance of cooperatives and their limits. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Importance and Limits.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Importance and Limits.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Importance and Limits.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Importance and Limits.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Importance and Limits.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Case in this chapter is a members' purchasing society, an illustrative arrangement (membership rules differ by society and by law). On 3 February 2025 Meghna and Sons Limited joined the Dhaka Booksellers' Purchasing Society as one of 40 member shops. Each member holds one share of Tk 5,000, so share capital is Tk 200,000 (40 x 5,000). Each member has one vote. For the year ended 31 December 2025 the members bought books worth Tk 3,000,000 through the society. The society's surplus after costs was Tk 150,000. The general meeting voted to return 80% of the surplus to members as a patronage refund, Tk 120,000 (150,000 x 80/100), and to keep 20%, Tk 30,000, as a reserve. Meghna and Sons Limited bought books worth Tk 240,000 through the society, which is 8% of the total (240,000 / 3,000,000), so its refund was Tk 9,600 (120,000 x 8/100).


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Importance and Limits can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Case in this chapter is a members' purchasing society, an illustrative arrangement (membership rules differ by society and by law). On 3 February 2025 Meghna and Sons Limited joined the Dhaka Booksellers' Purchasing Society as one of 40 member shops. Each member holds one share of Tk 5,000, so share capital is Tk 200,000 (40 x 5,000). Each member has one vote. For the year ended 31 December 2025 the members bought books worth Tk 3,000,000 through the society. The society's surplus after costs was Tk 150,000. The general meeting voted to return 80% of the surplus to members as a patronage refund, Tk 120,000 (150,000 x 80/100), and to keep 20%, Tk 30,000, as a reserve. Meghna and Sons Limited bought books worth Tk 240,000 through the society, which is 8% of the total (240,000 / 3,000,000), so its refund was Tk 9,600 (120,000 x 8/100).


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 7.t1 | define cooperative society and give three of its principles

:q 7.t2 | explain why one member has one vote and how that differs from a company

:q 7.t3 | name four kinds of cooperative and say who each helps

:q 7.t4 | describe how a surplus is shared

:q 7.t5 | a farmers' society sells its crop for Tk 600,000 against Tk 520,000 if each farmer sold alone and has 40 members, so find the gain per member and say what the members might do with a surplus

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
The Rochdale Society of Equitable Pioneers, opened in Rochdale, England, in December 1844 in Toad Lane, and the rules it set for its members. Search hint: Rochdale Pioneers 1844 Toad Lane principles.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Sources

> These sources support the historical or defining material used in the chapter.
:read The historical case named in this chapter, institutional or primary record, year
:read A standard reference on the chapter's subject, author and title, year

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 7.r1 | define cooperative society and give three of its principles

:q 7.r2 | explain why one member has one vote and how that differs from a company

:q 7.r3 | name four kinds of cooperative and say who each helps

:q 7.r4 | describe how a surplus is shared

:q 7.r5 | a farmers' society sells its crop for Tk 600,000 against Tk 520,000 if each farmer sold alone and has 40 members, so find the gain per member and say what the members might do with a surplus

:pause 7.p1 | after the principles, and after the passage on sharing surplus

:fig members at the base voting in a general meeting, which elects a managing committee, which hires a manager; a second arrow shows surplus flowing back to members by their purchases | ch07-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 5, 'Partnership', section 5.1 'The Idea and Types of Partnership' — a small group owning together; Chapter 6, 'Joint Stock Company', section 6.1 'The Company and Its Shares' — the contrast of votes by member and votes by share. These references are reminders of where a related idea is developed; they do not introduce a new definition here.