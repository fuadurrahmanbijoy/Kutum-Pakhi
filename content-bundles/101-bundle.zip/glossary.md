:glossary 01
Need | something a person must have to live safely and in health, such as food, water, shelter and basic care. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Want | something a person would like to have but could live without, such as a new phone or a holiday. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Exchange | giving one thing and receiving another in return, whether goods, services or money. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Good | a physical item that can be touched and owned, such as a book, a chair or a bag of rice. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Service | useful work done for another person that leaves nothing physical behind, such as teaching, carrying or repairing. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Business | an activity that supplies goods or services to customers in the hope of earning a profit. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Profit | the money left over when the costs of running a business are taken away from what it earns. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Risk | the chance that a business will earn less than it hoped, or lose money, because the future is uncertain. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Trade | the buying and selling of goods, either to make a profit or to supply what others want. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Commerce | all the activities that help goods move from maker to user, including trade and the services that support it. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Industry | the making or growing of goods, or the extraction of materials, by people who use skill, tools and effort. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 02
Factors of production | the resources a business must combine to make or sell anything: land, labour, capital and the entrepreneur. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Land | all natural resources and the ground itself, including soil, water, minerals and the site of a shop. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Labour | the physical and mental effort that people give to producing goods or services. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Capital | the money and the man-made means of production, such as tools, stock and buildings, used to earn more. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Entrepreneur | the person who combines the other resources, takes the risk and organises a business to meet a need. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Location | the place where a business carries out its work, chosen from the available sites. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Plant | the factory, machinery and equipment that a business uses to make its goods. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Environment | everything outside and around a business that can affect it, and everything inside that it controls. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Internal environment | the parts of the environment that the business controls: owners, managers, employees, methods and resources. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
External environment | the forces outside the business that it cannot control but must respond to. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 03
Social responsibility | the duty of a business to act in ways that benefit society as well as itself. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Stakeholder | any person or group affected by a business or able to affect it, such as customers or neighbours. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Supplier | a person or business that sells the goods, materials or services that another business needs. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Investor | a person or organisation that puts money into a business in the hope of getting more money back. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Business ethics | the standards of right and wrong that guide how a business treats people and makes decisions. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 04
Liability | the duty to pay what the business owes, whether to a supplier, a lender or an employee. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Unlimited liability | the owner must pay all the business's debts, using personal property if the business cannot. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Limited liability | the owner can lose only the money put into the business, and personal property stays safe. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Legal person | an organisation that the law treats as separate from its owners, able to own property and make contracts. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Sole proprietorship | a business owned, financed and run by one person who keeps all profit and bears all loss. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Trade licence | official permission, given by a local authority, to carry on a particular business in a particular place. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 05
Partnership | a business owned by two or more people who agree to run it together and share its profit. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Partner | one of the people who own a partnership and share in its profit, loss and duties. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Partnership deed | the written agreement that sets out how partners share capital, profit, work and decisions. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Partnership at will | a partnership with no fixed end date, which any partner can end by giving notice. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Active partner | a partner who takes a full part in running the business day to day. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Sleeping partner | a partner who puts in money and shares profit but takes no part in running the business. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Nominal partner | a person who lends their name to the business and takes no share, yet may still be answerable to outsiders. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Dissolution | the ending of the partnership between the partners, or of the whole business, with its affairs settled. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 06
Company | a business that the law treats as a separate person, owned by shareholders through shares. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Share | one equal part of a company's capital, which gives its holder a part of ownership. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Shareholder | a person or organisation that owns one or more shares in a company. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Dividend | the part of a company's profit that is paid out to its shareholders. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Authorised capital | the largest amount of share capital that a company is permitted to raise under its rules. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Private company | a company that limits who may hold its shares and may not invite the public to buy them. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Public company | a company that may invite the public to buy its shares and whose shares can be freely traded. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Board of directors | the group chosen by shareholders to guide the company and appoint its senior managers. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Memorandum of association | the founding document that states a company's name, aims, home and capital. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Articles of association | the rules for running the company inside, including meetings, directors and shares. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Certificate of incorporation | the official paper that proves the company legally exists as a separate person. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Prospectus | the document by which a public company invites the public to buy its shares. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Certificate of commencement | the official paper that allows a public company to start business after it has raised enough money. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 07
Cooperative society | a business owned and run by its members, who join to meet a shared need rather than to earn the largest profit. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Open membership | the rule that anyone who meets the society's basic conditions may join, with no unfair barrier. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Democratic control | the rule that each member has one vote, however many shares or how much business they bring. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Surplus | the money left over after a cooperative pays its costs, which it shares or keeps for the members. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Patronage refund | a share of the surplus paid to members in proportion to the business they did with the society. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Credit cooperative | a society that collects savings from members and lends to them on fair terms. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Marketing cooperative | a society that gathers members' products, such as crops, and sells them for a better price. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Consumer cooperative | a society that buys goods in bulk and sells them to members at fair prices. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Producer cooperative | a society in which members make goods together and share the work and the reward. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 08
State enterprise | a business owned and run by the government, set up to serve the public or to earn money for the state. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Public sector | all the businesses and organisations that the government owns or controls. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Nationalisation | the act of a government taking over a privately owned business and making it state property. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Monopoly | a market in which only one seller supplies a good or service, so customers have no choice. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Departmental undertaking | a state business run as a part of a government office and funded from its budget. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Public corporation | a state business set up by a special law, with its own legal identity and some freedom to act. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Government company | a company, formed under company law, in which the government owns most or all of the shares. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Public utility | a service that everyone needs and that is hard to supply through competition, such as water or electricity. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Privatisation | the sale or handing over of a state enterprise to private owners. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 09
Ordinary share | a share whose holder votes at meetings and receives a dividend that rises and falls with the company's profit. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Preference share | a share whose holder is paid a fixed dividend before ordinary shareholders but usually has no vote. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Share market | the whole system of buying and selling shares, both when they are first issued and afterwards. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Primary market | the part of the share market where a company sells new shares directly to investors for the first time. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Secondary market | the part of the share market where investors buy and sell shares that already exist. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Initial public offering | the first time a company invites the public to buy its shares. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Stock exchange | an organised market with rules where approved members trade company shares and other securities. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Broker | a licensed person or firm that buys and sells shares for clients and earns a fee. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Share price index | a single number that shows how the prices of a chosen group of shares have moved together. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 10
Foreign trade | the buying and selling of goods and services between people or businesses in different countries. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Export | a good or service sold to a buyer in another country. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Import | a good or service bought from a seller in another country. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Comparative advantage | a country's ability to make a good at a lower sacrifice of other goods than another country can. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Visible trade | trade in goods that can be seen and counted at a port, such as books, cloth and machines. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Invisible trade | trade in services, such as shipping, insurance and tourism, that cannot be seen at a port. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Balance of trade | the value of a country's visible exports minus the value of its visible imports. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Balance of payments | the full record of money flowing into and out of a country over a period for all kinds of dealings. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Letter of credit | a bank's written promise to pay the exporter once agreed documents are shown. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Bill of lading | a receipt and contract issued by a shipping company for goods it has accepted for carriage. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Charter party | the contract by which the owner of a ship hires the whole ship, or part of it, to another business. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Customs duty | a tax charged on goods when they cross a national border. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Non-tariff barrier | a rule or practice other than a tax that makes it harder to trade, such as a quota or a quality test. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 11
Multinational corporation | a company that owns and runs business operations in two or more countries. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Home country | the country where a multinational has its headquarters and where its parent company is based. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Host country | a country in which a multinational sets up a branch or subsidiary and operates. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Subsidiary | a company that is owned or controlled by another, larger company called the parent. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Parent-country national | an employee of a multinational who comes from the country of its headquarters. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Host-country national | an employee of a multinational who comes from the country where it is operating. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Third-country national | an employee of a multinational who comes from neither its home nor its host country. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Technology transfer | the passing of knowledge, machines and methods from one country or firm to another. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary 12
Securities regulator | a public body that makes and enforces rules for the share market in order to protect investors. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Chamber of commerce | an association of local businesses that speaks for them and helps them trade. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Export processing zone | a designated area with special facilities and incentives, set up to attract factories that make goods for export. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Business combination | two or more businesses joining together, by agreement or by one taking over another, to act as a larger unit. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Cartel | a loose agreement among businesses that stay separate but fix prices or output together. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Holding company | a company that controls others by owning enough of their shares. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Merger | the joining of two or more businesses into one, with the owners of each becoming owners of the new business. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Horizontal integration | joining businesses that sell the same kind of good or service at the same stage of the chain. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.
Vertical integration | joining businesses at different stages of the chain, such as a printer, a wholesaler and a shop. The term should be used only in this stated sense in the chapter. A small business example can make the boundary easier to recognise.

:glossary A1
Percentage | a part expressed out of one hundred.
Ratio | a comparison of two quantities using division.
Average | a value found by combining quantities and dividing by their number.
