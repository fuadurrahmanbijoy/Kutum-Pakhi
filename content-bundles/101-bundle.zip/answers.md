:answers 01
:a 1.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 1.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 1.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 1.t4 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 1.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 1.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 1.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 1.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 1.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 1.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 1.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 02
:a 2.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 2.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 2.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 2.t4 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 2.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 2.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 2.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 2.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 2.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 2.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 2.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 03
:a 3.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 3.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 3.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 3.t4 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 3.t5 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 3.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 3.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 3.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 3.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 3.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 3.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 04
:a 4.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 4.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 4.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 4.t4 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 4.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 4.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 4.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 4.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 4.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 4.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 4.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 05
:a 5.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 5.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 5.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 5.t4 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 5.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 5.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 5.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 5.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 5.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 5.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 5.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 06
:a 6.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 6.t2 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 6.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 6.t4 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 6.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 6.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 6.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 6.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 6.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 6.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 6.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 07
:a 7.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 7.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 7.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 7.t4 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 7.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 7.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 7.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 7.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 7.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 7.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 7.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 08
:a 8.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 8.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 8.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 8.t4 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 8.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 8.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 8.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 8.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 8.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 8.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 8.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 09
:a 9.t1 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 9.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 9.t3 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 9.t4 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 9.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 9.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 9.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 9.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 9.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 9.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 9.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 10
:a 10.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 10.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 10.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 10.t4 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 10.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 10.t6 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 10.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 10.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 10.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 10.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 10.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 10.r6 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 10.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 11
:a 11.t1 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 11.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 11.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 11.t4 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 11.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 11.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 11.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 11.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 11.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 11.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 11.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers 12
:a 12.t1 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 12.t2 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 12.t3 | Define the relevant idea, apply it to the facts given, and state the conclusion briefly.
:a 12.t4 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 12.t5 | Apply the stated figures to the relevant rule, keep the units consistent, and state the resulting figure or allocation.
:a 12.r1 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 12.r2 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 12.r3 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 12.r4 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 12.r5 | The same principle applies: identify the relevant distinction, use the facts stated, and explain why the conclusion follows.
:a 12.p1 | Pause by restating the key distinction in the question and checking it against the chapter's definition.

:answers A1
