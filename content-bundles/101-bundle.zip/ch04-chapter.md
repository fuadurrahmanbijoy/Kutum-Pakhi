:chapter IV | Ways to Own a Business, and the Sole Proprietor
:mood How does the business idea become a workable decision?
:desc Show why the form of ownership matters, teach limited and unlimited liability, and explain the sole proprietorship with its strengths and limits. The chapter builds the idea from ordinary experience to business practice.
:plate ch04-plate.svg | a lone shopkeeper at a counter with scales, a ledger and shelves of jars, 1880s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 1, 'What Business Is, Does and Aims For', section 1.2 'What a Business Is'; Chapter 3, 'Social Responsibility of Business', section 3.2 'Responsibility to Society, Suppliers and Investors'

## Why the Form of Ownership Matters

> Why the Form of Ownership Matters begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about why the form of ownership matters. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Liability | the duty to pay what the business owes, whether to a supplier, a lender or an employee
> The definition gives the boundary of liability before the example is applied.
The word **Liability** means the duty to pay what the business owes, whether to a supplier, a lender or an employee. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Legal person | an organisation that the law treats as separate from its owners, able to own property and make contracts
> The definition gives the boundary of legal person before the example is applied.
The word **Legal person** means an organisation that the law treats as separate from its owners, able to own property and make contracts. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Why the Form of Ownership Matters is what liability, unlimited and limited, and who bears a business's losses changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Liability, unlimited and limited, and who bears a business's losses. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Why the Form of Ownership Matters is what the main forms of ownership and the legal person changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The main forms of ownership and the legal person. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Why the Form of Ownership Matters.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Why the Form of Ownership Matters.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Why the Form of Ownership Matters.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Why the Form of Ownership Matters.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Why the Form of Ownership Matters.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons is a sole proprietorship owned by Rafiq Uddin Mia, with a bank loan of Tk 60,000 taken on 1 March 2019. Position on 31 December 2019: assets Tk 400,000 (stock Tk 310,000 and other assets Tk 90,000); debts Tk 180,000 (owed to suppliers Tk 120,000 and to the bank Tk 60,000); the owner's own stake was therefore Tk 220,000 (400,000 - 180,000). The shop was closed for nine weeks in 2020. Position on 31 December 2020: assets Tk 380,000; debts Tk 430,000 (owed to suppliers Tk 370,000 and to the bank Tk 60,000); debts exceeded assets by Tk 50,000 (430,000 - 380,000). On 15 January 2021 Rafiq paid the Tk 50,000 shortfall from his personal savings. The shop's trade licence (illustrative number TL-2015-0417) was issued on 20 December 2014 and has been renewed each year.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Why the Form of Ownership Matters can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Sole Proprietorship

> Sole Proprietorship begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about sole proprietorship. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Unlimited liability | the owner must pay all the business's debts, using personal property if the business cannot
> The definition gives the boundary of unlimited liability before the example is applied.
The word **Unlimited liability** means the owner must pay all the business's debts, using personal property if the business cannot. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Sole proprietorship | a business owned, financed and run by one person who keeps all profit and bears all loss
> The definition gives the boundary of sole proprietorship before the example is applied.
The word **Sole proprietorship** means a business owned, financed and run by one person who keeps all profit and bears all loss. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Sole Proprietorship is what sole proprietorship: meaning, features, strengths, limits and suitable fields changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Sole proprietorship: meaning, features, strengths, limits and suitable fields. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Sole Proprietorship is what formation of a sole proprietorship and why it survives beside large businesses changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Formation of a sole proprietorship and why it survives beside large businesses. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Sole Proprietorship.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Sole Proprietorship.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Sole Proprietorship.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Sole Proprietorship.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Sole Proprietorship.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Sole Proprietorship can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Comparing the Forms

> Comparing the Forms begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about comparing the forms. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Limited liability | the owner can lose only the money put into the business, and personal property stays safe
> The definition gives the boundary of limited liability before the example is applied.
The word **Limited liability** means the owner can lose only the money put into the business, and personal property stays safe. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Trade licence | official permission, given by a local authority, to carry on a particular business in a particular place
> The definition gives the boundary of trade licence before the example is applied.
The word **Trade licence** means official permission, given by a local authority, to carry on a particular business in a particular place. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Comparing the Forms is what a first comparison of the forms on owner, money, risk and control changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: A first comparison of the forms on owner, money, risk and control. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Comparing the Forms.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Comparing the Forms.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Comparing the Forms.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Comparing the Forms.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Comparing the Forms.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons is a sole proprietorship owned by Rafiq Uddin Mia, with a bank loan of Tk 60,000 taken on 1 March 2019. Position on 31 December 2019: assets Tk 400,000 (stock Tk 310,000 and other assets Tk 90,000); debts Tk 180,000 (owed to suppliers Tk 120,000 and to the bank Tk 60,000); the owner's own stake was therefore Tk 220,000 (400,000 - 180,000). The shop was closed for nine weeks in 2020. Position on 31 December 2020: assets Tk 380,000; debts Tk 430,000 (owed to suppliers Tk 370,000 and to the bank Tk 60,000); debts exceeded assets by Tk 50,000 (430,000 - 380,000). On 15 January 2021 Rafiq paid the Tk 50,000 shortfall from his personal savings. The shop's trade licence (illustrative number TL-2015-0417) was issued on 20 December 2014 and has been renewed each year.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Comparing the Forms can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

> The rule becomes more useful when the surrounding conditions are made explicit.

A business decision is affected by the setting in which it is made. The same form of ownership, resource choice, responsibility, or market arrangement can have different consequences when the people, law, money, or purpose changes. The reader should therefore state the relevant conditions before applying the rule. This is not an extra complication; it is part of using the definition accurately.

> A second test is to ask what the idea does not include.

Definitions are useful because they separate one idea from another. A supplier is not the same as an investor, a shareholder is not the same as a manager, and a business decision is not the same as its eventual result. When two terms appear together, ask what question each term answers. That question often reveals the boundary more quickly than memorising a longer description.

> The principle can also be viewed from different positions.

An owner may focus on control and risk. A manager may focus on workable procedures. An employee may focus on duties and conditions. A customer may focus on price, quality, and service. These viewpoints do not change the definition of a term. They help the reader see why the same business arrangement can matter to several groups at once.

> A final application should return to the evidence.

Before accepting a conclusion, identify the figures, dates, people, and decisions that support it. Then separate those facts from assumptions. If the evidence is incomplete, the conclusion should remain limited to what the evidence supports. This habit is especially important when a business case crosses different forms of ownership, institutions, countries, or periods.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons is a sole proprietorship owned by Rafiq Uddin Mia, with a bank loan of Tk 60,000 taken on 1 March 2019. Position on 31 December 2019: assets Tk 400,000 (stock Tk 310,000 and other assets Tk 90,000); debts Tk 180,000 (owed to suppliers Tk 120,000 and to the bank Tk 60,000); the owner's own stake was therefore Tk 220,000 (400,000 - 180,000). The shop was closed for nine weeks in 2020. Position on 31 December 2020: assets Tk 380,000; debts Tk 430,000 (owed to suppliers Tk 370,000 and to the bank Tk 60,000); debts exceeded assets by Tk 50,000 (430,000 - 380,000). On 15 January 2021 Rafiq paid the Tk 50,000 shortfall from his personal savings. The shop's trade licence (illustrative number TL-2015-0417) was issued on 20 December 2014 and has been renewed each year.


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 4.t1 | define liability and say how unlimited differs from limited liability, using one sum of your own

:q 4.t2 | list four features of a sole proprietorship

:q 4.t3 | give two fields where it suits and say why

:q 4.t4 | explain why it survives beside large businesses

:q 4.t5 | a tailor's assets are Tk 90,000 and her debts Tk 135,000, so say who must pay the gap under each kind of liability and what she might do

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
The failure of the City of Glasgow Bank in 1878, when shareholders with unlimited liability lost their homes and savings. Search hint: City of Glasgow Bank 1878 collapse unlimited liability shareholders.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 4.r1 | define liability and say how unlimited differs from limited liability, using one sum of your own

:q 4.r2 | list four features of a sole proprietorship

:q 4.r3 | give two fields where it suits and say why

:q 4.r4 | explain why it survives beside large businesses

:q 4.r5 | a tailor's assets are Tk 90,000 and her debts Tk 135,000, so say who must pay the gap under each kind of liability and what she might do

:pause 4.p1 | after the definition of unlimited liability, and after the passage on the legal person

:fig two balance-style drawings of one business whose debts exceed its assets, one showing the shortfall falling on the owner's home and savings, the other stopping at the business | ch04-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 3, 'Social Responsibility of Business', section 3.2 'Responsibility to Society, Suppliers and Investors' — the lender and supplier whose claims the owner must meet; Chapter 5, 'Partnership', section 5.1 'The Idea and Types of Partnership' — what changes when two or more people share the business. These references are reminders of where a related idea is developed; they do not introduce a new definition here.