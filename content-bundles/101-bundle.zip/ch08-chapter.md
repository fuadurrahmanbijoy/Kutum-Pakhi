:chapter VIII | State Enterprise
:mood How does the business idea become a workable decision?
:desc Teach what a state enterprise is, why governments run businesses, the forms they take, and why many struggle to make a profit. The chapter builds the idea from ordinary experience to business practice.
:plate ch08-plate.svg | a municipal waterworks pumping engine hall with an engineer at the controls, 1880s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 4, 'Ways to Own a Business, and the Sole Proprietor', section 4.1 'Why the Form of Ownership Matters'; Chapter 6, 'Joint Stock Company', section 6.1 'The Company and Its Shares'

## Meaning, Need and Importance

> Meaning, Need and Importance begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about meaning, need and importance. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ State enterprise | a business owned and run by the government, set up to serve the public or to earn money for the state
> The definition gives the boundary of state enterprise before the example is applied.
The word **State enterprise** means a business owned and run by the government, set up to serve the public or to earn money for the state. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Monopoly | a market in which only one seller supplies a good or service, so customers have no choice
> The definition gives the boundary of monopoly before the example is applied.
The word **Monopoly** means a market in which only one seller supplies a good or service, so customers have no choice. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Government company | a company, formed under company law, in which the government owns most or all of the shares
> The definition gives the boundary of government company before the example is applied.
The word **Government company** means a company, formed under company law, in which the government owns most or all of the shares. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Meaning, Need and Importance is what the state enterprise, the public sector and the reasons governments run businesses, including the fields where it fits changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The state enterprise, the public sector and the reasons governments run businesses, including the fields where it fits. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Meaning, Need and Importance is what nationalisation, monopoly and the case for and against state ownership changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Nationalisation, monopoly and the case for and against state ownership. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Meaning, Need and Importance.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Meaning, Need and Importance.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Meaning, Need and Importance.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Meaning, Need and Importance.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Meaning, Need and Importance.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. none


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Meaning, Need and Importance can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Forms of State Enterprise

> Forms of State Enterprise begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about forms of state enterprise. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Public sector | all the businesses and organisations that the government owns or controls
> The definition gives the boundary of public sector before the example is applied.
The word **Public sector** means all the businesses and organisations that the government owns or controls. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Departmental undertaking | a state business run as a part of a government office and funded from its budget
> The definition gives the boundary of departmental undertaking before the example is applied.
The word **Departmental undertaking** means a state business run as a part of a government office and funded from its budget. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Public utility | a service that everyone needs and that is hard to supply through competition, such as water or electricity
> The definition gives the boundary of public utility before the example is applied.
The word **Public utility** means a service that everyone needs and that is hard to supply through competition, such as water or electricity. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Forms of State Enterprise is what departmental undertaking, public corporation and government company compared changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Departmental undertaking, public corporation and government company compared. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Forms of State Enterprise is what public utilities and joint ventures with private businesses changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Public utilities and joint ventures with private businesses. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Forms of State Enterprise.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Forms of State Enterprise.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Forms of State Enterprise.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Forms of State Enterprise.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Forms of State Enterprise.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Forms of State Enterprise can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Performance and Reform

> Performance and Reform begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about performance and reform. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Nationalisation | the act of a government taking over a privately owned business and making it state property
> The definition gives the boundary of nationalisation before the example is applied.
The word **Nationalisation** means the act of a government taking over a privately owned business and making it state property. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Public corporation | a state business set up by a special law, with its own legal identity and some freedom to act
> The definition gives the boundary of public corporation before the example is applied.
The word **Public corporation** means a state business set up by a special law, with its own legal identity and some freedom to act. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Privatisation | the sale or handing over of a state enterprise to private owners
> The definition gives the boundary of privatisation before the example is applied.
The word **Privatisation** means the sale or handing over of a state enterprise to private owners. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Performance and Reform is what why state enterprises often lose money, and the remedies tried, including privatisation changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Why state enterprises often lose money, and the remedies tried, including privatisation. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Performance and Reform.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Performance and Reform.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Performance and Reform.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Performance and Reform.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Performance and Reform.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. none


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Performance and Reform can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

> The rule becomes more useful when the surrounding conditions are made explicit.

A business decision is affected by the setting in which it is made. The same form of ownership, resource choice, responsibility, or market arrangement can have different consequences when the people, law, money, or purpose changes. The reader should therefore state the relevant conditions before applying the rule. This is not an extra complication; it is part of using the definition accurately.

> A second test is to ask what the idea does not include.

Definitions are useful because they separate one idea from another. A supplier is not the same as an investor, a shareholder is not the same as a manager, and a business decision is not the same as its eventual result. When two terms appear together, ask what question each term answers. That question often reveals the boundary more quickly than memorising a longer description.

> The principle can also be viewed from different positions.

An owner may focus on control and risk. A manager may focus on workable procedures. An employee may focus on duties and conditions. A customer may focus on price, quality, and service. These viewpoints do not change the definition of a term. They help the reader see why the same business arrangement can matter to several groups at once.

> A final application should return to the evidence.

Before accepting a conclusion, identify the figures, dates, people, and decisions that support it. Then separate those facts from assumptions. If the evidence is incomplete, the conclusion should remain limited to what the evidence supports. This habit is especially important when a business case crosses different forms of ownership, institutions, countries, or periods.

> The reader can test the rule by changing one fact at a time.
If one amount, person, purpose, or condition changes, apply the same definition again. The result may stay the same or it may change. What matters is that the reader can identify the fact that caused the change and explain the connection rather than relying on the appearance of the example.
## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. none


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 8.t1 | define state enterprise and name two reasons a government runs a business

:q 8.t2 | compare the three forms on control, money and legal identity

:q 8.t3 | explain what a public utility is and why it is often state-run

:q 8.t4 | give two causes of loss in state enterprises and one remedy

:q 8.t5 | a government mill loses Tk 40 crore a year while employing 3,000 people, so set out the case for keeping it, the case for selling it, and a decision

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
The British Broadcasting Corporation, set up as a company in 1922 and made a public corporation under a Royal Charter on 1 January 1927. Search hint: BBC royal charter 1927 public corporation Reith.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 8.r1 | define state enterprise and name two reasons a government runs a business

:q 8.r2 | compare the three forms on control, money and legal identity

:q 8.r3 | explain what a public utility is and why it is often state-run

:q 8.r4 | give two causes of loss in state enterprises and one remedy

:q 8.r5 | a government mill loses Tk 40 crore a year while employing 3,000 people, so set out the case for keeping it, the case for selling it, and a decision

:pause 8.p1 | after the three forms are introduced, and after the causes of loss

:fig a tree with state enterprise at the top and three branches: run as a government office, set up as a public corporation, formed as a government-owned company | ch08-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 6, 'Joint Stock Company', section 6.1 'The Company and Its Shares' — a government company is a company in law; Chapter 7, 'Cooperative Societies', section 7.1 'The Idea and Principles of Cooperation' — another form that does not exist only for private profit. These references are reminders of where a related idea is developed; they do not introduce a new definition here.