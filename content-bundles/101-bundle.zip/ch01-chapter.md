:chapter I | What Business Is, Does and Aims For
:mood How does the business idea become a workable decision?
:desc Show a reader with no background what a business is, how trade, commerce and industry fit together, and why businesses exist; this is a foundation chapter that also teaches how to read the book. The chapter builds the idea from ordinary experience to business practice.
:plate ch01-plate.svg | a village market square with a stallholder weighing grain for a customer, 1860s

> Earlier ideas needed for this chapter are named before they are used.
You will need: nothing

## Needs, Wants and Exchange

> Needs, Wants and Exchange begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about needs, wants and exchange. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Need | something a person must have to live safely and in health, such as food, water, shelter and basic care
> The definition gives the boundary of need before the example is applied.
The word **Need** means something a person must have to live safely and in health, such as food, water, shelter and basic care. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Service | useful work done for another person that leaves nothing physical behind, such as teaching, carrying or repairing
> The definition gives the boundary of service before the example is applied.
The word **Service** means useful work done for another person that leaves nothing physical behind, such as teaching, carrying or repairing. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Trade | the buying and selling of goods, either to make a profit or to supply what others want
> The definition gives the boundary of trade before the example is applied.
The word **Trade** means the buying and selling of goods, either to make a profit or to supply what others want. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Needs, Wants and Exchange is what needs and wants, and why people must choose changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Needs and wants, and why people must choose. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Needs, Wants and Exchange is what exchange, and why people let others make things for them changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Exchange, and why people let others make things for them. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Needs, Wants and Exchange.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Needs, Wants and Exchange.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Needs, Wants and Exchange.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Needs, Wants and Exchange.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Needs, Wants and Exchange.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Base facts. Rafiq Uddin Mia opened Meghna and Sons, a bookshop in Dhaka, on 4 January 2015. Start-up money was Tk 158,000 of his own savings, used as follows: books for sale Tk 110,000 (500 textbooks bought at an average Tk 220 each); advance paid to the landlord Tk 30,000; shelves and counter Tk 12,000; cash in hand Tk 6,000 (110,000 + 30,000 + 12,000 + 6,000 = 158,000). Average selling price Tk 280 per book, so each book sold earns Tk 60 above its cost. Monthly shop rent Tk 9,000. In January 2015 the shop sold 180 books: sales Tk 50,400 (180 x 280); cost of the books sold Tk 39,600 (180 x 220); amount left above book cost Tk 10,800. After rent of Tk 9,000 the profit for the month was Tk 1,800. Unsold at 31 January 2015: 320 books with a cost of Tk 70,400 (320 x 220). Rafiq took no wage for himself that month.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Needs, Wants and Exchange can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## What a Business Is

> What a Business Is begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about what a business is. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Want | something a person would like to have but could live without, such as a new phone or a holiday
> The definition gives the boundary of want before the example is applied.
The word **Want** means something a person would like to have but could live without, such as a new phone or a holiday. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Business | an activity that supplies goods or services to customers in the hope of earning a profit
> The definition gives the boundary of business before the example is applied.
The word **Business** means an activity that supplies goods or services to customers in the hope of earning a profit. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Commerce | all the activities that help goods move from maker to user, including trade and the services that support it
> The definition gives the boundary of commerce before the example is applied.
The word **Commerce** means all the activities that help goods move from maker to user, including trade and the services that support it. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in What a Business Is is what business as the supply of goods and services for profit changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Business as the supply of goods and services for profit. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in What a Business Is is what profit and risk changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Profit and risk. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in What a Business Is.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in What a Business Is.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in What a Business Is.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in What a Business Is.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in What a Business Is.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* What a Business Is can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Trade, Commerce and Industry

> Trade, Commerce and Industry begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about trade, commerce and industry. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Exchange | giving one thing and receiving another in return, whether goods, services or money
> The definition gives the boundary of exchange before the example is applied.
The word **Exchange** means giving one thing and receiving another in return, whether goods, services or money. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Profit | the money left over when the costs of running a business are taken away from what it earns
> The definition gives the boundary of profit before the example is applied.
The word **Profit** means the money left over when the costs of running a business are taken away from what it earns. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Industry | the making or growing of goods, or the extraction of materials, by people who use skill, tools and effort
> The definition gives the boundary of industry before the example is applied.
The word **Industry** means the making or growing of goods, or the extraction of materials, by people who use skill, tools and effort. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Trade, Commerce and Industry is what trade, commerce and industry, and how they fit together changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Trade, commerce and industry, and how they fit together. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Trade, Commerce and Industry is what branches of business and the helping services, including selling online changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Branches of business and the helping services, including selling online. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Trade, Commerce and Industry.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Trade, Commerce and Industry.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Trade, Commerce and Industry.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Trade, Commerce and Industry.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Trade, Commerce and Industry.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Trade, Commerce and Industry can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Features, Functions and Aims of Business

> Features, Functions and Aims of Business begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about features, functions and aims of business. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Good | a physical item that can be touched and owned, such as a book, a chair or a bag of rice
> The definition gives the boundary of good before the example is applied.
The word **Good** means a physical item that can be touched and owned, such as a book, a chair or a bag of rice. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Risk | the chance that a business will earn less than it hoped, or lose money, because the future is uncertain
> The definition gives the boundary of risk before the example is applied.
The word **Risk** means the chance that a business will earn less than it hoped, or lose money, because the future is uncertain. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Features, Functions and Aims of Business is what scope, features, functions and aims of business, and the conditions that help it succeed changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Scope, features, functions and aims of business, and the conditions that help it succeed. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Features, Functions and Aims of Business.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Features, Functions and Aims of Business.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Features, Functions and Aims of Business.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Features, Functions and Aims of Business.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Features, Functions and Aims of Business.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Base facts. Rafiq Uddin Mia opened Meghna and Sons, a bookshop in Dhaka, on 4 January 2015. Start-up money was Tk 158,000 of his own savings, used as follows: books for sale Tk 110,000 (500 textbooks bought at an average Tk 220 each); advance paid to the landlord Tk 30,000; shelves and counter Tk 12,000; cash in hand Tk 6,000 (110,000 + 30,000 + 12,000 + 6,000 = 158,000). Average selling price Tk 280 per book, so each book sold earns Tk 60 above its cost. Monthly shop rent Tk 9,000. In January 2015 the shop sold 180 books: sales Tk 50,400 (180 x 280); cost of the books sold Tk 39,600 (180 x 220); amount left above book cost Tk 10,800. After rent of Tk 9,000 the profit for the month was Tk 1,800. Unsold at 31 January 2015: 320 books with a cost of Tk 70,400 (320 x 220). Rafiq took no wage for himself that month.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Features, Functions and Aims of Business can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Base facts. Rafiq Uddin Mia opened Meghna and Sons, a bookshop in Dhaka, on 4 January 2015. Start-up money was Tk 158,000 of his own savings, used as follows: books for sale Tk 110,000 (500 textbooks bought at an average Tk 220 each); advance paid to the landlord Tk 30,000; shelves and counter Tk 12,000; cash in hand Tk 6,000 (110,000 + 30,000 + 12,000 + 6,000 = 158,000). Average selling price Tk 280 per book, so each book sold earns Tk 60 above its cost. Monthly shop rent Tk 9,000. In January 2015 the shop sold 180 books: sales Tk 50,400 (180 x 280); cost of the books sold Tk 39,600 (180 x 220); amount left above book cost Tk 10,800. After rent of Tk 9,000 the profit for the month was Tk 1,800. Unsold at 31 January 2015: 320 books with a cost of Tk 70,400 (320 x 220). Rafiq took no wage for himself that month.


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 1.t1 | sort a student's week of spending into needs and wants and say why the sorting is hard

:q 1.t2 | explain exchange using two villagers who each make one thing

:q 1.t3 | name the branch of business for a printing press, a wholesaler and an insurer

:q 1.t4 | explain why money received and profit are different amounts

:q 1.t5 | a tea stall owner could earn more by selling only cold drinks, yet her neighbours rely on hot tea, so weigh profit against service and decide

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
Adam Smith, An Inquiry into the Nature and Causes of the Wealth of Nations, 1776: the pin-making example of workers who specialise and exchange. Search hint: Adam Smith pin factory 1776 division of labour.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 1.r1 | sort a student's week of spending into needs and wants and say why the sorting is hard

:q 1.r2 | explain exchange using two villagers who each make one thing

:q 1.r3 | name the branch of business for a printing press, a wholesaler and an insurer

:q 1.r4 | explain why money received and profit are different amounts

:q 1.r5 | a tea stall owner could earn more by selling only cold drinks, yet her neighbours rely on hot tea, so weigh profit against service and decide

:pause 1.p1 | after the passage on needs and wants, and after the passage separating trade, commerce and industry

:fig the chain from maker to trader to customer, with the helping services (transport, storage, banking, insurance, advertising) drawn beside it | ch01-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 2, 'Resources, Location and Environment', section 2.1 'The Factors of Production' — the resources that every business uses to make or sell; Chapter 12, 'Institutions and Business Combination', section 12.1 'Institutions That Promote Business' — bodies that support trade and industry. These references are reminders of where a related idea is developed; they do not introduce a new definition here.