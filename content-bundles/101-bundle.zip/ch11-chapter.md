:chapter XI | Multinational Corporations
:mood How does the business idea become a workable decision?
:desc Teach what a multinational corporation is, why firms become multinational, the three groups of staff such firms use, and the gains and problems for the countries that host them. The chapter builds the idea from ordinary experience to business practice.
:plate ch11-plate.svg | a large works with chimneys beside a railway and a steamship in dock, 1880s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 6, 'Joint Stock Company', section 6.1 'The Company and Its Shares'; Chapter 10, 'Foreign Trade: Measuring It and Doing It', section 10.1 'Why Nations Trade, and Why It Matters'

## What a Multinational Corporation Is

> What a Multinational Corporation Is begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about what a multinational corporation is. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Multinational corporation | a company that owns and runs business operations in two or more countries
> The definition gives the boundary of multinational corporation before the example is applied.
The word **Multinational corporation** means a company that owns and runs business operations in two or more countries. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Subsidiary | a company that is owned or controlled by another, larger company called the parent
> The definition gives the boundary of subsidiary before the example is applied.
The word **Subsidiary** means a company that is owned or controlled by another, larger company called the parent. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Third-country national | an employee of a multinational who comes from neither its home nor its host country
> The definition gives the boundary of third-country national before the example is applied.
The word **Third-country national** means an employee of a multinational who comes from neither its home nor its host country. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in What a Multinational Corporation Is is what the multinational corporation and the reasons firms set up in other countries changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The multinational corporation and the reasons firms set up in other countries. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in What a Multinational Corporation Is is what home country, host country and subsidiary changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Home country, host country and subsidiary. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in What a Multinational Corporation Is.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in What a Multinational Corporation Is.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in What a Multinational Corporation Is.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in What a Multinational Corporation Is.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in What a Multinational Corporation Is.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Case in this chapter is an illustrative multinational. Northwind Stationery plc (fictional) is headquartered in the United Kingdom and began operating through a subsidiary in Dhaka, Northwind Stationery Bangladesh Limited, on 5 May 2024. The parent invested US$ 1,000,000, Tk 120,000,000 at the illustration's assumed rate of Tk 120 a dollar (1,000,000 x 120). The subsidiary has 90 staff: 3 parent-country nationals from the United Kingdom, 2 third-country nationals from India, and 85 host-country nationals from Bangladesh (3 + 2 + 85 = 90). Host-country nationals are 94.4% of staff (85 / 90). From 1 September 2025 Meghna and Sons Limited has sold Northwind notebooks, and its purchases from the subsidiary between 1 September and 31 December 2025 were Tk 180,000.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* What a Multinational Corporation Is can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## People in a Multinational

> People in a Multinational begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about people in a multinational. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Home country | the country where a multinational has its headquarters and where its parent company is based
> The definition gives the boundary of home country before the example is applied.
The word **Home country** means the country where a multinational has its headquarters and where its parent company is based. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Parent-country national | an employee of a multinational who comes from the country of its headquarters
> The definition gives the boundary of parent-country national before the example is applied.
The word **Parent-country national** means an employee of a multinational who comes from the country of its headquarters. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Technology transfer | the passing of knowledge, machines and methods from one country or firm to another
> The definition gives the boundary of technology transfer before the example is applied.
The word **Technology transfer** means the passing of knowledge, machines and methods from one country or firm to another. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in People in a Multinational is what parent-country, host-country and third-country nationals in a multinational's staff changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Parent-country, host-country and third-country nationals in a multinational's staff. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in People in a Multinational.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in People in a Multinational.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in People in a Multinational.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in People in a Multinational.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in People in a Multinational.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* People in a Multinational can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Why Multinationals Matter, and Their Problems

> Why Multinationals Matter, and Their Problems begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about why multinationals matter, and their problems. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Host country | a country in which a multinational sets up a branch or subsidiary and operates
> The definition gives the boundary of host country before the example is applied.
The word **Host country** means a country in which a multinational sets up a branch or subsidiary and operates. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Host-country national | an employee of a multinational who comes from the country where it is operating
> The definition gives the boundary of host-country national before the example is applied.
The word **Host-country national** means an employee of a multinational who comes from the country where it is operating. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Why Multinationals Matter, and Their Problems is what the gains a multinational brings to a host country and the problems it can cause changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The gains a multinational brings to a host country and the problems it can cause. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Why Multinationals Matter, and Their Problems is what technology transfer and the way a country such as bangladesh deals with multinationals changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Technology transfer and the way a country such as Bangladesh deals with multinationals. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Why Multinationals Matter, and Their Problems.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Why Multinationals Matter, and Their Problems.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Why Multinationals Matter, and Their Problems.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Why Multinationals Matter, and Their Problems.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Why Multinationals Matter, and Their Problems.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Case in this chapter is an illustrative multinational. Northwind Stationery plc (fictional) is headquartered in the United Kingdom and began operating through a subsidiary in Dhaka, Northwind Stationery Bangladesh Limited, on 5 May 2024. The parent invested US$ 1,000,000, Tk 120,000,000 at the illustration's assumed rate of Tk 120 a dollar (1,000,000 x 120). The subsidiary has 90 staff: 3 parent-country nationals from the United Kingdom, 2 third-country nationals from India, and 85 host-country nationals from Bangladesh (3 + 2 + 85 = 90). Host-country nationals are 94.4% of staff (85 / 90). From 1 September 2025 Meghna and Sons Limited has sold Northwind notebooks, and its purchases from the subsidiary between 1 September and 31 December 2025 were Tk 180,000.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Why Multinationals Matter, and Their Problems can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

> The rule becomes more useful when the surrounding conditions are made explicit.

A business decision is affected by the setting in which it is made. The same form of ownership, resource choice, responsibility, or market arrangement can have different consequences when the people, law, money, or purpose changes. The reader should therefore state the relevant conditions before applying the rule. This is not an extra complication; it is part of using the definition accurately.

> A second test is to ask what the idea does not include.

Definitions are useful because they separate one idea from another. A supplier is not the same as an investor, a shareholder is not the same as a manager, and a business decision is not the same as its eventual result. When two terms appear together, ask what question each term answers. That question often reveals the boundary more quickly than memorising a longer description.

> The principle can also be viewed from different positions.

An owner may focus on control and risk. A manager may focus on workable procedures. An employee may focus on duties and conditions. A customer may focus on price, quality, and service. These viewpoints do not change the definition of a term. They help the reader see why the same business arrangement can matter to several groups at once.

> A final application should return to the evidence.

Before accepting a conclusion, identify the figures, dates, people, and decisions that support it. Then separate those facts from assumptions. If the evidence is incomplete, the conclusion should remain limited to what the evidence supports. This habit is especially important when a business case crosses different forms of ownership, institutions, countries, or periods.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Case in this chapter is an illustrative multinational. Northwind Stationery plc (fictional) is headquartered in the United Kingdom and began operating through a subsidiary in Dhaka, Northwind Stationery Bangladesh Limited, on 5 May 2024. The parent invested US$ 1,000,000, Tk 120,000,000 at the illustration's assumed rate of Tk 120 a dollar (1,000,000 x 120). The subsidiary has 90 staff: 3 parent-country nationals from the United Kingdom, 2 third-country nationals from India, and 85 host-country nationals from Bangladesh (3 + 2 + 85 = 90). Host-country nationals are 94.4% of staff (85 / 90). From 1 September 2025 Meghna and Sons Limited has sold Northwind notebooks, and its purchases from the subsidiary between 1 September and 31 December 2025 were Tk 180,000.


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 11.t1 | define multinational corporation and name three reasons a firm becomes one

:q 11.t2 | tell home country from host country with an example

:q 11.t3 | explain the three groups of staff and why a multinational mixes them

:q 11.t4 | list two gains and two problems for a host country

:q 11.t5 | a foreign factory will employ 400 local workers and train them, but may send most of its profit abroad and push local makers out, so weigh both sides and say what rules a government might set

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
The Singer Manufacturing Company's factory at Kilbowie, near Glasgow, Scotland, opened in 1867 as one of the first overseas factories of an American firm. Search hint: Singer Kilbowie factory 1867 Scotland first overseas.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 11.r1 | define multinational corporation and name three reasons a firm becomes one

:q 11.r2 | tell home country from host country with an example

:q 11.r3 | explain the three groups of staff and why a multinational mixes them

:q 11.r4 | list two gains and two problems for a host country

:q 11.r5 | a foreign factory will employ 400 local workers and train them, but may send most of its profit abroad and push local makers out, so weigh both sides and say what rules a government might set

:pause 11.p1 | after the three groups of staff, and after the gains and problems

:fig a parent company in its home country with a subsidiary in a host country, and three groups of staff labelled by their country of origin | ch11-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 10, 'Foreign Trade: Measuring It and Doing It', section 10.1 'Why Nations Trade, and Why It Matters' — the gains from trade that multinationals extend; Chapter 12, 'Institutions and Business Combination', section 12.2 'Zones, Export Bodies and Others' — zones that attract overseas investors. These references are reminders of where a related idea is developed; they do not introduce a new definition here.