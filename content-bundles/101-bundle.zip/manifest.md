:bundle
status: ok
failures: 0
chapters: 12
appendix: a1
changed-duplicates-resolved: 0
glossary-duplicates-removed: 0
chapter | ch01 | I | What Business Is, Does and Aims For | 3523 | 1 | 11 | 11
chapter | ch02 | II | Resources, Location and Environment | 3075 | 1 | 10 | 11
chapter | ch03 | III | Social Responsibility of Business | 2885 | 1 | 5 | 11
chapter | ch04 | IV | Ways to Own a Business, and the Sole Proprietor | 2900 | 1 | 6 | 11
chapter | ch05 | V | Partnership | 3092 | 1 | 8 | 11
chapter | ch06 | VI | Joint Stock Company | 3527 | 2 | 13 | 11
chapter | ch07 | VII | Cooperative Societies | 2860 | 1 | 9 | 11
chapter | ch08 | VIII | State Enterprise | 2704 | 1 | 9 | 11
chapter | ch09 | IX | The Share Market | 2863 | 1 | 9 | 11
chapter | ch10 | X | Foreign Trade: Measuring It and Doing It | 3820 | 2 | 13 | 13
chapter | ch11 | XI | Multinational Corporations | 2975 | 1 | 8 | 11
chapter | ch12 | XII | Institutions and Business Combination | 3340 | 1 | 9 | 11
chapter | a1 | A1 | Maths You Will Use | 701 | 0 | 3 | 0
