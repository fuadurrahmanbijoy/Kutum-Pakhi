:chapter V | Partnership
:mood How does the business idea become a workable decision?
:desc Teach what a partnership is, the kinds of partnership and partner, the duties between partners, and how a partnership ends. The chapter builds the idea from ordinary experience to business practice.
:plate ch05-plate.svg | two clerks sharing a double desk in a counting-house with ledgers and a ship model, 1890s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 4, 'Ways to Own a Business, and the Sole Proprietor', sections 4.1 'Why the Form of Ownership Matters' and 4.2 'Sole Proprietorship'

## The Idea and Types of Partnership

> The Idea and Types of Partnership begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about the idea and types of partnership. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Partnership | a business owned by two or more people who agree to run it together and share its profit
> The definition gives the boundary of partnership before the example is applied.
The word **Partnership** means a business owned by two or more people who agree to run it together and share its profit. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Partnership at will | a partnership with no fixed end date, which any partner can end by giving notice
> The definition gives the boundary of partnership at will before the example is applied.
The word **Partnership at will** means a partnership with no fixed end date, which any partner can end by giving notice. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Nominal partner | a person who lends their name to the business and takes no share, yet may still be answerable to outsiders
> The definition gives the boundary of nominal partner before the example is applied.
The word **Nominal partner** means a person who lends their name to the business and takes no share, yet may still be answerable to outsiders. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in The Idea and Types of Partnership is what partnership, the partnership deed and the base on which it rests changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Partnership, the partnership deed and the base on which it rests. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in The Idea and Types of Partnership is what kinds of partnership: by purpose and length, and by liability changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Kinds of partnership: by purpose and length, and by liability. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in The Idea and Types of Partnership.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in The Idea and Types of Partnership.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in The Idea and Types of Partnership.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in The Idea and Types of Partnership.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in The Idea and Types of Partnership.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. In 2020 Rafiq Uddin Mia met a Tk 50,000 shortfall from savings (Chapter 4). On 1 July 2021 Rafiq and his son Imran formed a partnership under a deed of that date. Capital: Rafiq Tk 400,000, Imran Tk 200,000, total Tk 600,000. Profit and loss are shared 2 : 1, the ratio of capital (400,000 : 200,000); both partners work full time. Profit for the year ended 30 June 2022 was Tk 360,000: Rafiq Tk 240,000 (360,000 x 2/3) and Imran Tk 120,000 (360,000 x 1/3). On 1 January 2023 Rafiq's second son Sohel joined as a sleeping partner with capital of Tk 200,000, taking total capital to Tk 800,000; profit is now shared 2 : 1 : 1. Profit for the year ended 31 December 2023 was Tk 480,000: Rafiq Tk 240,000 (480,000 x 2/4), Imran Tk 120,000 (480,000 x 1/4), Sohel Tk 120,000 (480,000 x 1/4). On 31 March 2024 the partners' capital, including profit left in the business, stood at Tk 1,200,000: Rafiq Tk 600,000, Imran Tk 300,000, Sohel Tk 300,000.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* The Idea and Types of Partnership can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Types of Partners and Their Duties

> Types of Partners and Their Duties begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about types of partners and their duties. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Partner | one of the people who own a partnership and share in its profit, loss and duties
> The definition gives the boundary of partner before the example is applied.
The word **Partner** means one of the people who own a partnership and share in its profit, loss and duties. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Active partner | a partner who takes a full part in running the business day to day
> The definition gives the boundary of active partner before the example is applied.
The word **Active partner** means a partner who takes a full part in running the business day to day. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Dissolution | the ending of the partnership between the partners, or of the whole business, with its affairs settled
> The definition gives the boundary of dissolution before the example is applied.
The word **Dissolution** means the ending of the partnership between the partners, or of the whole business, with its affairs settled. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Types of Partners and Their Duties is what active, sleeping and nominal partners, and the duties implied between partners changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Active, sleeping and nominal partners, and the duties implied between partners. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Types of Partners and Their Duties is what how profit and loss are shared when the deed is silent or specific changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: How profit and loss are shared when the deed is silent or specific. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Types of Partners and Their Duties.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Types of Partners and Their Duties.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Types of Partners and Their Duties.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Types of Partners and Their Duties.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Types of Partners and Their Duties.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Types of Partners and Their Duties can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Advantages, Disadvantages and Dissolution

> Advantages, Disadvantages and Dissolution begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about advantages, disadvantages and dissolution. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Partnership deed | the written agreement that sets out how partners share capital, profit, work and decisions
> The definition gives the boundary of partnership deed before the example is applied.
The word **Partnership deed** means the written agreement that sets out how partners share capital, profit, work and decisions. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Sleeping partner | a partner who puts in money and shares profit but takes no part in running the business
> The definition gives the boundary of sleeping partner before the example is applied.
The word **Sleeping partner** means a partner who puts in money and shares profit but takes no part in running the business. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Advantages, Disadvantages and Dissolution is what advantages and disadvantages of partnership, and how it differs from a sole proprietorship, ending with dissolution changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Advantages and disadvantages of partnership, and how it differs from a sole proprietorship, ending with dissolution. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Advantages, Disadvantages and Dissolution.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Advantages, Disadvantages and Dissolution.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Advantages, Disadvantages and Dissolution.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Advantages, Disadvantages and Dissolution.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Advantages, Disadvantages and Dissolution.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. In 2020 Rafiq Uddin Mia met a Tk 50,000 shortfall from savings (Chapter 4). On 1 July 2021 Rafiq and his son Imran formed a partnership under a deed of that date. Capital: Rafiq Tk 400,000, Imran Tk 200,000, total Tk 600,000. Profit and loss are shared 2 : 1, the ratio of capital (400,000 : 200,000); both partners work full time. Profit for the year ended 30 June 2022 was Tk 360,000: Rafiq Tk 240,000 (360,000 x 2/3) and Imran Tk 120,000 (360,000 x 1/3). On 1 January 2023 Rafiq's second son Sohel joined as a sleeping partner with capital of Tk 200,000, taking total capital to Tk 800,000; profit is now shared 2 : 1 : 1. Profit for the year ended 31 December 2023 was Tk 480,000: Rafiq Tk 240,000 (480,000 x 2/4), Imran Tk 120,000 (480,000 x 1/4), Sohel Tk 120,000 (480,000 x 1/4). On 31 March 2024 the partners' capital, including profit left in the business, stood at Tk 1,200,000: Rafiq Tk 600,000, Imran Tk 300,000, Sohel Tk 300,000.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Advantages, Disadvantages and Dissolution can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

> The reader can test the rule by changing one fact at a time.
If one amount, person, purpose, or condition changes, apply the same definition again. The result may stay the same or it may change. What matters is that the reader can identify the fact that caused the change and explain the connection rather than relying on the appearance of the example.
> The distinction is strongest when the terms are used consistently.
Use one term for one idea. When a related everyday word is available, keep the defined business term in place so that the reader can see exactly which rule is being applied. Consistent vocabulary makes comparisons easier and reduces confusion when several ideas appear in the same case.
> The partnership idea can be checked from the relationship between ownership and responsibility.

When more than one person owns a business, the reader should ask how the agreement allocates capital, work, profit, loss, decisions, and responsibility. A written agreement can make those arrangements explicit, while the legal form determines which consequences follow from the arrangement. The example is therefore read in two stages: first identify what the partners agreed, then apply the relevant rule.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. In 2020 Rafiq Uddin Mia met a Tk 50,000 shortfall from savings (Chapter 4). On 1 July 2021 Rafiq and his son Imran formed a partnership under a deed of that date. Capital: Rafiq Tk 400,000, Imran Tk 200,000, total Tk 600,000. Profit and loss are shared 2 : 1, the ratio of capital (400,000 : 200,000); both partners work full time. Profit for the year ended 30 June 2022 was Tk 360,000: Rafiq Tk 240,000 (360,000 x 2/3) and Imran Tk 120,000 (360,000 x 1/3). On 1 January 2023 Rafiq's second son Sohel joined as a sleeping partner with capital of Tk 200,000, taking total capital to Tk 800,000; profit is now shared 2 : 1 : 1. Profit for the year ended 31 December 2023 was Tk 480,000: Rafiq Tk 240,000 (480,000 x 2/4), Imran Tk 120,000 (480,000 x 1/4), Sohel Tk 120,000 (480,000 x 1/4). On 31 March 2024 the partners' capital, including profit left in the business, stood at Tk 1,200,000: Rafiq Tk 600,000, Imran Tk 300,000, Sohel Tk 300,000.


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 5.t1 | define partnership and name the base it rests on

:q 5.t2 | compare active, sleeping and nominal partners

:q 5.t3 | state three duties partners owe each other

:q 5.t4 | list the ways a partnership can end

:q 5.t5 | three partners put in Tk 300,000, Tk 200,000 and Tk 100,000 and earn Tk 180,000, so share the profit by capital and say what changes if the deed fixes equal shares

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
The partnership of Michael Marks and Thomas Spencer, formed in 1894 in Leeds, England, which grew into the retailer Marks and Spencer. Search hint: Marks and Spencer 1894 partnership Thomas Spencer.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 5.r1 | define partnership and name the base it rests on

:q 5.r2 | compare active, sleeping and nominal partners

:q 5.r3 | state three duties partners owe each other

:q 5.r4 | list the ways a partnership can end

:q 5.r5 | three partners put in Tk 300,000, Tk 200,000 and Tk 100,000 and earn Tk 180,000, so share the profit by capital and say what changes if the deed fixes equal shares

:pause 5.p1 | after the passage on sleeping partners, and after profit sharing

:fig how a year's profit is shared among three partners in the ratio of their capital, drawn as three hatched blocks with labels | ch05-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 4, 'Ways to Own a Business, and the Sole Proprietor', section 4.1 'Why the Form of Ownership Matters' — liability, which partners share; Chapter 6, 'Joint Stock Company', section 6.1 'The Company and Its Shares' — the next step when a partnership outgrows its form. These references are reminders of where a related idea is developed; they do not introduce a new definition here.