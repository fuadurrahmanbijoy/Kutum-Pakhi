:chapter IX | The Share Market
:mood How does the business idea become a workable decision?
:desc Teach the kinds of shares, how a company first offers shares to the public, and how stock exchanges, including the Dhaka Stock Exchange, let investors trade them. The chapter builds the idea from ordinary experience to business practice.
:plate ch09-plate.svg | a stock exchange floor with brokers and a large chalk board, 1880s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 6, 'Joint Stock Company', sections 6.1 'The Company and Its Shares', 6.2 'Private and Public Companies' and 6.3 'Forming a Company and Issuing a Prospectus'

## Shares and Their Kinds

> Shares and Their Kinds begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about shares and their kinds. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Ordinary share | a share whose holder votes at meetings and receives a dividend that rises and falls with the company's profit
> The definition gives the boundary of ordinary share before the example is applied.
The word **Ordinary share** means a share whose holder votes at meetings and receives a dividend that rises and falls with the company's profit. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Primary market | the part of the share market where a company sells new shares directly to investors for the first time
> The definition gives the boundary of primary market before the example is applied.
The word **Primary market** means the part of the share market where a company sells new shares directly to investors for the first time. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Stock exchange | an organised market with rules where approved members trade company shares and other securities
> The definition gives the boundary of stock exchange before the example is applied.
The word **Stock exchange** means an organised market with rules where approved members trade company shares and other securities. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Shares and Their Kinds is what ordinary and preference shares, and which kind suits which investor changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Ordinary and preference shares, and which kind suits which investor. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Shares and Their Kinds is what the share market, with its primary and secondary parts changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The share market, with its primary and secondary parts. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Shares and Their Kinds.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Shares and Their Kinds.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Shares and Their Kinds.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Shares and Their Kinds.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Shares and Their Kinds.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons Limited has 120,000 issued shares of Tk 10 and an authorised capital of Tk 2,000,000 (200,000 shares); Rafiq, Imran and Sohel hold 60,000, 30,000 and 30,000 shares. At a board meeting on 10 February 2026 the directors considered raising Tk 4,000,000 for a second shop through an initial public offering of 400,000 new shares at Tk 10 each (400,000 x 10). The offering would need authorised capital to rise to at least 520,000 shares (120,000 + 400,000), Tk 5,200,000, and the company to become a public company. After the offering the three founders' 120,000 shares would be 23.1% of 520,000 shares (120,000 / 520,000) and outside investors would hold 76.9%. The board noted the cost of the offering and the loss of control, and deferred the decision. Imran Rafiq was asked to prepare a cost estimate by 31 March 2026.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Shares and Their Kinds can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## The Initial Public Offering

> The Initial Public Offering begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about the initial public offering. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Preference share | a share whose holder is paid a fixed dividend before ordinary shareholders but usually has no vote
> The definition gives the boundary of preference share before the example is applied.
The word **Preference share** means a share whose holder is paid a fixed dividend before ordinary shareholders but usually has no vote. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Secondary market | the part of the share market where investors buy and sell shares that already exist
> The definition gives the boundary of secondary market before the example is applied.
The word **Secondary market** means the part of the share market where investors buy and sell shares that already exist. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Broker | a licensed person or firm that buys and sells shares for clients and earns a fee
> The definition gives the boundary of broker before the example is applied.
The word **Broker** means a licensed person or firm that buys and sells shares for clients and earns a fee. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in The Initial Public Offering is what the initial public offering and the steps that lead to it changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The initial public offering and the steps that lead to it. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in The Initial Public Offering.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in The Initial Public Offering.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in The Initial Public Offering.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in The Initial Public Offering.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in The Initial Public Offering.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* The Initial Public Offering can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Stock Exchanges and the Dhaka Stock Exchange

> Stock Exchanges and the Dhaka Stock Exchange begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about stock exchanges and the dhaka stock exchange. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Share market | the whole system of buying and selling shares, both when they are first issued and afterwards
> The definition gives the boundary of share market before the example is applied.
The word **Share market** means the whole system of buying and selling shares, both when they are first issued and afterwards. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Initial public offering | the first time a company invites the public to buy its shares
> The definition gives the boundary of initial public offering before the example is applied.
The word **Initial public offering** means the first time a company invites the public to buy its shares. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Share price index | a single number that shows how the prices of a chosen group of shares have moved together
> The definition gives the boundary of share price index before the example is applied.
The word **Share price index** means a single number that shows how the prices of a chosen group of shares have moved together. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Stock Exchanges and the Dhaka Stock Exchange is what the stock exchange and the functions of the dhaka stock exchange changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The stock exchange and the functions of the Dhaka Stock Exchange. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Stock Exchanges and the Dhaka Stock Exchange is what brokers, share price indices and the regulator's role changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Brokers, share price indices and the regulator's role. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Stock Exchanges and the Dhaka Stock Exchange.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Stock Exchanges and the Dhaka Stock Exchange.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Stock Exchanges and the Dhaka Stock Exchange.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Stock Exchanges and the Dhaka Stock Exchange.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Stock Exchanges and the Dhaka Stock Exchange.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons Limited has 120,000 issued shares of Tk 10 and an authorised capital of Tk 2,000,000 (200,000 shares); Rafiq, Imran and Sohel hold 60,000, 30,000 and 30,000 shares. At a board meeting on 10 February 2026 the directors considered raising Tk 4,000,000 for a second shop through an initial public offering of 400,000 new shares at Tk 10 each (400,000 x 10). The offering would need authorised capital to rise to at least 520,000 shares (120,000 + 400,000), Tk 5,200,000, and the company to become a public company. After the offering the three founders' 120,000 shares would be 23.1% of 520,000 shares (120,000 / 520,000) and outside investors would hold 76.9%. The board noted the cost of the offering and the loss of control, and deferred the decision. Imran Rafiq was asked to prepare a cost estimate by 31 March 2026.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Stock Exchanges and the Dhaka Stock Exchange can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons Limited has 120,000 issued shares of Tk 10 and an authorised capital of Tk 2,000,000 (200,000 shares); Rafiq, Imran and Sohel hold 60,000, 30,000 and 30,000 shares. At a board meeting on 10 February 2026 the directors considered raising Tk 4,000,000 for a second shop through an initial public offering of 400,000 new shares at Tk 10 each (400,000 x 10). The offering would need authorised capital to rise to at least 520,000 shares (120,000 + 400,000), Tk 5,200,000, and the company to become a public company. After the offering the three founders' 120,000 shares would be 23.1% of 520,000 shares (120,000 / 520,000) and outside investors would hold 76.9%. The board noted the cost of the offering and the loss of control, and deferred the decision. Imran Rafiq was asked to prepare a cost estimate by 31 March 2026.


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 9.t1 | tell ordinary from preference shares on vote, dividend and risk

:q 9.t2 | separate the primary from the secondary market with an example of each

:q 9.t3 | describe the steps by which a company offers shares to the public

:q 9.t4 | list the main functions of a stock exchange

:q 9.t5 | an investor has Tk 100,000, wants steady income and dislikes risk, so choose between the two kinds of share and explain

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
The Buttonwood Agreement signed by 24 brokers in New York on 17 May 1792, which began the organised trading that became the New York Stock Exchange. Search hint: Buttonwood Agreement 1792 New York brokers.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 9.r1 | tell ordinary from preference shares on vote, dividend and risk

:q 9.r2 | separate the primary from the secondary market with an example of each

:q 9.r3 | describe the steps by which a company offers shares to the public

:q 9.r4 | list the main functions of a stock exchange

:q 9.r5 | an investor has Tk 100,000, wants steady income and dislikes risk, so choose between the two kinds of share and explain

:pause 9.p1 | after the two kinds of share, and after the split between the primary and secondary markets

:fig companies selling shares to investors in the primary market (left), and investors trading among themselves through brokers on the stock exchange in the secondary market (right) | ch09-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 6, 'Joint Stock Company', section 6.3 'Forming a Company and Issuing a Prospectus' — the prospectus a public company issues; Chapter 12, 'Institutions and Business Combination', section 12.1 'Institutions That Promote Business' — the regulator of the share market. These references are reminders of where a related idea is developed; they do not introduce a new definition here.