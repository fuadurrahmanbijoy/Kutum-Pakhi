:chapter A1 | Maths You Will Use

## A1.1 | Percentages and percentage change

> Percentages express a part in relation to one hundred.
@ Percentage | a part expressed out of one hundred
The term **Percentage** means a part expressed out of one hundred. If 25 of 100 books are sold, the percentage sold is 25%.

> Percentage change compares a new amount with an earlier amount.
Percentage change is found by taking the change, dividing by the original amount, and multiplying by 100. If sales rise from 200 to 250, the change is 50 and the percentage change is 50 ÷ 200 × 100 = 25%.

## A1.2 | Ratios and averages

> Ratios compare quantities by showing their relative sizes.
@ Ratio | a comparison of two quantities using division
The term **Ratio** means a comparison of two quantities using division. If a business has 4 workers and 2 supervisors, the ratio of workers to supervisors is 4 : 2, which can be simplified to 2 : 1.

> An average gives one representative value for a group of quantities.
@ Average | a value found by combining quantities and dividing by their number
The term **Average** means a value found by combining quantities and dividing by their number. For 10, 20 and 30, the average is (10 + 20 + 30) ÷ 3 = 20.

## A1.3 | Rearranging an equation and rounding

> An equation can be rearranged by performing the same operation on both sides.
If sales = price × quantity, then quantity = sales ÷ price. For sales of Tk 600 and a price of Tk 20, quantity = 600 ÷ 20 = 30.

> Rounding should be done only at the requested level of accuracy.
If a calculation gives 1,666.666..., rounded to the nearest taka it becomes Tk 1,667. Keep extra figures during intermediate steps when rounding early would change the final result.

## A1.4 | Reading a graph

> A graph shows a relationship visually, so first identify its axes and units.
The horizontal axis normally shows the independent quantity and the vertical axis shows the quantity being measured. A point on the graph represents one pair of values. A rising line means the vertical measure increases as the horizontal measure increases.

> A graph must be read from its scale, labels and plotted values rather than from appearance alone.
Check the units on both axes, locate the relevant point, and compare points using the same scale. If the graph begins above zero, do not treat the visible height as the amount itself without reading the axis labels.

> This is a reference check for applying the numerical rule safely.

When using any calculation in the book, write the given figures first, identify what is required, choose the operation, show each arithmetic step, state the answer with units, and make a quick check. These habits reduce errors caused by mixed units, wrong bases for percentage change, reversed ratios, early rounding, or misread graph scales. 

> This is a reference check for applying the numerical rule safely.

When using any calculation in the book, write the given figures first, identify what is required, choose the operation, show each arithmetic step, state the answer with units, and make a quick check. These habits reduce errors caused by mixed units, wrong bases for percentage change, reversed ratios, early rounding, or misread graph scales. 

> This is a reference check for applying the numerical rule safely.

When using any calculation in the book, write the given figures first, identify what is required, choose the operation, show each arithmetic step, state the answer with units, and make a quick check. These habits reduce errors caused by mixed units, wrong bases for percentage change, reversed ratios, early rounding, or misread graph scales. 

> This is a reference check for applying the numerical rule safely.

When using any calculation in the book, write the given figures first, identify what is required, choose the operation, show each arithmetic step, state the answer with units, and make a quick check. These habits reduce errors caused by mixed units, wrong bases for percentage change, reversed ratios, early rounding, or misread graph scales. 

> This is a reference check for applying the numerical rule safely.

When using any calculation in the book, write the given figures first, identify what is required, choose the operation, show each arithmetic step, state the answer with units, and make a quick check. These habits reduce errors caused by mixed units, wrong bases for percentage change, reversed ratios, early rounding, or misread graph scales. 

> This is a reference check for applying the numerical rule safely.

When using any calculation in the book, write the given figures first, identify what is required, choose the operation, show each arithmetic step, state the answer with units, and make a quick check. These habits reduce errors caused by mixed units, wrong bases for percentage change, reversed ratios, early rounding, or misread graph scales. 

> This is a reference check for applying the numerical rule safely.

When using any calculation in the book, write the given figures first, identify what is required, choose the operation, show each arithmetic step, state the answer with units, and make a quick check. These habits reduce errors caused by mixed units, wrong bases for percentage change, reversed ratios, early rounding, or misread graph scales. 

> This is a reference check for applying the numerical rule safely.

When using any calculation in the book, write the given figures first, identify what is required, choose the operation, show each arithmetic step, state the answer with units, and make a quick check. These habits reduce errors caused by mixed units, wrong bases for percentage change, reversed ratios, early rounding, or misread graph scales. 

