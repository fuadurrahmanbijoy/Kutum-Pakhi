:chapter X | Foreign Trade: Measuring It and Doing It
:mood How does the business idea become a workable decision?
:desc Explain why nations trade, how trade between nations is measured, and how an export or import is carried out, with the documents and barriers involved. The chapter builds the idea from ordinary experience to business practice.
:plate ch10-plate.svg | a quay with cranes loading crates onto a sailing ship, a customs officer beside the gangway, 1870s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 1, 'What Business Is, Does and Aims For', section 1.3 'Trade, Commerce and Industry'; Chapter 2, 'Resources, Location and Environment', section 2.1 'The Factors of Production'

## Why Nations Trade, and Why It Matters

> Why Nations Trade, and Why It Matters begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about why nations trade, and why it matters. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Foreign trade | the buying and selling of goods and services between people or businesses in different countries
> The definition gives the boundary of foreign trade before the example is applied.
The word **Foreign trade** means the buying and selling of goods and services between people or businesses in different countries. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Visible trade | trade in goods that can be seen and counted at a port, such as books, cloth and machines
> The definition gives the boundary of visible trade before the example is applied.
The word **Visible trade** means trade in goods that can be seen and counted at a port, such as books, cloth and machines. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Letter of credit | a bank's written promise to pay the exporter once agreed documents are shown
> The definition gives the boundary of letter of credit before the example is applied.
The word **Letter of credit** means a bank's written promise to pay the exporter once agreed documents are shown. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Non-tariff barrier | a rule or practice other than a tax that makes it harder to trade, such as a quota or a quality test
> The definition gives the boundary of non-tariff barrier before the example is applied.
The word **Non-tariff barrier** means a rule or practice other than a tax that makes it harder to trade, such as a quota or a quality test. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Why Nations Trade, and Why It Matters is what why nations trade: differences in resources and comparative advantage changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Why nations trade: differences in resources and comparative advantage. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Why Nations Trade, and Why It Matters is what the importance of foreign trade to a country such as bangladesh changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The importance of foreign trade to a country such as Bangladesh. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Why Nations Trade, and Why It Matters.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Why Nations Trade, and Why It Matters.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Why Nations Trade, and Why It Matters.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Why Nations Trade, and Why It Matters.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Why Nations Trade, and Why It Matters.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons Limited is a company (since 1 April 2024). The figures here use an assumed rate of Tk 120 for one US dollar, chosen only for this illustration. Import: on 3 March 2025 the company opened a letter of credit for 1,500 English-language books from a publisher in the United Kingdom, invoice value US$ 6,000 (Tk 720,000: 6,000 x 120). The goods were shipped on 28 March 2025 under a bill of lading of that date and reached Chattogram on 29 April 2025. Customs duty and taxes were Tk 108,000 (15% of 720,000) and the bank's charges on the letter of credit were Tk 7,200 (1% of 720,000). Landed cost Tk 835,200 (720,000 + 108,000 + 7,200), which is Tk 556.80 a book (835,200 / 1,500). Export: in 2025 the company also sold 200 Bangla books to a bookseller in London, invoice value US$ 2,000 (Tk 240,000: 2,000 x 120). Balance of trade for the company's goods: 240,000 - 720,000 = minus Tk 480,000, a deficit. Invisible trade: marine insurance paid to a foreign insurer US$ 150 (Tk 18,000: 150 x 120), so goods and services together show a deficit of Tk 498,000 (480,000 + 18,000).


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Why Nations Trade, and Why It Matters can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Measuring Trade Between Nations

> Measuring Trade Between Nations begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about measuring trade between nations. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Export | a good or service sold to a buyer in another country
> The definition gives the boundary of export before the example is applied.
The word **Export** means a good or service sold to a buyer in another country. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Invisible trade | trade in services, such as shipping, insurance and tourism, that cannot be seen at a port
> The definition gives the boundary of invisible trade before the example is applied.
The word **Invisible trade** means trade in services, such as shipping, insurance and tourism, that cannot be seen at a port. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Bill of lading | a receipt and contract issued by a shipping company for goods it has accepted for carriage
> The definition gives the boundary of bill of lading before the example is applied.
The word **Bill of lading** means a receipt and contract issued by a shipping company for goods it has accepted for carriage. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Measuring Trade Between Nations is what visible and invisible trade, the balance of trade and the balance of payments changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Visible and invisible trade, the balance of trade and the balance of payments. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Measuring Trade Between Nations is what reading a surplus or a deficit changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Reading a surplus or a deficit. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Measuring Trade Between Nations.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Measuring Trade Between Nations.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Measuring Trade Between Nations.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Measuring Trade Between Nations.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Measuring Trade Between Nations.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Measuring Trade Between Nations can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Export and Import Procedure and Documents

> Export and Import Procedure and Documents begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about export and import procedure and documents. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Import | a good or service bought from a seller in another country
> The definition gives the boundary of import before the example is applied.
The word **Import** means a good or service bought from a seller in another country. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Balance of trade | the value of a country's visible exports minus the value of its visible imports
> The definition gives the boundary of balance of trade before the example is applied.
The word **Balance of trade** means the value of a country's visible exports minus the value of its visible imports. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Charter party | the contract by which the owner of a ship hires the whole ship, or part of it, to another business
> The definition gives the boundary of charter party before the example is applied.
The word **Charter party** means the contract by which the owner of a ship hires the whole ship, or part of it, to another business. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Export and Import Procedure and Documents is what the export and import procedure from first enquiry to payment and customs clearance changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The export and import procedure from first enquiry to payment and customs clearance. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Export and Import Procedure and Documents is what the main documents in foreign trade, including the bill of lading and the charter party changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The main documents in foreign trade, including the bill of lading and the charter party. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Export and Import Procedure and Documents.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Export and Import Procedure and Documents.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Export and Import Procedure and Documents.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Export and Import Procedure and Documents.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Export and Import Procedure and Documents.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Export and Import Procedure and Documents can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Barriers to Export Trade

> Barriers to Export Trade begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about barriers to export trade. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Comparative advantage | a country's ability to make a good at a lower sacrifice of other goods than another country can
> The definition gives the boundary of comparative advantage before the example is applied.
The word **Comparative advantage** means a country's ability to make a good at a lower sacrifice of other goods than another country can. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Balance of payments | the full record of money flowing into and out of a country over a period for all kinds of dealings
> The definition gives the boundary of balance of payments before the example is applied.
The word **Balance of payments** means the full record of money flowing into and out of a country over a period for all kinds of dealings. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Customs duty | a tax charged on goods when they cross a national border
> The definition gives the boundary of customs duty before the example is applied.
The word **Customs duty** means a tax charged on goods when they cross a national border. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Barriers to Export Trade is what barriers to export trade in bangladesh, and tariff and non-tariff barriers changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Barriers to export trade in Bangladesh, and tariff and non-tariff barriers. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Barriers to Export Trade.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Barriers to Export Trade.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Barriers to Export Trade.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Barriers to Export Trade.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Barriers to Export Trade.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons Limited is a company (since 1 April 2024). The figures here use an assumed rate of Tk 120 for one US dollar, chosen only for this illustration. Import: on 3 March 2025 the company opened a letter of credit for 1,500 English-language books from a publisher in the United Kingdom, invoice value US$ 6,000 (Tk 720,000: 6,000 x 120). The goods were shipped on 28 March 2025 under a bill of lading of that date and reached Chattogram on 29 April 2025. Customs duty and taxes were Tk 108,000 (15% of 720,000) and the bank's charges on the letter of credit were Tk 7,200 (1% of 720,000). Landed cost Tk 835,200 (720,000 + 108,000 + 7,200), which is Tk 556.80 a book (835,200 / 1,500). Export: in 2025 the company also sold 200 Bangla books to a bookseller in London, invoice value US$ 2,000 (Tk 240,000: 2,000 x 120). Balance of trade for the company's goods: 240,000 - 720,000 = minus Tk 480,000, a deficit. Invisible trade: marine insurance paid to a foreign insurer US$ 150 (Tk 18,000: 150 x 120), so goods and services together show a deficit of Tk 498,000 (480,000 + 18,000).


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Barriers to Export Trade can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons Limited is a company (since 1 April 2024). The figures here use an assumed rate of Tk 120 for one US dollar, chosen only for this illustration. Import: on 3 March 2025 the company opened a letter of credit for 1,500 English-language books from a publisher in the United Kingdom, invoice value US$ 6,000 (Tk 720,000: 6,000 x 120). The goods were shipped on 28 March 2025 under a bill of lading of that date and reached Chattogram on 29 April 2025. Customs duty and taxes were Tk 108,000 (15% of 720,000) and the bank's charges on the letter of credit were Tk 7,200 (1% of 720,000). Landed cost Tk 835,200 (720,000 + 108,000 + 7,200), which is Tk 556.80 a book (835,200 / 1,500). Export: in 2025 the company also sold 200 Bangla books to a bookseller in London, invoice value US$ 2,000 (Tk 240,000: 2,000 x 120). Balance of trade for the company's goods: 240,000 - 720,000 = minus Tk 480,000, a deficit. Invisible trade: marine insurance paid to a foreign insurer US$ 150 (Tk 18,000: 150 x 120), so goods and services together show a deficit of Tk 498,000 (480,000 + 18,000).


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 10.t1 | explain comparative advantage with a pair of goods of your own

:q 10.t2 | separate visible from invisible trade with two examples of each

:q 10.t3 | list the steps of an export in order

:q 10.t4 | name five documents used in foreign trade and say what each does

:q 10.t5 | a country sells goods worth 48 billion and buys goods worth 61 billion, so find the balance of trade and say if it is a surplus or deficit

:q 10.t6 | a country has a deficit in goods but earns much from workers abroad, so say what the balance of payments might show and why

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
David Ricardo's example of cloth and wine traded between England and Portugal in On the Principles of Political Economy and Taxation, 1817. Search hint: Ricardo 1817 comparative advantage wine cloth Portugal.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Sources

> These sources support the historical or defining material used in the chapter.
:read The historical case named in this chapter, institutional or primary record, year
:read A standard reference on the chapter's subject, author and title, year

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 10.r1 | explain comparative advantage with a pair of goods of your own

:q 10.r2 | separate visible from invisible trade with two examples of each

:q 10.r3 | list the steps of an export in order

:q 10.r4 | name five documents used in foreign trade and say what each does

:q 10.r5 | a country sells goods worth 48 billion and buys goods worth 61 billion, so find the balance of trade and say if it is a surplus or deficit

:q 10.r6 | a country has a deficit in goods but earns much from workers abroad, so say what the balance of payments might show and why

:pause 10.p1 | after comparative advantage, and after the worked deficit

:fig the steps of an export in order, from enquiry and order through letter of credit and shipment to payment, drawn as numbered boxes | ch10-fig01.svg

:fig two hatched columns, exports and imports, with the gap between them labelled as the balance of trade | ch10-fig02.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 11, 'Multinational Corporations', section 11.1 'What a Multinational Corporation Is' — firms that operate in several countries; Chapter 12, 'Institutions and Business Combination', section 12.2 'Zones, Export Bodies and Others' — bodies that help exporters. These references are reminders of where a related idea is developed; they do not introduce a new definition here.