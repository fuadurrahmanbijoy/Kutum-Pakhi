:chapter III | Social Responsibility of Business
:mood How does the business idea become a workable decision?
:desc Explain why a business owes duties beyond profit, to whom it owes them, and how a reader can recognise a responsible business. The chapter builds the idea from ordinary experience to business practice.
:plate ch03-plate.svg | a mill-owner's committee inspecting a workers' school and reading room, 1880s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 1, 'What Business Is, Does and Aims For', section 1.4 'Features, Functions and Aims of Business'; Chapter 2, 'Resources, Location and Environment', section 2.3 'The Business Environment'

## Meaning and Importance of Responsibility

> Meaning and Importance of Responsibility begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about meaning and importance of responsibility. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Social responsibility | the duty of a business to act in ways that benefit society as well as itself
> The definition gives the boundary of social responsibility before the example is applied.
The word **Social responsibility** means the duty of a business to act in ways that benefit society as well as itself. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Investor | a person or organisation that puts money into a business in the hope of getting more money back
> The definition gives the boundary of investor before the example is applied.
The word **Investor** means a person or organisation that puts money into a business in the hope of getting more money back. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Meaning and Importance of Responsibility is what social responsibility and the reasons it matters, including how it fits with the aim of profit changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Social responsibility and the reasons it matters, including how it fits with the aim of profit. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Meaning and Importance of Responsibility is what stakeholders and the idea of duties to each changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Stakeholders and the idea of duties to each. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Meaning and Importance of Responsibility.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Meaning and Importance of Responsibility.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Meaning and Importance of Responsibility.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Meaning and Importance of Responsibility.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Meaning and Importance of Responsibility.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. In 2019 Meghna and Sons had average monthly sales of Tk 190,000, so annual sales were Tk 2,280,000 (190,000 x 12). The helper, Mahbub, earned Tk 8,000 a month and received a festival bonus of one month's wage at each of two festivals, Tk 16,000 in the year (8,000 x 2). The shop paid its main supplier, a publisher called Alo Prokashoni (illustrative), within the agreed 45 days; the invoice of Tk 84,000 dated 1 June 2019 was paid on 15 July 2019, on day 44. On 1 March 2019 Rafiq Uddin Mia borrowed Tk 60,000 from a bank at 10% a year, so yearly interest was Tk 6,000. On 10 December 2019 the shop gave 1% of the year's sales, Tk 22,800 (2,280,000 x 1/100), to the library of a primary school. The shop has no outside investor; the bank is its only lender.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Meaning and Importance of Responsibility can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Responsibility to Society, Suppliers and Investors

> Responsibility to Society, Suppliers and Investors begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about responsibility to society, suppliers and investors. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Stakeholder | any person or group affected by a business or able to affect it, such as customers or neighbours
> The definition gives the boundary of stakeholder before the example is applied.
The word **Stakeholder** means any person or group affected by a business or able to affect it, such as customers or neighbours. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Business ethics | the standards of right and wrong that guide how a business treats people and makes decisions
> The definition gives the boundary of business ethics before the example is applied.
The word **Business ethics** means the standards of right and wrong that guide how a business treats people and makes decisions. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Responsibility to Society, Suppliers and Investors is what duties to society, suppliers and investors changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Duties to society, suppliers and investors. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Responsibility to Society, Suppliers and Investors is what business ethics in everyday decisions changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Business ethics in everyday decisions. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Responsibility to Society, Suppliers and Investors.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Responsibility to Society, Suppliers and Investors.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Responsibility to Society, Suppliers and Investors.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Responsibility to Society, Suppliers and Investors.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Responsibility to Society, Suppliers and Investors.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Responsibility to Society, Suppliers and Investors can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Recognising a Responsible Organisation

> Recognising a Responsible Organisation begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about recognising a responsible organisation. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Supplier | a person or business that sells the goods, materials or services that another business needs
> The definition gives the boundary of supplier before the example is applied.
The word **Supplier** means a person or business that sells the goods, materials or services that another business needs. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Recognising a Responsible Organisation is what signs that a business is acting responsibly changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Signs that a business is acting responsibly. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Recognising a Responsible Organisation.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Recognising a Responsible Organisation.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Recognising a Responsible Organisation.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Recognising a Responsible Organisation.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Recognising a Responsible Organisation.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. In 2019 Meghna and Sons had average monthly sales of Tk 190,000, so annual sales were Tk 2,280,000 (190,000 x 12). The helper, Mahbub, earned Tk 8,000 a month and received a festival bonus of one month's wage at each of two festivals, Tk 16,000 in the year (8,000 x 2). The shop paid its main supplier, a publisher called Alo Prokashoni (illustrative), within the agreed 45 days; the invoice of Tk 84,000 dated 1 June 2019 was paid on 15 July 2019, on day 44. On 1 March 2019 Rafiq Uddin Mia borrowed Tk 60,000 from a bank at 10% a year, so yearly interest was Tk 6,000. On 10 December 2019 the shop gave 1% of the year's sales, Tk 22,800 (2,280,000 x 1/100), to the library of a primary school. The shop has no outside investor; the bank is its only lender.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Recognising a Responsible Organisation can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

> The rule becomes more useful when the surrounding conditions are made explicit.

A business decision is affected by the setting in which it is made. The same form of ownership, resource choice, responsibility, or market arrangement can have different consequences when the people, law, money, or purpose changes. The reader should therefore state the relevant conditions before applying the rule. This is not an extra complication; it is part of using the definition accurately.

> A second test is to ask what the idea does not include.

Definitions are useful because they separate one idea from another. A supplier is not the same as an investor, a shareholder is not the same as a manager, and a business decision is not the same as its eventual result. When two terms appear together, ask what question each term answers. That question often reveals the boundary more quickly than memorising a longer description.

> The principle can also be viewed from different positions.

An owner may focus on control and risk. A manager may focus on workable procedures. An employee may focus on duties and conditions. A customer may focus on price, quality, and service. These viewpoints do not change the definition of a term. They help the reader see why the same business arrangement can matter to several groups at once.

> A final application should return to the evidence.

Before accepting a conclusion, identify the figures, dates, people, and decisions that support it. Then separate those facts from assumptions. If the evidence is incomplete, the conclusion should remain limited to what the evidence supports. This habit is especially important when a business case crosses different forms of ownership, institutions, countries, or periods.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. In 2019 Meghna and Sons had average monthly sales of Tk 190,000, so annual sales were Tk 2,280,000 (190,000 x 12). The helper, Mahbub, earned Tk 8,000 a month and received a festival bonus of one month's wage at each of two festivals, Tk 16,000 in the year (8,000 x 2). The shop paid its main supplier, a publisher called Alo Prokashoni (illustrative), within the agreed 45 days; the invoice of Tk 84,000 dated 1 June 2019 was paid on 15 July 2019, on day 44. On 1 March 2019 Rafiq Uddin Mia borrowed Tk 60,000 from a bank at 10% a year, so yearly interest was Tk 6,000. On 10 December 2019 the shop gave 1% of the year's sales, Tk 22,800 (2,280,000 x 1/100), to the library of a primary school. The shop has no outside investor; the bank is its only lender.


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 3.t1 | say in your own words what social responsibility means and give two reasons it matters

:q 3.t2 | name five stakeholders of a restaurant and the duty owed to each

:q 3.t3 | explain what a business owes a supplier and what it owes an investor

:q 3.t4 | list three signs of a responsible business

:q 3.t5 | a printer offers books at 12% less, but its workers have no safety equipment, so weigh cost against duty and give a decision with reasons

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
The collapse of the Rana Plaza building at Savar, Bangladesh, on 24 April 2013, and the building and fire safety agreement signed by buyers and unions in May 2013. Search hint: Rana Plaza collapse 2013 Accord on Fire and Building Safety.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 3.r1 | say in your own words what social responsibility means and give two reasons it matters

:q 3.r2 | name five stakeholders of a restaurant and the duty owed to each

:q 3.r3 | explain what a business owes a supplier and what it owes an investor

:q 3.r4 | list three signs of a responsible business

:q 3.r5 | a printer offers books at 12% less, but its workers have no safety equipment, so weigh cost against duty and give a decision with reasons

:pause 3.p1 | after the definition of stakeholder, and after the passage on duties to suppliers

:fig a business in the middle with arrows to customers, employees, suppliers, lenders, owners and the community, each arrow labelled with the duty owed | ch03-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 2, 'Resources, Location and Environment', section 2.3 'The Business Environment' — the society and the economy as outside forces; Chapter 4, 'Ways to Own a Business, and the Sole Proprietor', section 4.1 'Why the Form of Ownership Matters' — who answers for the business. These references are reminders of where a related idea is developed; they do not introduce a new definition here.