:chapter XII | Institutions and Business Combination
:mood How does the business idea become a workable decision?
:desc Teach the bodies that promote and regulate business in Bangladesh, and why and how businesses combine, with the opportunities and threats of combining. The chapter builds the idea from ordinary experience to business practice.
:plate ch12-plate.svg | merchants meeting in a chamber hall with a model of a harbour on a table, 1890s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 6, 'Joint Stock Company', section 6.1 'The Company and Its Shares'; Chapter 9, 'The Share Market', section 9.3 'Stock Exchanges and the Dhaka Stock Exchange'

## Institutions That Promote Business

> Institutions That Promote Business begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about institutions that promote business. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Securities regulator | a public body that makes and enforces rules for the share market in order to protect investors
> The definition gives the boundary of securities regulator before the example is applied.
The word **Securities regulator** means a public body that makes and enforces rules for the share market in order to protect investors. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Cartel | a loose agreement among businesses that stay separate but fix prices or output together
> The definition gives the boundary of cartel before the example is applied.
The word **Cartel** means a loose agreement among businesses that stay separate but fix prices or output together. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Vertical integration | joining businesses at different stages of the chain, such as a printer, a wholesaler and a shop
> The definition gives the boundary of vertical integration before the example is applied.
The word **Vertical integration** means joining businesses at different stages of the chain, such as a printer, a wholesaler and a shop. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Institutions That Promote Business is what the role of bodies that promote and regulate business, including the securities regulator changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The role of bodies that promote and regulate business, including the securities regulator. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Institutions That Promote Business is what chambers of commerce and the national federation of chambers changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Chambers of commerce and the national federation of chambers. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Institutions That Promote Business.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Institutions That Promote Business.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Institutions That Promote Business.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Institutions That Promote Business.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Institutions That Promote Business.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons Limited has been a member since 1 July 2022 of a district traders' chamber that belongs to a national federation of chambers (illustrative), with an annual subscription of Tk 12,000. Sales for the year ended 31 March 2026 were Tk 3,600,000. On 12 May 2026 the board considered buying a printing press for Tk 2,500,000 (vertical integration) and rejected it. On 1 June 2026 the company took over Shapla Books, a shop with annual sales of Tk 1,800,000, for Tk 900,000, paid by a bank loan of Tk 500,000 and retained profit of Tk 400,000 (500,000 + 400,000 = 900,000). Shapla Books ceased to exist as a separate firm. Combined annual sales of the two shops are Tk 5,400,000 (3,600,000 + 1,800,000), and Shapla Books' sales are one third of the combined figure.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Institutions That Promote Business can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Zones, Export Bodies and Others

> Zones, Export Bodies and Others begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about zones, export bodies and others. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Chamber of commerce | an association of local businesses that speaks for them and helps them trade
> The definition gives the boundary of chamber of commerce before the example is applied.
The word **Chamber of commerce** means an association of local businesses that speaks for them and helps them trade. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Holding company | a company that controls others by owning enough of their shares
> The definition gives the boundary of holding company before the example is applied.
The word **Holding company** means a company that controls others by owning enough of their shares. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Zones, Export Bodies and Others is what export processing zones and the authority that runs them changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Export processing zones and the authority that runs them. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Zones, Export Bodies and Others is what the export promotion body, the trade corporation and other support bodies (the writer confirms each body's full name and role) changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The export promotion body, the trade corporation and other support bodies (the writer confirms each body's full name and role). This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Zones, Export Bodies and Others.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Zones, Export Bodies and Others.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Zones, Export Bodies and Others.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Zones, Export Bodies and Others.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Zones, Export Bodies and Others.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Zones, Export Bodies and Others can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Forms of Business Combination

> Forms of Business Combination begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about forms of business combination. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Export processing zone | a designated area with special facilities and incentives, set up to attract factories that make goods for export
> The definition gives the boundary of export processing zone before the example is applied.
The word **Export processing zone** means a designated area with special facilities and incentives, set up to attract factories that make goods for export. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Merger | the joining of two or more businesses into one, with the owners of each becoming owners of the new business
> The definition gives the boundary of merger before the example is applied.
The word **Merger** means the joining of two or more businesses into one, with the owners of each becoming owners of the new business. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Forms of Business Combination is what forms of combination: cartel, holding company, merger and the directions of integration changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Forms of combination: cartel, holding company, merger and the directions of integration. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Forms of Business Combination.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Forms of Business Combination.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Forms of Business Combination.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Forms of Business Combination.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Forms of Business Combination.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Forms of Business Combination can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Opportunities and Threats

> Opportunities and Threats begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about opportunities and threats. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Business combination | two or more businesses joining together, by agreement or by one taking over another, to act as a larger unit
> The definition gives the boundary of business combination before the example is applied.
The word **Business combination** means two or more businesses joining together, by agreement or by one taking over another, to act as a larger unit. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Horizontal integration | joining businesses that sell the same kind of good or service at the same stage of the chain
> The definition gives the boundary of horizontal integration before the example is applied.
The word **Horizontal integration** means joining businesses that sell the same kind of good or service at the same stage of the chain. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Opportunities and Threats is what why businesses combine, and the opportunities and threats that follow changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Why businesses combine, and the opportunities and threats that follow. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Opportunities and Threats.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Opportunities and Threats.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Opportunities and Threats.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Opportunities and Threats.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Opportunities and Threats.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons Limited has been a member since 1 July 2022 of a district traders' chamber that belongs to a national federation of chambers (illustrative), with an annual subscription of Tk 12,000. Sales for the year ended 31 March 2026 were Tk 3,600,000. On 12 May 2026 the board considered buying a printing press for Tk 2,500,000 (vertical integration) and rejected it. On 1 June 2026 the company took over Shapla Books, a shop with annual sales of Tk 1,800,000, for Tk 900,000, paid by a bank loan of Tk 500,000 and retained profit of Tk 400,000 (500,000 + 400,000 = 900,000). Shapla Books ceased to exist as a separate firm. Combined annual sales of the two shops are Tk 5,400,000 (3,600,000 + 1,800,000), and Shapla Books' sales are one third of the combined figure.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Opportunities and Threats can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons Limited has been a member since 1 July 2022 of a district traders' chamber that belongs to a national federation of chambers (illustrative), with an annual subscription of Tk 12,000. Sales for the year ended 31 March 2026 were Tk 3,600,000. On 12 May 2026 the board considered buying a printing press for Tk 2,500,000 (vertical integration) and rejected it. On 1 June 2026 the company took over Shapla Books, a shop with annual sales of Tk 1,800,000, for Tk 900,000, paid by a bank loan of Tk 500,000 and retained profit of Tk 400,000 (500,000 + 400,000 = 900,000). Shapla Books ceased to exist as a separate firm. Combined annual sales of the two shops are Tk 5,400,000 (3,600,000 + 1,800,000), and Shapla Books' sales are one third of the combined figure.


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 12.t1 | say what a chamber of commerce does for its members

:q 12.t2 | describe the purpose of an export processing zone

:q 12.t3 | compare a cartel, a holding company and a merger

:q 12.t4 | tell horizontal from vertical integration with an example of each

:q 12.t5 | three bakeries each earning Tk 60,000 a month consider joining, so list two opportunities and two threats and decide whether to merge or only cooperate

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
The Standard Oil Trust of 1882 in the United States, the Sherman Antitrust Act of 1890, and the order of 1911 that broke the company into parts. Search hint: Standard Oil trust 1882 Sherman Act 1890 breakup 1911.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 12.r1 | say what a chamber of commerce does for its members

:q 12.r2 | describe the purpose of an export processing zone

:q 12.r3 | compare a cartel, a holding company and a merger

:q 12.r4 | tell horizontal from vertical integration with an example of each

:q 12.r5 | three bakeries each earning Tk 60,000 a month consider joining, so list two opportunities and two threats and decide whether to merge or only cooperate

:pause 12.p1 | after the securities regulator, and after the forms of combination

:fig two drawings side by side: horizontal combination (three shops of the same kind joined) and vertical combination (a printer, a wholesaler and a shop joined along one chain) | ch12-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 9, 'The Share Market', section 9.3 'Stock Exchanges and the Dhaka Stock Exchange' — the market the securities regulator oversees; Chapter 10, 'Foreign Trade: Measuring It and Doing It', section 10.4 'Barriers to Export Trade' — the barriers these bodies help exporters overcome; Chapter 6, 'Joint Stock Company', section 6.1 'The Company and Its Shares' — a holding company is a company that owns shares in others. These references are reminders of where a related idea is developed; they do not introduce a new definition here.