:chapter VI | Joint Stock Company
:mood How does the business idea become a workable decision?
:desc Teach the company as a separate legal person owned through shares, how private and public companies differ, how one is formed, and its merits and demerits. The chapter builds the idea from ordinary experience to business practice.
:plate ch06-plate.svg | a boardroom with directors around a long table beneath a company seal, 1880s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 4, 'Ways to Own a Business, and the Sole Proprietor', section 4.1 'Why the Form of Ownership Matters'; Chapter 5, 'Partnership', section 5.3 'Advantages, Disadvantages and Dissolution'

## The Company and Its Shares

> The Company and Its Shares begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about the company and its shares. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Company | a business that the law treats as a separate person, owned by shareholders through shares
> The definition gives the boundary of company before the example is applied.
The word **Company** means a business that the law treats as a separate person, owned by shareholders through shares. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Authorised capital | the largest amount of share capital that a company is permitted to raise under its rules
> The definition gives the boundary of authorised capital before the example is applied.
The word **Authorised capital** means the largest amount of share capital that a company is permitted to raise under its rules. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Memorandum of association | the founding document that states a company's name, aims, home and capital
> The definition gives the boundary of memorandum of association before the example is applied.
The word **Memorandum of association** means the founding document that states a company's name, aims, home and capital. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Certificate of commencement | the official paper that allows a public company to start business after it has raised enough money
> The definition gives the boundary of certificate of commencement before the example is applied.
The word **Certificate of commencement** means the official paper that allows a public company to start business after it has raised enough money. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in The Company and Its Shares is what the company as a legal person with limited liability changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The company as a legal person with limited liability. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in The Company and Its Shares is what shares, shareholders and dividend changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Shares, shareholders and dividend. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in The Company and Its Shares.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in The Company and Its Shares.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in The Company and Its Shares.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in The Company and Its Shares.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in The Company and Its Shares.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. On 31 March 2024 the partners' capital was Tk 1,200,000: Rafiq Tk 600,000, Imran Tk 300,000, Sohel Tk 300,000 (Chapter 5). On 1 April 2024 the partners ended the partnership and formed Meghna and Sons Limited, a private company. Authorised capital Tk 2,000,000, divided into 200,000 shares of Tk 10 each. Shares issued 120,000 (120,000 x 10 = Tk 1,200,000): Rafiq 60,000, Imran 30,000, Sohel 30,000. Unissued shares 80,000 (Tk 800,000). Certificate of incorporation dated 15 April 2024. Directors: Rafiq (chairman), Imran (managing director), Sohel. For the year ended 31 March 2025 profit after all costs was Tk 540,000; the board proposed a dividend of Tk 2 a share, Tk 240,000 in all (120,000 x 2): Rafiq Tk 120,000, Imran Tk 60,000, Sohel Tk 60,000; the remaining Tk 300,000 was kept in the business. As a private company the business issued no prospectus.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* The Company and Its Shares can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Private and Public Companies

> Private and Public Companies begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about private and public companies. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Share | one equal part of a company's capital, which gives its holder a part of ownership
> The definition gives the boundary of share before the example is applied.
The word **Share** means one equal part of a company's capital, which gives its holder a part of ownership. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Private company | a company that limits who may hold its shares and may not invite the public to buy them
> The definition gives the boundary of private company before the example is applied.
The word **Private company** means a company that limits who may hold its shares and may not invite the public to buy them. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Articles of association | the rules for running the company inside, including meetings, directors and shares
> The definition gives the boundary of articles of association before the example is applied.
The word **Articles of association** means the rules for running the company inside, including meetings, directors and shares. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Private and Public Companies is what private and public companies compared changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Private and public companies compared. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in Private and Public Companies is what management by the board of directors changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Management by the board of directors. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Private and Public Companies.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Private and Public Companies.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Private and Public Companies.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Private and Public Companies.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Private and Public Companies.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Private and Public Companies can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Forming a Company and Issuing a Prospectus

> Forming a Company and Issuing a Prospectus begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about forming a company and issuing a prospectus. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Shareholder | a person or organisation that owns one or more shares in a company
> The definition gives the boundary of shareholder before the example is applied.
The word **Shareholder** means a person or organisation that owns one or more shares in a company. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Public company | a company that may invite the public to buy its shares and whose shares can be freely traded
> The definition gives the boundary of public company before the example is applied.
The word **Public company** means a company that may invite the public to buy its shares and whose shares can be freely traded. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Certificate of incorporation | the official paper that proves the company legally exists as a separate person
> The definition gives the boundary of certificate of incorporation before the example is applied.
The word **Certificate of incorporation** means the official paper that proves the company legally exists as a separate person. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Forming a Company and Issuing a Prospectus is what steps of formation: the memorandum, the articles, incorporation, the prospectus and starting trade changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Steps of formation: the memorandum, the articles, incorporation, the prospectus and starting trade. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Forming a Company and Issuing a Prospectus.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Forming a Company and Issuing a Prospectus.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Forming a Company and Issuing a Prospectus.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Forming a Company and Issuing a Prospectus.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Forming a Company and Issuing a Prospectus.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Forming a Company and Issuing a Prospectus can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Merits and Demerits

> Merits and Demerits begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about merits and demerits. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Dividend | the part of a company's profit that is paid out to its shareholders
> The definition gives the boundary of dividend before the example is applied.
The word **Dividend** means the part of a company's profit that is paid out to its shareholders. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Board of directors | the group chosen by shareholders to guide the company and appoint its senior managers
> The definition gives the boundary of board of directors before the example is applied.
The word **Board of directors** means the group chosen by shareholders to guide the company and appoint its senior managers. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Prospectus | the document by which a public company invites the public to buy its shares
> The definition gives the boundary of prospectus before the example is applied.
The word **Prospectus** means the document by which a public company invites the public to buy its shares. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Merits and Demerits is what merits and demerits of the company form, and whether it is the best form changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Merits and demerits of the company form, and whether it is the best form. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Merits and Demerits.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Merits and Demerits.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Merits and Demerits.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Merits and Demerits.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Merits and Demerits.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. On 31 March 2024 the partners' capital was Tk 1,200,000: Rafiq Tk 600,000, Imran Tk 300,000, Sohel Tk 300,000 (Chapter 5). On 1 April 2024 the partners ended the partnership and formed Meghna and Sons Limited, a private company. Authorised capital Tk 2,000,000, divided into 200,000 shares of Tk 10 each. Shares issued 120,000 (120,000 x 10 = Tk 1,200,000): Rafiq 60,000, Imran 30,000, Sohel 30,000. Unissued shares 80,000 (Tk 800,000). Certificate of incorporation dated 15 April 2024. Directors: Rafiq (chairman), Imran (managing director), Sohel. For the year ended 31 March 2025 profit after all costs was Tk 540,000; the board proposed a dividend of Tk 2 a share, Tk 240,000 in all (120,000 x 2): Rafiq Tk 120,000, Imran Tk 60,000, Sohel Tk 60,000; the remaining Tk 300,000 was kept in the business. As a private company the business issued no prospectus.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Merits and Demerits can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. On 31 March 2024 the partners' capital was Tk 1,200,000: Rafiq Tk 600,000, Imran Tk 300,000, Sohel Tk 300,000 (Chapter 5). On 1 April 2024 the partners ended the partnership and formed Meghna and Sons Limited, a private company. Authorised capital Tk 2,000,000, divided into 200,000 shares of Tk 10 each. Shares issued 120,000 (120,000 x 10 = Tk 1,200,000): Rafiq 60,000, Imran 30,000, Sohel 30,000. Unissued shares 80,000 (Tk 800,000). Certificate of incorporation dated 15 April 2024. Directors: Rafiq (chairman), Imran (managing director), Sohel. For the year ended 31 March 2025 profit after all costs was Tk 540,000; the board proposed a dividend of Tk 2 a share, Tk 240,000 in all (120,000 x 2): Rafiq Tk 120,000, Imran Tk 60,000, Sohel Tk 60,000; the remaining Tk 300,000 was kept in the business. As a private company the business issued no prospectus.


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 6.t1 | define company and explain why it counts as a separate person

:q 6.t2 | compare private and public companies on members, shares and the public offer

:q 6.t3 | list the documents needed to form a company and say what each contains

:q 6.t4 | state two merits and two demerits of the form

:q 6.t5 | a company has 50,000 shares of Tk 10, earns Tk 80,000 profit and keeps half, so work out the dividend per share and the sum each holder of 5,000 shares receives

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
The Dutch East India Company (VOC), chartered in 1602 in Amsterdam, whose shares could be bought and sold, and the English Joint Stock Companies Act of 1844 and Limited Liability Act of 1855. Search hint: Dutch East India Company 1602 first joint stock shares Amsterdam.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Sources

> These sources support the historical or defining material used in the chapter.
:read The historical case named in this chapter, institutional or primary record, year
:read A standard reference on the chapter's subject, author and title, year

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 6.r1 | define company and explain why it counts as a separate person

:q 6.r2 | compare private and public companies on members, shares and the public offer

:q 6.r3 | list the documents needed to form a company and say what each contains

:q 6.r4 | state two merits and two demerits of the form

:q 6.r5 | a company has 50,000 shares of Tk 10, earns Tk 80,000 profit and keeps half, so work out the dividend per share and the sum each holder of 5,000 shares receives

:pause 6.p1 | after limited liability for shareholders, and after the memorandum and the articles

:fig the chain from shareholders to board of directors to managers, with arrows showing who elects and who reports | ch06-fig01.svg

:fig the steps of forming a company in order, from agreeing the aims to receiving the certificate, drawn as numbered boxes | ch06-fig02.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 4, 'Ways to Own a Business, and the Sole Proprietor', section 4.1 'Why the Form of Ownership Matters' — limited liability and the legal person; Chapter 9, 'The Share Market', section 9.1 'Shares and Their Kinds' — the kinds of shares and where they are traded. These references are reminders of where a related idea is developed; they do not introduce a new definition here.