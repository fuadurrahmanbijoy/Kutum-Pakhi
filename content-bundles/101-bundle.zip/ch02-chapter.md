:chapter II | Resources, Location and Environment
:mood How does the business idea become a workable decision?
:desc Teach the resources every business draws on, how a business chooses where to operate, and how the world around it shapes what it can do. The chapter builds the idea from ordinary experience to business practice.
:plate ch02-plate.svg | a surveyor with a theodolite at a river bend beside a mill and a railway line, 1870s

> Earlier ideas needed for this chapter are named before they are used.
You will need: Chapter 1, 'What Business Is, Does and Aims For', section 1.2 'What a Business Is' and section 1.3 'Trade, Commerce and Industry'

## The Factors of Production

> The Factors of Production begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about the factors of production. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Factors of production | the resources a business must combine to make or sell anything: land, labour, capital and the entrepreneur
> The definition gives the boundary of factors of production before the example is applied.
The word **Factors of production** means the resources a business must combine to make or sell anything: land, labour, capital and the entrepreneur. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Capital | the money and the man-made means of production, such as tools, stock and buildings, used to earn more
> The definition gives the boundary of capital before the example is applied.
The word **Capital** means the money and the man-made means of production, such as tools, stock and buildings, used to earn more. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Plant | the factory, machinery and equipment that a business uses to make its goods
> The definition gives the boundary of plant before the example is applied.
The word **Plant** means the factory, machinery and equipment that a business uses to make its goods. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ External environment | the forces outside the business that it cannot control but must respond to
> The definition gives the boundary of external environment before the example is applied.
The word **External environment** means the forces outside the business that it cannot control but must respond to. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in The Factors of Production is what the four factors of production and the reward each earns changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The four factors of production and the reward each earns. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The paragraph connects the idea to a practical business question.

The useful question in The Factors of Production is what how the factors are combined by the entrepreneur changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: How the factors are combined by the entrepreneur. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in The Factors of Production.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in The Factors of Production.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in The Factors of Production.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in The Factors of Production.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in The Factors of Production.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons opened on 4 January 2015 with start-up money of Tk 158,000 and monthly shop rent of Tk 9,000. Factors in the shop: land is the rented room (rent Tk 9,000 a month, advance paid to the landlord Tk 30,000); labour is Rafiq Uddin Mia and one helper, Mahbub, employed from 1 February 2015 at Tk 6,000 a month; capital is the Tk 158,000; Rafiq acts as entrepreneur. Location choice made in December 2014, three sites compared: Site A near a college: rent Tk 9,000, advance Tk 30,000, about 1,200 passers-by a day; Site B in a wholesale lane: rent Tk 14,000, advance Tk 56,000, about 2,000 passers-by a day; Site C in a residential lane: rent Tk 5,000, advance Tk 15,000, about 300 passers-by a day. Rent per 100 daily passers-by: Site A Tk 750, Site B Tk 700, Site C Tk 1,667 (to the nearest taka). Rafiq chose Site A because Site B's advance of Tk 56,000 was more than a third of his Tk 158,000 and its rent was Tk 5,000 higher. Environment events: on 2 January 2017 the education board changed the prescribed textbooks for three school classes, leaving 60 titles unsellable; average monthly sales were Tk 200,000 in 2017 and Tk 170,000 in 2018, a fall of 15% after an online bookstore began delivering in Dhaka; from March 2019 the helper delivered orders by bicycle for Tk 30 an order.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* The Factors of Production can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Choosing a Location

> Choosing a Location begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about choosing a location. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Land | all natural resources and the ground itself, including soil, water, minerals and the site of a shop
> The definition gives the boundary of land before the example is applied.
The word **Land** means all natural resources and the ground itself, including soil, water, minerals and the site of a shop. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Entrepreneur | the person who combines the other resources, takes the risk and organises a business to meet a need
> The definition gives the boundary of entrepreneur before the example is applied.
The word **Entrepreneur** means the person who combines the other resources, takes the risk and organises a business to meet a need. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Environment | everything outside and around a business that can affect it, and everything inside that it controls
> The definition gives the boundary of environment before the example is applied.
The word **Environment** means everything outside and around a business that can affect it, and everything inside that it controls. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in Choosing a Location is what the forces that shape where a business sets up, and how to weigh them changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: The forces that shape where a business sets up, and how to weigh them. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in Choosing a Location.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in Choosing a Location.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in Choosing a Location.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in Choosing a Location.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in Choosing a Location.

* * *

> The section recap gathers the main point before the next section.

*Before moving on.* Choosing a Location can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## The Business Environment

> The Business Environment begins with a concrete question before the rule is stated.
Suppose you are looking at a business that must make a decision about the business environment. What would you examine first? The safest starting point is the ordinary situation: what is being done, who is affected, what resources are involved, and what result is expected. Only after that should the formal business term be used.

@ Labour | the physical and mental effort that people give to producing goods or services
> The definition gives the boundary of labour before the example is applied.
The word **Labour** means the physical and mental effort that people give to producing goods or services. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Location | the place where a business carries out its work, chosen from the available sites
> The definition gives the boundary of location before the example is applied.
The word **Location** means the place where a business carries out its work, chosen from the available sites. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

@ Internal environment | the parts of the environment that the business controls: owners, managers, employees, methods and resources
> The definition gives the boundary of internal environment before the example is applied.
The word **Internal environment** means the parts of the environment that the business controls: owners, managers, employees, methods and resources. A small example makes the boundary easier to see: imagine a local business facing one decision in which this idea matters. The decision can then be described using the term without changing its meaning.

> The paragraph connects the idea to a practical business question.

The useful question in The Business Environment is what internal and external environment, and how a business and its surroundings affect each other changes in an ordinary business decision.

> The paragraph connects the idea to a practical business question.

The answer begins with the definition: Internal and external environment, and how a business and its surroundings affect each other. This gives the idea a boundary, so it can be distinguished from nearby ideas.

> The paragraph connects the idea to a practical business question.

Consider a small business before applying the rule. Its owner must decide what to buy, whom to serve, how to organise work, and what risks to accept.

> The section keeps the distinction practical and testable.

A useful first step is to describe the situation without using the formal term. Ask who acts, what is being exchanged or controlled, what resource is involved, and what result is expected. This prevents a familiar word from hiding a different business meaning. This is the point to carry into the next example in The Business Environment.

> The section keeps the distinction practical and testable.

The next step is to identify the relationship between the parts. A business rarely makes a decision in isolation. A choice about ownership can affect control and risk; a choice about resources can affect cost and capacity; a choice about customers can affect service and revenue. This is the point to carry into the next example in The Business Environment.

> The section keeps the distinction practical and testable.

The rule becomes useful when it can guide a real decision. State the facts that matter, select the relevant definition, and apply the rule to those facts. If the facts do not fit the definition, stop and reconsider rather than forcing the example into the rule. This is the point to carry into the next example in The Business Environment.

> The section keeps the distinction practical and testable.

The limits matter as much as the rule. Business conditions differ by place, law, market, time, and purpose. A principle may describe a common pattern without deciding every case. Where a legal or institutional difference matters, the reader should identify the country or institution involved. This is the point to carry into the next example in The Business Environment.

> The section keeps the distinction practical and testable.

A second viewpoint is often helpful. The owner may care about control and risk, the manager about workable operations, the employee about duties and conditions, and the customer about price and service. The same decision can therefore have several relevant effects. This is the point to carry into the next example in The Business Environment.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons opened on 4 January 2015 with start-up money of Tk 158,000 and monthly shop rent of Tk 9,000. Factors in the shop: land is the rented room (rent Tk 9,000 a month, advance paid to the landlord Tk 30,000); labour is Rafiq Uddin Mia and one helper, Mahbub, employed from 1 February 2015 at Tk 6,000 a month; capital is the Tk 158,000; Rafiq acts as entrepreneur. Location choice made in December 2014, three sites compared: Site A near a college: rent Tk 9,000, advance Tk 30,000, about 1,200 passers-by a day; Site B in a wholesale lane: rent Tk 14,000, advance Tk 56,000, about 2,000 passers-by a day; Site C in a residential lane: rent Tk 5,000, advance Tk 15,000, about 300 passers-by a day. Rent per 100 daily passers-by: Site A Tk 750, Site B Tk 700, Site C Tk 1,667 (to the nearest taka). Rafiq chose Site A because Site B's advance of Tk 56,000 was more than a third of his Tk 158,000 and its rent was Tk 5,000 higher. Environment events: on 2 January 2017 the education board changed the prescribed textbooks for three school classes, leaving 60 titles unsellable; average monthly sales were Tk 200,000 in 2017 and Tk 170,000 in 2018, a fall of 15% after an online bookstore began delivering in Dhaka; from March 2019 the helper delivered orders by bicycle for Tk 30 an order.


* * *

> The section recap gathers the main point before the next section.

*Before moving on.* The Business Environment can be understood by asking what the term means, how it changes a decision, and where the rule has limits.

## Worked Case

> A worked case shows how the chapter's ideas can be applied without turning the case into a story.

Situation. The documented running case contains recorded facts relevant to this chapter.

> The running case applies the section's rule to recorded facts.

:case Case file, illustrative. Carried forward. Meghna and Sons opened on 4 January 2015 with start-up money of Tk 158,000 and monthly shop rent of Tk 9,000. Factors in the shop: land is the rented room (rent Tk 9,000 a month, advance paid to the landlord Tk 30,000); labour is Rafiq Uddin Mia and one helper, Mahbub, employed from 1 February 2015 at Tk 6,000 a month; capital is the Tk 158,000; Rafiq acts as entrepreneur. Location choice made in December 2014, three sites compared: Site A near a college: rent Tk 9,000, advance Tk 30,000, about 1,200 passers-by a day; Site B in a wholesale lane: rent Tk 14,000, advance Tk 56,000, about 2,000 passers-by a day; Site C in a residential lane: rent Tk 5,000, advance Tk 15,000, about 300 passers-by a day. Rent per 100 daily passers-by: Site A Tk 750, Site B Tk 700, Site C Tk 1,667 (to the nearest taka). Rafiq chose Site A because Site B's advance of Tk 56,000 was more than a third of his Tk 158,000 and its rent was Tk 5,000 higher. Environment events: on 2 January 2017 the education board changed the prescribed textbooks for three school classes, leaving 60 titles unsellable; average monthly sales were Tk 200,000 in 2017 and Tk 170,000 in 2018, a fall of 15% after an online bookstore began delivering in Dhaka; from March 2019 the helper delivered orders by bicycle for Tk 30 an order.


> The question is tested by the rule rather than by invented assumptions.
Question. Which chapter idea best describes the recorded facts? Reasoning. Identify the relevant term, match it to the facts, and distinguish what is recorded from what would need further evidence. Conclusion. The rule can be applied only to the facts that satisfy its definition. Check. Change one fact and ask whether the same rule still applies.

## Summary

> The chapter's main ideas can be recalled as a connected set rather than as isolated terms.
The central pattern is to identify the business situation, name the relevant idea, apply its rule, and then check its limits. The running case shows how the same principles operate in a recorded business setting. The definitions provide the vocabulary needed to make the distinctions precise.

## Think It Through

> These questions test the ideas by changing the situation or asking for a distinction.

:q 2.t1 | name the four factors and the reward each one earns

:q 2.t2 | list the forces that shape a location and say which matter most for a shop and which for a factory

:q 2.t3 | separate a business's internal from its external environment, with an example of each

:q 2.t4 | explain how a business can respond to a change it cannot control

:q 2.t5 | a bakery can rent a roadside plot at Tk 18,000 a month with 2,400 daily passers-by, or an inner lane plot at Tk 7,000 with 500, and has Tk 120,000 to start, so compare rent per 100 passers-by and decide

## Where People Go Wrong

> Most errors arise when a related idea is treated as if it were identical.
One common error is to use a familiar word without checking its business meaning. Another is to apply a rule before identifying the facts that make the rule relevant. A third is to treat an example as proof that every business must behave in the same way. The correction in each case is to return to the definition, state the facts, apply the rule, and then test the exception.

## In History

> The historical case shows how the chapter's ideas appeared in a documented setting.
Tata Iron and Steel Company, 1907: the search for a site with ore, coal and water that ended at Sakchi, later Jamshedpur, India. Search hint: Tata Steel Sakchi site selection 1907 Jamshedpur.. The historical example is useful because it places the business principle in time and gives the reader a concrete setting. It should not be treated as evidence for facts that are not stated in the chapter.

## Review Questions

> The review questions return to the same ideas in a direct form.

:q 2.r1 | name the four factors and the reward each one earns

:q 2.r2 | list the forces that shape a location and say which matter most for a shop and which for a factory

:q 2.r3 | separate a business's internal from its external environment, with an example of each

:q 2.r4 | explain how a business can respond to a change it cannot control

:q 2.r5 | a bakery can rent a roadside plot at Tk 18,000 a month with 2,400 daily passers-by, or an inner lane plot at Tk 7,000 with 500, and has Tk 120,000 to start, so compare rent per 100 passers-by and decide

:pause 2.p1 | after the four factors, and after the split between internal and external environment

:fig a business at the centre with the internal group (owner, helper, resources) close in and the outside forces (customers, rivals, government, technology, economy, society) in a ring around it | ch02-fig01.svg

> Cross-references connect this chapter to related ideas elsewhere in the book.
The chapter points to: Chapter 1, 'What Business Is, Does and Aims For', section 1.2 'What a Business Is' — the idea of business that these resources serve; Chapter 3, 'Social Responsibility of Business', section 3.1 'Meaning and Importance of Responsibility' — the society that is part of the external environment. These references are reminders of where a related idea is developed; they do not introduce a new definition here.