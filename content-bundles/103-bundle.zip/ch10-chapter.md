:chapter X | Closing the Books
:mood What must be made visible before the next step can be trusted?
:desc This chapter builds one accounting idea at a time, from a practical problem to a rule and a checked application.
:plate ch10-plate.svg | a clerk locking a heavy iron safe at evening by candlelight, 1880s

> The chapter begins with a practical question before giving the formal rule.

Suppose a reader has the records described in this chapter but must decide what they mean. The difficulty is not arithmetic alone. A useful accounting record depends on classification, timing, evidence, and a method that another person can follow. Closing the Books addresses that difficulty by moving from a concrete situation to a rule and then back to the situation.

## Preparing the Statements from the Worksheet

> The chapter vocabulary is fixed before the procedures are applied.

These terms give the chapter a stable language. Each definition narrows an accounting idea so that later calculations and classifications do not drift.

@ Closing entry | a journal entry at the end of a period that moves a temporary account's balance to equity
> Closing entry names one specific idea needed here.

The term **Closing entry** means a journal entry at the end of a period that moves a temporary account's balance to equity. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Temporary account | an account for revenue, expense or drawings that is closed to zero at the end of each period
> Temporary account names one specific idea needed here.

The term **Temporary account** means an account for revenue, expense or drawings that is closed to zero at the end of each period. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Permanent account | an account for an asset, liability or owner's capital whose balance carries into the next period
> Permanent account names one specific idea needed here.

The term **Permanent account** means an account for an asset, liability or owner's capital whose balance carries into the next period. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Income summary | a temporary account that collects revenue and expenses before the net result moves to capital
> Income summary names one specific idea needed here.

The term **Income summary** means a temporary account that collects revenue and expenses before the net result moves to capital. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Reversing entry | an entry made on the first day of a new period that cancels an earlier adjusting entry
> Reversing entry names one specific idea needed here.

The term **Reversing entry** means an entry made on the first day of a new period that cancels an earlier adjusting entry. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

> Income statement and equity statement from the worksheet starts with a concrete question.

In Preparing the Statements from the Worksheet, we begin with income statement and equity statement from the worksheet rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Balance sheet from the worksheet starts with a concrete question.

In Preparing the Statements from the Worksheet, we begin with balance sheet from the worksheet rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig the four closing entries as arrows into the income summary and capital accounts | ch10-fig01.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Closing Entries

> Why temporary accounts are closed starts with a concrete question.

In Closing Entries, we begin with why temporary accounts are closed rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> The four closing entries starts with a concrete question.

In Closing Entries, we begin with the four closing entries rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig before-and-after view of temporary and permanent accounts | ch10-fig02.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Reversing Entries

> What a reversing entry undoes starts with a concrete question.

In Reversing Entries, we begin with what a reversing entry undoes rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> When reversing is optional starts with a concrete question.

In Reversing Entries, we begin with when reversing is optional rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

* * *
## Worked Case

> The worked case applies the chapter rules to the documented running case.

Situation. Meghna and Sons, illustrative. Adjusted balances at 31 January 2022, from the worksheet: Cash Tk 555,000; Accounts Receivable Tk 65,000; Supplies Tk 7,000; Prepaid Rent Tk 24,000; Equipment Tk 150,000; Accumulated Depreciation Tk 1,000 Cr; Accounts Payable Tk 38,000; Wages Payable Tk 9,000; Unearned Revenue Tk 22,000; Owner's Capital Tk 600,000; Owner's Drawings Tk 20,000; Service Revenue Tk 232,000; Wages Expense Tk 49,000; Utilities Expense Tk 8,000; Rent Expense Tk 12,000; Supplies Expense Tk 11,000; Depreciation Expense Tk 1,000. Net income Tk 151,000 (revenue Tk 232,000 less expenses Tk 81,000). Closing capital Tk 731,000 (Tk 600,000 plus Tk 151,000 less Tk 20,000). Total assets Tk 800,000; total liabilities Tk 69,000. Reversing entry for the Tk 9,000 wages accrual is made on 1 February 2022.

> The question is how the chapter method changes the way the case is recorded or understood.

Question. Using only the figures and facts given above, identify the relevant items, apply the rule introduced in the body of the chapter, and keep each step tied to a date or amount.

> The reasoning follows the chapter sequence rather than jumping to the result.

Reasoning. First identify the event or balance. Next classify it using the definitions in this chapter. Then perform the required recording or calculation step. Finally compare the result with the other records that should be affected.

> The case result is accepted only when the records agree with the stated facts.

Conclusion. The figures in the case file provide the boundary for the answer. A correct treatment uses those figures without inventing an additional transaction, date, or amount.

> A worked case is checked against the original facts.

Check. Re-read the case line by line. Confirm each amount, date, and classification. If a result cannot be traced to a stated fact or to an explicitly stated rule, it should not be added to the record.

* * *
> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

## Summary

> The chapter can be reduced to a small set of working rules.

Closing the Books is easiest to remember as a sequence: identify the fact, use the defined term precisely, apply the stated rule, and check the result against the other records. The examples and the worked case show how the method behaves when the setting changes.


## Think It Through

:q 10.t1 | What is the central problem that this chapter method is designed to solve?
:q 10.t2 | How would the treatment change if one important fact in the case were changed?

## Where People Go Wrong

> A common error is to use a familiar word without checking its accounting meaning.

Correction. Return to the definition, identify the exact item described, and then apply the rule. Another error is to perform a calculation without checking the period or record the number belongs to. Correction. Name the period and record before calculating.


## In History

> The historical case shows why careful records matter beyond a textbook example.

The British tax year begins on 6 April because of the calendar change of 1752, when eleven days were dropped and the old year-end of 25 March was moved forward. Search: why UK tax year starts 6 April 1752 calendar. This note is included as a documented setting in which accounting records or accounting methods had practical consequences. The history illustrates the need for careful method; it does not replace the accounting rule.


## Review Questions

:q 10.r1 | State the main rule in your own words and apply it to a new small example.
:q 10.r2 | What check would you perform before accepting the result?
