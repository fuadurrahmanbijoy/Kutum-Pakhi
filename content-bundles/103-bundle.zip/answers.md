:answers 01
:a 01.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 01.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 01.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 01.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 02
:a 02.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 02.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 02.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 02.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 03
:a 03.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 03.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 03.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 03.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 04
:a 04.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 04.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 04.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 04.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 05
:a 05.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 05.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 05.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 05.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 06
:a 06.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 06.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 06.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 06.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 07
:a 07.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 07.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 07.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 07.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 08
:a 08.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 08.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 08.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 08.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 09
:a 09.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 09.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 09.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 09.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 10
:a 10.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 10.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 10.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 10.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 11
:a 11.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 11.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 11.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 11.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 12
:a 12.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 12.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 12.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 12.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 13
:a 13.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 13.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 13.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 13.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 14
:a 14.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 14.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 14.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 14.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 15
:a 15.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 15.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 15.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 15.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 16
:a 16.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 16.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 16.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 16.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 17
:a 17.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 17.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 17.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 17.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers 18
:a 18.t1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 18.t2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 18.r1 | Identify the relevant fact, apply the stated rule, and check the result against the other records.
:a 18.r2 | Identify the relevant fact, apply the stated rule, and check the result against the other records.

:answers A1
