:chapter VI | Journal and Ledger
:mood What must be made visible before the next step can be trusted?
:desc This chapter builds one accounting idea at a time, from a practical problem to a rule and a checked application.
:plate ch06-plate.svg | a long shelf of leather-bound ledgers with a wheeled library ladder, 1

> The chapter begins with a practical question before giving the formal rule.

Suppose a reader has the records described in this chapter but must decide what they mean. The difficulty is not arithmetic alone. A useful accounting record depends on classification, timing, evidence, and a method that another person can follow. Journal and Ledger addresses that difficulty by moving from a concrete situation to a rule and then back to the situation.

## The Journal and Journal Entries

> The chapter vocabulary is fixed before the procedures are applied.

These terms give the chapter a stable language. Each definition narrows an accounting idea so that later calculations and classifications do not drift.

@ Journal | the book in which each transaction is first recorded, in date order
> Journal names one specific idea needed here.

The term **Journal** means the book in which each transaction is first recorded, in date order. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Journal entry | one recorded transaction, showing the accounts debited and credited and the amounts
> Journal entry names one specific idea needed here.

The term **Journal entry** means one recorded transaction, showing the accounts debited and credited and the amounts. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Compound entry | a journal entry that affects more than two accounts
> Compound entry names one specific idea needed here.

The term **Compound entry** means a journal entry that affects more than two accounts. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Narration | a short written explanation placed under a journal entry
> Narration names one specific idea needed here.

The term **Narration** means a short written explanation placed under a journal entry. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Ledger | the complete set of accounts of a business, kept together
> Ledger names one specific idea needed here.

The term **Ledger** means the complete set of accounts of a business, kept together. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Posting | copying the amounts from journal entries into the proper ledger accounts
> Posting names one specific idea needed here.

The term **Posting** means copying the amounts from journal entries into the proper ledger accounts. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Folio | a page or reference number used to link a journal entry with its ledger account
> Folio names one specific idea needed here.

The term **Folio** means a page or reference number used to link a journal entry with its ledger account. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

> Layout of a journal entry starts with a concrete question.

In The Journal and Journal Entries, we begin with layout of a journal entry rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Narration and compound entries starts with a concrete question.

In The Journal and Journal Entries, we begin with narration and compound entries rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig a journal page with columns labelled | ch06-fig01.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## The Ledger and Posting

> The ledger as the book of accounts starts with a concrete question.

In The Ledger and Posting, we begin with the ledger as the book of accounts rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Posting step by step and cross-referencing starts with a concrete question.

In The Ledger and Posting, we begin with posting step by step and cross-referencing rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig an arrow from journal entry to the ledger accounts it feeds | ch06-fig02.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Worked Cycle of Entries

> A month from journal to ledger balances starts with a concrete question.

In Worked Cycle of Entries, we begin with a month from journal to ledger balances rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Checking your own work starts with a concrete question.

In Worked Cycle of Entries, we begin with checking your own work rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

* * *
## Worked Case

> The worked case applies the chapter rules to the documented running case.

Situation. Meghna and Sons, illustrative. January 2022 transactions: 2 Jan owner Karim Meghna invests cash Tk 600,000; 3 Jan buys binding equipment Tk 150,000, paying Tk 100,000 cash and owing Tk 50,000 to Dhaka Machine Works; 8 Jan binding work for cash Tk 95,000; 12 Jan binding work for a school on account Tk 120,000; 20 Jan collects Tk 70,000 from the school; 22 Jan pays Tk 30,000 to Dhaka Machine Works; 25 Jan pays wages Tk 40,000; 28 Jan pays utilities Tk 8,000; 31 Jan owner withdraws Tk 20,000. Ledger balances after posting (by code): Cash Tk 567,000 Dr; Accounts Receivable Tk 50,000 Dr; Equipment Tk 150,000 Dr; Accounts Payable Tk 20,000 Cr; Owner's Capital Tk 600,000 Cr; Owner's Drawings Tk 20,000 Dr; Service Revenue Tk 215,000 Cr; Wages Expense Tk 40,000 Dr; Utilities Expense Tk 8,000 Dr. Equipment purchase of 3 January is the compound entry: Equipment Dr Tk 150,000; Cash Cr Tk 100,000; Accounts Payable Cr Tk 50,000.

> The question is how the chapter method changes the way the case is recorded or understood.

Question. Using only the figures and facts given above, identify the relevant items, apply the rule introduced in the body of the chapter, and keep each step tied to a date or amount.

> The reasoning follows the chapter sequence rather than jumping to the result.

Reasoning. First identify the event or balance. Next classify it using the definitions in this chapter. Then perform the required recording or calculation step. Finally compare the result with the other records that should be affected.

> The case result is accepted only when the records agree with the stated facts.

Conclusion. The figures in the case file provide the boundary for the answer. A correct treatment uses those figures without inventing an additional transaction, date, or amount.

> A worked case is checked against the original facts.

Check. Re-read the case line by line. Confirm each amount, date, and classification. If a result cannot be traced to a stated fact or to an explicitly stated rule, it should not be added to the record.

* * *
> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

## Summary

> The chapter can be reduced to a small set of working rules.

Journal and Ledger is easiest to remember as a sequence: identify the fact, use the defined term precisely, apply the stated rule, and check the result against the other records. The examples and the worked case show how the method behaves when the setting changes.


## Think It Through

:q 06.t1 | What is the central problem that this chapter method is designed to solve?
:q 06.t2 | How would the treatment change if one important fact in the case were changed?

## Where People Go Wrong

> A common error is to use a familiar word without checking its accounting meaning.

Correction. Return to the definition, identify the exact item described, and then apply the rule. Another error is to perform a calculation without checking the period or record the number belongs to. Correction. Name the period and record before calculating.


## In History

> The historical case shows why careful records matter beyond a textbook example.

The ledger of Giovanni Farolfi and Company, kept 1299 to 1300 at Salon-de-Provence, is one of the oldest known surviving double-entry ledgers. Search: Farolfi ledger 1299 double entry earliest. This note is included as a documented setting in which accounting records or accounting methods had practical consequences. The history illustrates the need for careful method; it does not replace the accounting rule.


## Review Questions

:q 06.r1 | State the main rule in your own words and apply it to a new small example.
:q 06.r2 | What check would you perform before accepting the result?
