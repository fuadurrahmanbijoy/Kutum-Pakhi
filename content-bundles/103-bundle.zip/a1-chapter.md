:chapter A1 | Maths You Will Use

## Percentages and Percentage Change

@ Percentage | a number written as a part out of one hundred
> Percentage gives a precise mathematical meaning.

The term **Percentage** means a number written as a part out of one hundred. Use the definition with a tiny numerical example before moving to a larger accounting calculation.

@ Percentage change | the size of an increase or decrease shown as a percentage of the starting figure
> Percentage change gives a precise mathematical meaning.

The term **Percentage change** means the size of an increase or decrease shown as a percentage of the starting figure. Use the definition with a tiny numerical example before moving to a larger accounting calculation.

@ Ratio | a comparison of two or more amounts, written with a colon, such as 2:1
> Ratio gives a precise mathematical meaning.

The term **Ratio** means a comparison of two or more amounts, written with a colon, such as 2:1. Use the definition with a tiny numerical example before moving to a larger accounting calculation.

@ Average | the total of a set of numbers divided by how many numbers there are
> Average gives a precise mathematical meaning.

The term **Average** means the total of a set of numbers divided by how many numbers there are. Use the definition with a tiny numerical example before moving to a larger accounting calculation.

@ Rounding | replacing a number by a nearby simpler number, such as the nearest whole taka
> Rounding gives a precise mathematical meaning.

The term **Rounding** means replacing a number by a nearby simpler number, such as the nearest whole taka. Use the definition with a tiny numerical example before moving to a larger accounting calculation.

> Percentages and Percentage Change provides a practical mathematical tool.

The topic is used to handle numerical relationships in accounting. Start with the smallest example, write the operation in full, and check the result against the original quantities. The aim is accuracy and a repeatable method.

## Ratios and Averages

> Ratios and Averages provides a practical mathematical tool.

The topic is used to handle numerical relationships in accounting. Start with the smallest example, write the operation in full, and check the result against the original quantities. The aim is accuracy and a repeatable method.

## Rearranging, Rounding and Graphs

> Rearranging, Rounding and Graphs provides a practical mathematical tool.

The topic is used to handle numerical relationships in accounting. Start with the smallest example, write the operation in full, and check the result against the original quantities. The aim is accuracy and a repeatable method.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

> A short numerical check prevents an avoidable arithmetic error.

Write the starting value before changing it. Keep the unit or label beside the number while working. Estimate the result first, then calculate it exactly and compare the two results.

