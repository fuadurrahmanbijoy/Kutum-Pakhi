:chapter VIII | Adjusting the Accounts
:mood What must be made visible before the next step can be trusted?
:desc This chapter builds one accounting idea at a time, from a practical problem to a rule and a checked application.
:plate ch08-plate.svg | a grandfather clock beside a stack of unpaid bills and receipts on a m

> The chapter begins with a practical question before giving the formal rule.

Suppose a reader has the records described in this chapter but must decide what they mean. The difficulty is not arithmetic alone. A useful accounting record depends on classification, timing, evidence, and a method that another person can follow. Adjusting the Accounts addresses that difficulty by moving from a concrete situation to a rule and then back to the situation.

## Why Accounts Need Adjusting

> The chapter vocabulary is fixed before the procedures are applied.

These terms give the chapter a stable language. Each definition narrows an accounting idea so that later calculations and classifications do not drift.

@ Adjusting entry | a journal entry made at the end of a period to bring an account up to its correct amount
> Adjusting entry names one specific idea needed here.

The term **Adjusting entry** means a journal entry made at the end of a period to bring an account up to its correct amount. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Cash basis | the method of recording revenue and expenses only when cash is received or paid
> Cash basis names one specific idea needed here.

The term **Cash basis** means the method of recording revenue and expenses only when cash is received or paid. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Accrual basis | the method of recording revenue when it is earned and expenses when they are incurred, whatever the cash timing
> Accrual basis names one specific idea needed here.

The term **Accrual basis** means the method of recording revenue when it is earned and expenses when they are incurred, whatever the cash timing. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Matching principle | the rule that expenses are recorded in the same period as the revenue they helped to earn
> Matching principle names one specific idea needed here.

The term **Matching principle** means the rule that expenses are recorded in the same period as the revenue they helped to earn. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Prepaid expense | a cost paid in advance, held as an asset until its benefit is used up
> Prepaid expense names one specific idea needed here.

The term **Prepaid expense** means a cost paid in advance, held as an asset until its benefit is used up. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Unearned revenue | money received before the work is done, held as a liability until the work is performed
> Unearned revenue names one specific idea needed here.

The term **Unearned revenue** means money received before the work is done, held as a liability until the work is performed. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Accrued expense | a cost already incurred in the period but not yet paid or recorded
> Accrued expense names one specific idea needed here.

The term **Accrued expense** means a cost already incurred in the period but not yet paid or recorded. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Accrued revenue | revenue earned in the period but not yet received or billed
> Accrued revenue names one specific idea needed here.

The term **Accrued revenue** means revenue earned in the period but not yet received or billed. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Depreciation | the sharing of an asset's cost across the periods in which the asset is used
> Depreciation names one specific idea needed here.

The term **Depreciation** means the sharing of an asset's cost across the periods in which the asset is used. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Accumulated depreciation | the total depreciation charged on an asset since it was bought
> Accumulated depreciation names one specific idea needed here.

The term **Accumulated depreciation** means the total depreciation charged on an asset since it was bought. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Contra account | an account that is deducted from a related account and has the opposite normal balance
> Contra account names one specific idea needed here.

The term **Contra account** means an account that is deducted from a related account and has the opposite normal balance. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Adjusted trial balance | a trial balance prepared after the adjusting entries have been posted
> Adjusted trial balance names one specific idea needed here.

The term **Adjusted trial balance** means a trial balance prepared after the adjusting entries have been posted. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

> Cash basis and accrual basis starts with a concrete question.

In Why Accounts Need Adjusting, we begin with cash basis and accrual basis rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> The matching principle and adjusting entries starts with a concrete question.

In Why Accounts Need Adjusting, we begin with the matching principle and adjusting entries rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig a timeline showing a payment made before, and a cost used after, the month-end | ch08-fig01.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Prepaid Items and Unearned Revenue

> Prepaid expenses and supplies used starts with a concrete question.

In Prepaid Items and Unearned Revenue, we begin with prepaid expenses and supplies used rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Unearned revenue earned over time starts with a concrete question.

In Prepaid Items and Unearned Revenue, we begin with unearned revenue earned over time rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig the four adjustment types in a two-by-two grid | ch08-fig02.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Accrued Items

> Accrued expenses such as unpaid wages starts with a concrete question.

In Accrued Items, we begin with accrued expenses such as unpaid wages rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Accrued revenue not yet billed starts with a concrete question.

In Accrued Items, we begin with accrued revenue not yet billed rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig before-and-after trial balance columns for one adjustment | ch08-fig03.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Depreciation as an Adjustment

> Spreading the cost of equipment over its life starts with a concrete question.

In Depreciation as an Adjustment, we begin with spreading the cost of equipment over its life rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Accumulated depreciation as a contra account starts with a concrete question.

In Depreciation as an Adjustment, we begin with accumulated depreciation as a contra account rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

* * *
## The Adjusted Trial Balance

> Applying the six adjustments to the trial balance starts with a concrete question.

In The Adjusted Trial Balance, we begin with applying the six adjustments to the trial balance rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Checking that totals still agree starts with a concrete question.

In The Adjusted Trial Balance, we begin with checking that totals still agree rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

* * *
## Worked Case

> The worked case applies the chapter rules to the documented running case.

Situation. Meghna and Sons, illustrative. Unadjusted trial balance at 31 January 2022 (Dr): Cash Tk 555,000; Accounts Receivable Tk 50,000; Supplies Tk 18,000; Prepaid Rent Tk 36,000; Equipment Tk 150,000; Owner's Drawings Tk 20,000; Wages Expense Tk 40,000; Utilities Expense Tk 8,000. (Cr): Accounts Payable Tk 38,000; Unearned Revenue Tk 24,000; Owner's Capital Tk 600,000; Service Revenue Tk 215,000. Each total Tk 877,000. Three events since the chapter 5 list: 2 Jan three months' rent paid in advance, Tk 36,000; 4 Jan supplies bought on account, Tk 18,000; 2 Jan a library paid Tk 24,000 for a 12-month repair contract running from 1 January. Month-end facts: (a) one month of rent used, Tk 12,000; (b) supplies on hand Tk 7,000, so Tk 11,000 used; (c) equipment cost Tk 150,000, residual Tk 30,000, 10 years, depreciation for one month Tk 1,000; (d) wages for the last days of January, unpaid, Tk 9,000; (e) one month of the library contract earned, Tk 2,000; (f) binding work finished but not billed, Tk 15,000. Adjusted balances by code: Accounts Receivable Tk 65,000; Supplies Tk 7,000; Prepaid Rent Tk 24,000; Accumulated Depreciation Tk 1,000 Cr; Wages Payable Tk 9,000 Cr; Unearned Revenue Tk 22,000 Cr; Service Revenue Tk 232,000 Cr; Wages Expense Tk 49,000; Rent Expense Tk 12,000; Supplies Expense Tk 11,000; Depreciation Expense Tk 1,000. Adjusted totals Tk 902,000 each side.

> The question is how the chapter method changes the way the case is recorded or understood.

Question. Using only the figures and facts given above, identify the relevant items, apply the rule introduced in the body of the chapter, and keep each step tied to a date or amount.

> The reasoning follows the chapter sequence rather than jumping to the result.

Reasoning. First identify the event or balance. Next classify it using the definitions in this chapter. Then perform the required recording or calculation step. Finally compare the result with the other records that should be affected.

> The case result is accepted only when the records agree with the stated facts.

Conclusion. The figures in the case file provide the boundary for the answer. A correct treatment uses those figures without inventing an additional transaction, date, or amount.

> A worked case is checked against the original facts.

Check. Re-read the case line by line. Confirm each amount, date, and classification. If a result cannot be traced to a stated fact or to an explicitly stated rule, it should not be added to the record.

* * *
> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

## Summary

> The chapter can be reduced to a small set of working rules.

Adjusting the Accounts is easiest to remember as a sequence: identify the fact, use the defined term precisely, apply the stated rule, and check the result against the other records. The examples and the worked case show how the method behaves when the setting changes.


## Think It Through

:q 08.t1 | What is the central problem that this chapter method is designed to solve?
:q 08.t2 | How would the treatment change if one important fact in the case were changed?

## Where People Go Wrong

> A common error is to use a familiar word without checking its accounting meaning.

Correction. Return to the definition, identify the exact item described, and then apply the rule. Another error is to perform a calculation without checking the period or record the number belongs to. Correction. Name the period and record before calculating.


## In History

> The historical case shows why careful records matter beyond a textbook example.

In September 2014 the British supermarket group Tesco announced that its profit had been overstated, because income from suppliers had been recorded too early. Search: Tesco 2014 profit overstatement supplier income timing. This note is included as a documented setting in which accounting records or accounting methods had practical consequences. The history illustrates the need for careful method; it does not replace the accounting rule.


## Review Questions

:q 08.r1 | State the main rule in your own words and apply it to a new small example.
:q 08.r2 | What check would you perform before accepting the result?
