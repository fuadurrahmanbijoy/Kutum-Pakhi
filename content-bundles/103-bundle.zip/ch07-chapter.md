:chapter VII | The Trial Balance and the Accounting Cycle
:mood What must be made visible before the next step can be trusted?
:desc This chapter builds one accounting idea at a time, from a practical problem to a rule and a checked application.
:plate ch07-plate.svg | a clerk with a magnifying glass over a long column of figures beside a

> The chapter begins with a practical question before giving the formal rule.

Suppose a reader has the records described in this chapter but must decide what they mean. The difficulty is not arithmetic alone. A useful accounting record depends on classification, timing, evidence, and a method that another person can follow. The Trial Balance and the Accounting Cycle addresses that difficulty by moving from a concrete situation to a rule and then back to the situation.

## Preparing a Trial Balance

> The chapter vocabulary is fixed before the procedures are applied.

These terms give the chapter a stable language. Each definition narrows an accounting idea so that later calculations and classifications do not drift.

@ Trial balance | a list of all ledger account balances showing that total debits equal total credits
> Trial balance names one specific idea needed here.

The term **Trial balance** means a list of all ledger account balances showing that total debits equal total credits. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Transposition error | a mistake in which two digits of a number are written in the wrong order
> Transposition error names one specific idea needed here.

The term **Transposition error** means a mistake in which two digits of a number are written in the wrong order. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Error of omission | a mistake in which a transaction, or one side of it, is left out of the records
> Error of omission names one specific idea needed here.

The term **Error of omission** means a mistake in which a transaction, or one side of it, is left out of the records. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Compensating error | two mistakes of equal size on opposite sides that cancel each other out
> Compensating error names one specific idea needed here.

The term **Compensating error** means two mistakes of equal size on opposite sides that cancel each other out. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Accounting cycle | the full set of steps from recording a transaction to preparing the next period's opening records
> Accounting cycle names one specific idea needed here.

The term **Accounting cycle** means the full set of steps from recording a transaction to preparing the next period's opening records. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

> Listing ledger balances in two columns starts with a concrete question.

In Preparing a Trial Balance, we begin with listing ledger balances in two columns rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> What equal totals do and do not prove starts with a concrete question.

In Preparing a Trial Balance, we begin with what equal totals do and do not prove rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig a trial balance with the two total lines highlighted | ch07-fig01.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Finding and Correcting Errors

> Errors that stop the totals agreeing starts with a concrete question.

In Finding and Correcting Errors, we begin with errors that stop the totals agreeing rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Errors the trial balance cannot find starts with a concrete question.

In Finding and Correcting Errors, we begin with errors the trial balance cannot find rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig the accounting cycle as a circle of steps | ch07-fig02.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Steps of the Accounting Cycle

> The cycle from transaction to closing starts with a concrete question.

In Steps of the Accounting Cycle, we begin with the cycle from transaction to closing rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Where each later chapter fits starts with a concrete question.

In Steps of the Accounting Cycle, we begin with where each later chapter fits rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

* * *
## Worked Case

> The worked case applies the chapter rules to the documented running case.

Situation. Meghna and Sons, illustrative. Ledger balances at 31 January 2022: Cash Tk 567,000 Dr; Accounts Receivable Tk 50,000 Dr; Equipment Tk 150,000 Dr; Owner's Drawings Tk 20,000 Dr; Wages Expense Tk 40,000 Dr; Utilities Expense Tk 8,000 Dr; Accounts Payable Tk 20,000 Cr; Owner's Capital Tk 600,000 Cr; Service Revenue Tk 215,000 Cr. Debit total Tk 835,000; credit total Tk 835,000. Three faulty copies: (a) Equipment copied as Tk 105,000, so debits are Tk 790,000, a difference of Tk 45,000; (b) the credit to Accounts Receivable for the 20 January collection of Tk 70,000 was never posted, so Accounts Receivable shows Tk 120,000 and debits total Tk 905,000 against credits of Tk 835,000; (c) Wages Expense copied as Tk 45,000 and Owner's Drawings copied as Tk 15,000, so the totals still agree at Tk 835,000.

> The question is how the chapter method changes the way the case is recorded or understood.

Question. Using only the figures and facts given above, identify the relevant items, apply the rule introduced in the body of the chapter, and keep each step tied to a date or amount.

> The reasoning follows the chapter sequence rather than jumping to the result.

Reasoning. First identify the event or balance. Next classify it using the definitions in this chapter. Then perform the required recording or calculation step. Finally compare the result with the other records that should be affected.

> The case result is accepted only when the records agree with the stated facts.

Conclusion. The figures in the case file provide the boundary for the answer. A correct treatment uses those figures without inventing an additional transaction, date, or amount.

> A worked case is checked against the original facts.

Check. Re-read the case line by line. Confirm each amount, date, and classification. If a result cannot be traced to a stated fact or to an explicitly stated rule, it should not be added to the record.

* * *
> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

## Summary

> The chapter can be reduced to a small set of working rules.

The Trial Balance and the Accounting Cycle is easiest to remember as a sequence: identify the fact, use the defined term precisely, apply the stated rule, and check the result against the other records. The examples and the worked case show how the method behaves when the setting changes.


## Think It Through

:q 07.t1 | What is the central problem that this chapter method is designed to solve?
:q 07.t2 | How would the treatment change if one important fact in the case were changed?

## Where People Go Wrong

> A common error is to use a familiar word without checking its accounting meaning.

Correction. Return to the definition, identify the exact item described, and then apply the rule. Another error is to perform a calculation without checking the period or record the number belongs to. Correction. Name the period and record before calculating.


## In History

> The historical case shows why careful records matter beyond a textbook example.

Barings Bank collapsed in February 1995 after trading losses were hidden in an error account numbered 88888 in its Singapore office. Search: Barings 1995 account 88888 Leeson. This note is included as a documented setting in which accounting records or accounting methods had practical consequences. The history illustrates the need for careful method; it does not replace the accounting rule.


## Review Questions

:q 07.r1 | State the main rule in your own words and apply it to a new small example.
:q 07.r2 | What check would you perform before accepting the result?
