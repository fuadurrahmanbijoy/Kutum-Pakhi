:glossary 01
Business | an organisation that provides goods or services to customers in order to earn money The chapter example shows how the term is used in practice.
Profit | the money left over when a business has paid all its costs out of the money it earns The chapter example shows how the term is used in practice.
Loss | the shortfall that results when a business's costs are greater than the money it earns The chapter example shows how the term is used in practice.
Record | a written note, made at the time, of something that happened and its money value The chapter example shows how the term is used in practice.
Customer | a person or organisation that pays for the goods or services a business provides The chapter example shows how the term is used in practice.
Supplier | a person or organisation that sells goods or services to a business The chapter example shows how the term is used in practice.
Owner | a person who put money into a business and has a claim on what is left after debts are paid The chapter example shows how the term is used in practice.
Service firm | a business that earns money by doing work for customers instead of selling goods The chapter example shows how the term is used in practice.
Merchandising firm | a business that buys finished goods and resells them without changing them The chapter example shows how the term is used in practice.
Manufacturing firm | a business that makes goods from materials and then sells them The chapter example shows how the term is used in practice.
Sole trader | one person who owns and runs a business and is personally responsible for its debts The chapter example shows how the term is used in practice.
Partnership | a business owned by two or more people who agree to share its profit The chapter example shows how the term is used in practice.
Company | a business that the law treats as a separate person, owned through shares The chapter example shows how the term is used in practice.

:glossary 02
Accounting | the process of recording, sorting, summarising and reporting the money events of a business The chapter example shows how the term is used in practice.
Financial accounting | accounting that prepares reports on a business for people outside it, such as banks and tax officers The chapter example shows how the term is used in practice.
Management accounting | accounting that gives a business's own managers the information they need to plan and decide The chapter example shows how the term is used in practice.
Cost accounting | accounting that works out what it costs to make a product or provide a service The chapter example shows how the term is used in practice.
User of accounting information | any person or group that reads accounting reports in order to make a decision The chapter example shows how the term is used in practice.
Business entity concept | the rule that a business is kept separate from its owner when records are made The chapter example shows how the term is used in practice.
Going concern concept | the assumption that a business will continue to operate for the foreseeable future The chapter example shows how the term is used in practice.
Money measurement concept | the rule that only events that can be stated in money are recorded The chapter example shows how the term is used in practice.
Historical cost concept | the rule that an asset is recorded at the price actually paid for it The chapter example shows how the term is used in practice.
Accounting standard | a detailed rule, issued by an official body, on how a type of item must be recorded and reported The chapter example shows how the term is used in practice.
Generally accepted accounting principles | the body of agreed rules that businesses follow when they prepare accounts The chapter example shows how the term is used in practice.

:glossary 03
Asset | something of value that a business owns or is owed, such as cash, equipment or money owed by customers The chapter example shows how the term is used in practice.
Liability | an amount that a business owes to someone outside the business The chapter example shows how the term is used in practice.
Owner's equity | the owner's claim on the business: what is left when liabilities are taken from assets The chapter example shows how the term is used in practice.
Accounting equation | the statement that assets always equal liabilities plus owner's equity The chapter example shows how the term is used in practice.
Revenue | the price of goods sold or services provided to customers in a period The chapter example shows how the term is used in practice.
Expense | a cost of running the business that is used up in earning revenue The chapter example shows how the term is used in practice.
Net income | the amount by which revenue is greater than expenses in a period The chapter example shows how the term is used in practice.
Net loss | the amount by which expenses are greater than revenue in a period The chapter example shows how the term is used in practice.
Drawings | money or goods the owner takes out of the business for personal use The chapter example shows how the term is used in practice.
Transaction | an event that has a money value and changes the accounting equation The chapter example shows how the term is used in practice.
Source document | a paper or electronic proof that a transaction took place, such as an invoice or receipt The chapter example shows how the term is used in practice.
Account receivable | an amount a customer owes the business for goods or services already provided The chapter example shows how the term is used in practice.
Account payable | an amount the business owes a supplier for goods or services already received The chapter example shows how the term is used in practice.

:glossary 04
Financial statement | a formal report that sums up the money results or position of a business The chapter example shows how the term is used in practice.
Income statement | the report that shows revenue, expenses and the resulting net income or net loss for a period The chapter example shows how the term is used in practice.
Statement of owner's equity | the report that shows how the owner's equity changed during a period The chapter example shows how the term is used in practice.
Balance sheet | the report that lists the assets, liabilities and owner's equity of a business on one date The chapter example shows how the term is used in practice.
Accounting period | the stretch of time, such as a month or a year, covered by one set of reports The chapter example shows how the term is used in practice.
Fiscal year | a twelve-month accounting period that can start in any month, such as 1 July to 30 June The chapter example shows how the term is used in practice.
Calendar year | the twelve months from 1 January to 31 December The chapter example shows how the term is used in practice.
Interim period | a period shorter than a year, such as a month or quarter, for which reports are prepared The chapter example shows how the term is used in practice.

:glossary 05
Account | a record of the increases and decreases in one kind of item, such as Cash or Wages Expense The chapter example shows how the term is used in practice.
Chart of accounts | the numbered list of all the accounts a business uses The chapter example shows how the term is used in practice.
Debit | an entry on the left side of an account The chapter example shows how the term is used in practice.
Credit | an entry on the right side of an account The chapter example shows how the term is used in practice.
Normal balance | the side of an account, debit or credit, on which its increases are recorded The chapter example shows how the term is used in practice.
Double-entry system | the method in which every transaction is recorded as equal debits and credits in at least two accounts The chapter example shows how the term is used in practice.
T-account | a simple drawing of an account, shaped like the letter T, with debits on the left and credits on the right The chapter example shows how the term is used in practice.
Account balance | the difference between the total debits and the total credits in an account The chapter example shows how the term is used in practice.

:glossary 06
Journal | the book in which each transaction is first recorded, in date order The chapter example shows how the term is used in practice.
Journal entry | one recorded transaction, showing the accounts debited and credited and the amounts The chapter example shows how the term is used in practice.
Compound entry | a journal entry that affects more than two accounts The chapter example shows how the term is used in practice.
Narration | a short written explanation placed under a journal entry The chapter example shows how the term is used in practice.
Ledger | the complete set of accounts of a business, kept together The chapter example shows how the term is used in practice.
Posting | copying the amounts from journal entries into the proper ledger accounts The chapter example shows how the term is used in practice.
Folio | a page or reference number used to link a journal entry with its ledger account The chapter example shows how the term is used in practice.

:glossary 07
Trial balance | a list of all ledger account balances showing that total debits equal total credits The chapter example shows how the term is used in practice.
Transposition error | a mistake in which two digits of a number are written in the wrong order The chapter example shows how the term is used in practice.
Error of omission | a mistake in which a transaction, or one side of it, is left out of the records The chapter example shows how the term is used in practice.
Compensating error | two mistakes of equal size on opposite sides that cancel each other out The chapter example shows how the term is used in practice.
Accounting cycle | the full set of steps from recording a transaction to preparing the next period's opening records The chapter example shows how the term is used in practice.

:glossary 08
Adjusting entry | a journal entry made at the end of a period to bring an account up to its correct amount The chapter example shows how the term is used in practice.
Cash basis | the method of recording revenue and expenses only when cash is received or paid The chapter example shows how the term is used in practice.
Accrual basis | the method of recording revenue when it is earned and expenses when they are incurred, whatever the cash timing The chapter example shows how the term is used in practice.
Matching principle | the rule that expenses are recorded in the same period as the revenue they helped to earn The chapter example shows how the term is used in practice.
Prepaid expense | a cost paid in advance, held as an asset until its benefit is used up The chapter example shows how the term is used in practice.
Unearned revenue | money received before the work is done, held as a liability until the work is performed The chapter example shows how the term is used in practice.
Accrued expense | a cost already incurred in the period but not yet paid or recorded The chapter example shows how the term is used in practice.
Accrued revenue | revenue earned in the period but not yet received or billed The chapter example shows how the term is used in practice.
Depreciation | the sharing of an asset's cost across the periods in which the asset is used The chapter example shows how the term is used in practice.
Accumulated depreciation | the total depreciation charged on an asset since it was bought The chapter example shows how the term is used in practice.
Contra account | an account that is deducted from a related account and has the opposite normal balance The chapter example shows how the term is used in practice.
Adjusted trial balance | a trial balance prepared after the adjusting entries have been posted The chapter example shows how the term is used in practice.

:glossary 09
Worksheet | a working paper, not a formal report, that lays out the trial balance, adjustments and statement figures in columns The chapter example shows how the term is used in practice.
Ten-column worksheet | a worksheet with five pairs of debit and credit columns, from unadjusted trial balance to balance sheet The chapter example shows how the term is used in practice.
Footing | adding up a column of figures to get its total The chapter example shows how the term is used in practice.

:glossary 10
Closing entry | a journal entry at the end of a period that moves a temporary account's balance to equity The chapter example shows how the term is used in practice.
Temporary account | an account for revenue, expense or drawings that is closed to zero at the end of each period The chapter example shows how the term is used in practice.
Permanent account | an account for an asset, liability or owner's capital whose balance carries into the next period The chapter example shows how the term is used in practice.
Income summary | a temporary account that collects revenue and expenses before the net result moves to capital The chapter example shows how the term is used in practice.
Reversing entry | an entry made on the first day of a new period that cancels an earlier adjusting entry The chapter example shows how the term is used in practice.

:glossary 11
Merchandise inventory | the goods a merchandising firm holds for resale The chapter example shows how the term is used in practice.
Purchases | the cost of goods bought during the period for resale The chapter example shows how the term is used in practice.
Sales | the selling price of goods sold to customers during the period The chapter example shows how the term is used in practice.
Sales return | goods that a customer sends back, reducing sales The chapter example shows how the term is used in practice.
Purchase return | goods that the firm sends back to a supplier, reducing purchases The chapter example shows how the term is used in practice.
Freight-in | the cost of carrying purchased goods to the firm's premises The chapter example shows how the term is used in practice.
Cost of goods sold | the cost of the goods that were sold during the period The chapter example shows how the term is used in practice.
Gross profit | net sales less cost of goods sold The chapter example shows how the term is used in practice.
Product cost | a cost included in the cost of the goods themselves The chapter example shows how the term is used in practice.
Period cost | a cost of running the business that is charged to the period in which it occurs The chapter example shows how the term is used in practice.
Operating expense | a cost of running the business apart from the cost of goods sold The chapter example shows how the term is used in practice.
Classified income statement | an income statement that groups items into sections such as sales, cost of goods sold and operating expenses The chapter example shows how the term is used in practice.
Current asset | an asset expected to be turned into cash or used within one year The chapter example shows how the term is used in practice.
Non-current asset | an asset the firm expects to use for longer than one year The chapter example shows how the term is used in practice.
Current liability | a debt due for payment within one year The chapter example shows how the term is used in practice.
Non-current liability | a debt not due for payment until after one year The chapter example shows how the term is used in practice.
Classified balance sheet | a balance sheet that groups assets and liabilities into current and non-current sections The chapter example shows how the term is used in practice.

:glossary 12
Special journal | a journal used for only one kind of repeated transaction, such as credit purchases The chapter example shows how the term is used in practice.
General journal | the journal used for transactions that no special journal covers The chapter example shows how the term is used in practice.
Invoice | a document sent by a seller stating the goods or services supplied and the amount due The chapter example shows how the term is used in practice.
Purchases journal | the special journal for goods bought on credit The chapter example shows how the term is used in practice.
Sales journal | the special journal for goods sold on credit The chapter example shows how the term is used in practice.
Cash receipts journal | the special journal for all money received The chapter example shows how the term is used in practice.
Cash disbursements journal | the special journal for all money paid out The chapter example shows how the term is used in practice.
Cash book | a book that records the receipts and payments passing through the firm's bank account The chapter example shows how the term is used in practice.

:glossary 13
Bank statement | a report from the bank listing the deposits, withdrawals and balance on the firm's account The chapter example shows how the term is used in practice.
Bank reconciliation statement | a statement that explains the difference between the cash book balance and the bank statement balance The chapter example shows how the term is used in practice.
Outstanding cheque | a cheque the firm has written and recorded but the bank has not yet paid The chapter example shows how the term is used in practice.
Deposit in transit | money the firm has recorded as banked but the bank has not yet added to its statement The chapter example shows how the term is used in practice.
Debit memo | a bank notice that it has taken money out of the firm's account, for example a charge The chapter example shows how the term is used in practice.
Credit memo | a bank notice that it has added money to the firm's account, for example a direct customer payment The chapter example shows how the term is used in practice.
Adjusted cash balance | the correct bank balance after all reconciling items have been included The chapter example shows how the term is used in practice.

:glossary 14
Inventory | goods a business holds for sale, or materials and part-made goods it holds to make products The chapter example shows how the term is used in practice.
Raw materials | the basic materials a manufacturer buys to make its products The chapter example shows how the term is used in practice.
Work in process | goods that have been started in production but are not yet finished The chapter example shows how the term is used in practice.
Finished goods | completed products waiting to be sold The chapter example shows how the term is used in practice.
Stockout | a shortage that occurs when goods are wanted by customers but none are available The chapter example shows how the term is used in practice.
Cost flow assumption | a rule that decides which purchase costs are assigned to goods sold and which to goods still held The chapter example shows how the term is used in practice.
First-in, first-out (FIFO) | the cost flow assumption that treats the oldest goods as the first sold The chapter example shows how the term is used in practice.
Last-in, first-out (LIFO) | the cost flow assumption that treats the newest goods as the first sold The chapter example shows how the term is used in practice.
Weighted average cost | a method that gives each unit the average cost of all units available The chapter example shows how the term is used in practice.
Ending inventory | the cost of goods still held at the end of the period The chapter example shows how the term is used in practice.

:glossary 15
Plant asset | a long-lived physical asset, such as equipment or a building, used in running the business The chapter example shows how the term is used in practice.
Capital expenditure | spending that adds to the cost of an asset, including delivery and installation The chapter example shows how the term is used in practice.
Useful life | the period over which an asset is expected to be of use to the business The chapter example shows how the term is used in practice.
Residual value | the amount the firm expects to receive when it disposes of the asset at the end of its useful life The chapter example shows how the term is used in practice.
Depreciable cost | the cost of an asset less its residual value The chapter example shows how the term is used in practice.
Straight-line method | a method that charges the same depreciation each year The chapter example shows how the term is used in practice.
Units-of-production method | a method that charges depreciation in proportion to how much the asset is used The chapter example shows how the term is used in practice.
Sum-of-the-years'-digits method | a method that charges more depreciation in early years, using a falling fraction of depreciable cost The chapter example shows how the term is used in practice.
Book value | an asset's cost less its accumulated depreciation The chapter example shows how the term is used in practice.
Depreciation schedule | a table showing the depreciation, accumulated depreciation and book value for each year The chapter example shows how the term is used in practice.

:glossary 16
Non-trading concern | an organisation, such as a club, that exists to serve its members and not to earn profit The chapter example shows how the term is used in practice.
Receipts and payments account | a summary of all cash received and paid in a period, whatever period it belongs to The chapter example shows how the term is used in practice.
Income and expenditure account | the report of a non-trading concern that matches income and costs to the period, like an income statement The chapter example shows how the term is used in practice.
Surplus | the amount by which income is greater than expenditure in a non-trading concern The chapter example shows how the term is used in practice.
Deficit | the amount by which expenditure is greater than income in a non-trading concern The chapter example shows how the term is used in practice.
Subscription | a regular payment that a member makes to a club The chapter example shows how the term is used in practice.
Partnership deed | the written agreement among partners on how the business is run and profit shared The chapter example shows how the term is used in practice.
Profit-sharing ratio | the agreed proportions in which partners share profit and loss The chapter example shows how the term is used in practice.
Interest on capital | an agreed payment to a partner for the capital put into the business The chapter example shows how the term is used in practice.
Appropriation account | the account that shows how a partnership's profit is divided among the partners The chapter example shows how the term is used in practice.

:glossary 17
Liquidation | the process of selling a business's assets, paying its debts and sharing what is left among the owners The chapter example shows how the term is used in practice.
Realisation | the sale of the assets of a business for cash The chapter example shows how the term is used in practice.
Capital deficiency | a debit balance in a partner's capital account after losses are shared The chapter example shows how the term is used in practice.
Cash distribution schedule | a table that shows how cash is paid out to creditors and partners step by step The chapter example shows how the term is used in practice.

:glossary 18
Share | one of the equal parts into which a company's capital is divided The chapter example shows how the term is used in practice.
Shareholder | a person or organisation that owns one or more shares in a company The chapter example shows how the term is used in practice.
Limited liability | the rule that shareholders can lose no more than they have paid or agreed to pay for their shares The chapter example shows how the term is used in practice.
Ordinary share | a share that carries the right to vote and to receive the profit left after other claims The chapter example shows how the term is used in practice.
Preference share | a share that has a right to a fixed dividend before ordinary shareholders are paid The chapter example shows how the term is used in practice.
Par value | the face value printed on a share The chapter example shows how the term is used in practice.
Share premium | the amount a company receives above par value when it issues a share The chapter example shows how the term is used in practice.
Dividend | a share of a company's profit paid to its shareholders The chapter example shows how the term is used in practice.
Application money | the first payment, made with a request to buy shares The chapter example shows how the term is used in practice.
Allotment | the company's decision to give shares to applicants, with the payment due on that step The chapter example shows how the term is used in practice.
Call | a later request to shareholders to pay part of the amount still owed on their shares The chapter example shows how the term is used in practice.

:glossary A1
Percentage | a number written as a part out of one hundred The chapter example shows how the term is used in practice.
Percentage change | the size of an increase or decrease shown as a percentage of the starting figure The chapter example shows how the term is used in practice.
Ratio | a comparison of two or more amounts, written with a colon, such as 2:1 The chapter example shows how the term is used in practice.
Average | the total of a set of numbers divided by how many numbers there are The chapter example shows how the term is used in practice.
Rounding | replacing a number by a nearby simpler number, such as the nearest whole taka The chapter example shows how the term is used in practice.
