:bundle
status: ok
failures: 0
chapters: 18
appendix: a1
changed-duplicates-resolved: 0
glossary-duplicates-removed: 0
chapter | ch01 | I | Business, Money and Records | 2798 | 3 | 13 | 4
chapter | ch02 | II | Accounting, Its Users and Its Rules | 2717 | 2 | 11 | 4
chapter | ch03 | III | The Accounting Equation | 3085 | 3 | 13 | 4
chapter | ch04 | IV | A First Look at the Financial Statements | 2761 | 2 | 8 | 4
chapter | ch05 | V | Accounts, Debits and Credits | 3092 | 3 | 8 | 4
chapter | ch06 | VI | Journal and Ledger | 2995 | 2 | 7 | 4
chapter | ch07 | VII | The Trial Balance and the Accounting Cycle | 2723 | 2 | 5 | 4
chapter | ch08 | VIII | Adjusting the Accounts | 3920 | 3 | 12 | 4
chapter | ch09 | IX | The Worksheet | 3202 | 2 | 3 | 4
chapter | ch10 | X | Closing the Books | 2828 | 2 | 5 | 4
chapter | ch11 | XI | Merchandising Company Accounts and Classified Statements | 3185 | 3 | 17 | 4
chapter | ch12 | XII | Special Journals and the Cash Book | 3180 | 2 | 8 | 4
chapter | ch13 | XIII | Bank Reconciliation | 3042 | 2 | 7 | 4
chapter | ch14 | XIV | Inventory | 3597 | 3 | 10 | 4
chapter | ch15 | XV | Plant Assets and Depreciation | 3762 | 3 | 10 | 4
chapter | ch16 | XVI | Non-Trading Concerns and Partnership Accounts | 3282 | 2 | 10 | 4
chapter | ch17 | XVII | Partnership Liquidation | 2916 | 2 | 4 | 4
chapter | ch18 | XVIII | Company Accounting and Shares | 2708 | 2 | 11 | 4
chapter | a1 | A1 | Maths You Will Use | 631 | 0 | 5 | 0
