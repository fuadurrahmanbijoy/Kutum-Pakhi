:chapter XI | Merchandising Company Accounts and Classified Statements
:mood What must be made visible before the next step can be trusted?
:desc This chapter builds one accounting idea at a time, from a practical problem to a rule and a checked application.
:plate ch11-plate.svg | a busy shop counter with shelves of books, string and paper parcels, 1

> The chapter begins with a practical question before giving the formal rule.

Suppose a reader has the records described in this chapter but must decide what they mean. The difficulty is not arithmetic alone. A useful accounting record depends on classification, timing, evidence, and a method that another person can follow. Merchandising Company Accounts and Classified Statements addresses that difficulty by moving from a concrete situation to a rule and then back to the situation.

## Buying and Selling Goods

> The chapter vocabulary is fixed before the procedures are applied.

These terms give the chapter a stable language. Each definition narrows an accounting idea so that later calculations and classifications do not drift.

@ Merchandise inventory | the goods a merchandising firm holds for resale
> Merchandise inventory names one specific idea needed here.

The term **Merchandise inventory** means the goods a merchandising firm holds for resale. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Purchases | the cost of goods bought during the period for resale
> Purchases names one specific idea needed here.

The term **Purchases** means the cost of goods bought during the period for resale. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Sales | the selling price of goods sold to customers during the period
> Sales names one specific idea needed here.

The term **Sales** means the selling price of goods sold to customers during the period. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Sales return | goods that a customer sends back, reducing sales
> Sales return names one specific idea needed here.

The term **Sales return** means goods that a customer sends back, reducing sales. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Purchase return | goods that the firm sends back to a supplier, reducing purchases
> Purchase return names one specific idea needed here.

The term **Purchase return** means goods that the firm sends back to a supplier, reducing purchases. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Freight-in | the cost of carrying purchased goods to the firm's premises
> Freight-in names one specific idea needed here.

The term **Freight-in** means the cost of carrying purchased goods to the firm's premises. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Cost of goods sold | the cost of the goods that were sold during the period
> Cost of goods sold names one specific idea needed here.

The term **Cost of goods sold** means the cost of the goods that were sold during the period. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Gross profit | net sales less cost of goods sold
> Gross profit names one specific idea needed here.

The term **Gross profit** means net sales less cost of goods sold. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Product cost | a cost included in the cost of the goods themselves
> Product cost names one specific idea needed here.

The term **Product cost** means a cost included in the cost of the goods themselves. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Period cost | a cost of running the business that is charged to the period in which it occurs
> Period cost names one specific idea needed here.

The term **Period cost** means a cost of running the business that is charged to the period in which it occurs. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Operating expense | a cost of running the business apart from the cost of goods sold
> Operating expense names one specific idea needed here.

The term **Operating expense** means a cost of running the business apart from the cost of goods sold. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Classified income statement | an income statement that groups items into sections such as sales, cost of goods sold and operating expenses
> Classified income statement names one specific idea needed here.

The term **Classified income statement** means an income statement that groups items into sections such as sales, cost of goods sold and operating expenses. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Current asset | an asset expected to be turned into cash or used within one year
> Current asset names one specific idea needed here.

The term **Current asset** means an asset expected to be turned into cash or used within one year. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Non-current asset | an asset the firm expects to use for longer than one year
> Non-current asset names one specific idea needed here.

The term **Non-current asset** means an asset the firm expects to use for longer than one year. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Current liability | a debt due for payment within one year
> Current liability names one specific idea needed here.

The term **Current liability** means a debt due for payment within one year. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Non-current liability | a debt not due for payment until after one year
> Non-current liability names one specific idea needed here.

The term **Non-current liability** means a debt not due for payment until after one year. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Classified balance sheet | a balance sheet that groups assets and liabilities into current and non-current sections
> Classified balance sheet names one specific idea needed here.

The term **Classified balance sheet** means a balance sheet that groups assets and liabilities into current and non-current sections. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

> Purchases, sales, returns and freight starts with a concrete question.

In Buying and Selling Goods, we begin with purchases, sales, returns and freight rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Cost of goods sold and gross profit starts with a concrete question.

In Buying and Selling Goods, we begin with cost of goods sold and gross profit rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig goods flowing from supplier to shop to customer with the account for each step | ch11-fig01.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Product Costs and Period Costs

> Product costs versus period costs starts with a concrete question.

In Product Costs and Period Costs, we begin with product costs versus period costs rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig a classified income statement with section brackets | ch11-fig02.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## The Classified Income Statement

> Net sales, cost of goods sold and gross profit starts with a concrete question.

In The Classified Income Statement, we begin with net sales, cost of goods sold and gross profit rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Operating expenses and net income starts with a concrete question.

In The Classified Income Statement, we begin with operating expenses and net income rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig a classified balance sheet with current and non-current groups | ch11-fig03.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## The Classified Balance Sheet

> Current and non-current assets and liabilities starts with a concrete question.

In The Classified Balance Sheet, we begin with current and non-current assets and liabilities rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Why the grouping helps a lender starts with a concrete question.

In The Classified Balance Sheet, we begin with why the grouping helps a lender rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

* * *
## Worked Case

> The worked case applies the chapter rules to the documented running case.

Situation. Meghna and Sons, illustrative. Year ended 31 December 2024, book sales. Sales Tk 3,100,000; sales returns Tk 40,000; inventory at 1 January Tk 180,000; purchases Tk 1,900,000; freight-in Tk 30,000; purchase returns Tk 25,000; inventory at 31 December Tk 210,000. Selling expenses: wages Tk 420,000; advertising Tk 60,000; delivery Tk 36,000. Administrative expenses: rent Tk 144,000; utilities Tk 48,000; insurance Tk 36,000; supplies Tk 24,000; depreciation Tk 45,000. Interest expense Tk 36,000. By code: net sales Tk 3,060,000; goods available Tk 2,085,000; cost of goods sold Tk 1,875,000; gross profit Tk 1,185,000; operating expenses Tk 813,000; operating profit Tk 372,000; net income Tk 336,000. Balance sheet at 31 December 2024: cash Tk 330,000; accounts receivable Tk 140,000; merchandise inventory Tk 210,000; supplies Tk 12,000; prepaid insurance Tk 18,000; equipment Tk 450,000 less accumulated depreciation Tk 90,000. Accounts payable Tk 160,000; wages payable Tk 14,000; unearned revenue Tk 10,000; bank loan Tk 300,000 repayable in three yearly instalments of Tk 100,000 from 2025 to 2027, so Tk 100,000 is current and Tk 200,000 is non-current. Total assets Tk 1,070,000; owner's capital at 1 January Tk 370,000; drawings Tk 120,000; closing capital Tk 586,000.

> The question is how the chapter method changes the way the case is recorded or understood.

Question. Using only the figures and facts given above, identify the relevant items, apply the rule introduced in the body of the chapter, and keep each step tied to a date or amount.

> The reasoning follows the chapter sequence rather than jumping to the result.

Reasoning. First identify the event or balance. Next classify it using the definitions in this chapter. Then perform the required recording or calculation step. Finally compare the result with the other records that should be affected.

> The case result is accepted only when the records agree with the stated facts.

Conclusion. The figures in the case file provide the boundary for the answer. A correct treatment uses those figures without inventing an additional transaction, date, or amount.

> A worked case is checked against the original facts.

Check. Re-read the case line by line. Confirm each amount, date, and classification. If a result cannot be traced to a stated fact or to an explicitly stated rule, it should not be added to the record.

* * *
> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

## Summary

> The chapter can be reduced to a small set of working rules.

Merchandising Company Accounts and Classified Statements is easiest to remember as a sequence: identify the fact, use the defined term precisely, apply the stated rule, and check the result against the other records. The examples and the worked case show how the method behaves when the setting changes.


## Think It Through

:q 11.t1 | What is the central problem that this chapter method is designed to solve?
:q 11.t2 | How would the treatment change if one important fact in the case were changed?

## Where People Go Wrong

> A common error is to use a familiar word without checking its accounting meaning.

Correction. Return to the definition, identify the exact item described, and then apply the rule. Another error is to perform a calculation without checking the period or record the number belongs to. Correction. Name the period and record before calculating.


## In History

> The historical case shows why careful records matter beyond a textbook example.

Amazon began selling books online from Seattle in July 1995, an example of a merchandising firm built on buying and reselling goods. Search: Amazon 1995 first books sold online. This note is included as a documented setting in which accounting records or accounting methods had practical consequences. The history illustrates the need for careful method; it does not replace the accounting rule.


## Review Questions

:q 11.r1 | State the main rule in your own words and apply it to a new small example.
:q 11.r2 | What check would you perform before accepting the result?
