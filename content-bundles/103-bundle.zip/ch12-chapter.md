:chapter XII | Special Journals and the Cash Book
:mood What must be made visible before the next step can be trusted?
:desc This chapter builds one accounting idea at a time, from a practical problem to a rule and a checked application.
:plate ch12-plate.svg | a post-office sorting table with pigeonholes and tied bundles of lette

> The chapter begins with a practical question before giving the formal rule.

Suppose a reader has the records described in this chapter but must decide what they mean. The difficulty is not arithmetic alone. A useful accounting record depends on classification, timing, evidence, and a method that another person can follow. Special Journals and the Cash Book addresses that difficulty by moving from a concrete situation to a rule and then back to the situation.

## Why Special Journals Exist

> The chapter vocabulary is fixed before the procedures are applied.

These terms give the chapter a stable language. Each definition narrows an accounting idea so that later calculations and classifications do not drift.

@ Special journal | a journal used for only one kind of repeated transaction, such as credit purchases
> Special journal names one specific idea needed here.

The term **Special journal** means a journal used for only one kind of repeated transaction, such as credit purchases. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ General journal | the journal used for transactions that no special journal covers
> General journal names one specific idea needed here.

The term **General journal** means the journal used for transactions that no special journal covers. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Invoice | a document sent by a seller stating the goods or services supplied and the amount due
> Invoice names one specific idea needed here.

The term **Invoice** means a document sent by a seller stating the goods or services supplied and the amount due. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Purchases journal | the special journal for goods bought on credit
> Purchases journal names one specific idea needed here.

The term **Purchases journal** means the special journal for goods bought on credit. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Sales journal | the special journal for goods sold on credit
> Sales journal names one specific idea needed here.

The term **Sales journal** means the special journal for goods sold on credit. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Cash receipts journal | the special journal for all money received
> Cash receipts journal names one specific idea needed here.

The term **Cash receipts journal** means the special journal for all money received. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Cash disbursements journal | the special journal for all money paid out
> Cash disbursements journal names one specific idea needed here.

The term **Cash disbursements journal** means the special journal for all money paid out. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

@ Cash book | a book that records the receipts and payments passing through the firm's bank account
> Cash book names one specific idea needed here.

The term **Cash book** means a book that records the receipts and payments passing through the firm's bank account. A tiny example is to take one event or balance from the chapter and ask whether it meets every part of the definition. If it does, use the term; if it does not, use a more accurate description.

> Repeated transactions and the time they waste starts with a concrete question.

In Why Special Journals Exist, we begin with repeated transactions and the time they waste rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> The general journal still has a place starts with a concrete question.

In Why Special Journals Exist, we begin with the general journal still has a place rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig a purchases journal and a sales journal with their columns | ch12-fig01.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## Purchases and Sales Journals

> Recording purchases on credit starts with a concrete question.

In Purchases and Sales Journals, we begin with recording purchases on credit rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Recording sales on credit starts with a concrete question.

In Purchases and Sales Journals, we begin with recording sales on credit rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

:fig a cash book with a receipts side and a payments side | ch12-fig02.svg
> The figure shows the same relationship in a compact visual form.

Read the labels and positions first. The picture is not a substitute for the rule; it is a second representation of the same relationship.

* * *
## The Cash Book and Cash Disbursements

> Cash receipts and the cash book starts with a concrete question.

In The Cash Book and Cash Disbursements, we begin with cash receipts and the cash book rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

> Cash disbursements journal starts with a concrete question.

In The Cash Book and Cash Disbursements, we begin with cash disbursements journal rather than a list of rules. The first task is to identify the item or event being described and to separate it from nearby ideas that may look similar. This matters because accounting records are useful only when the same fact is classified in the same way each time.
> The procedure keeps the idea tied to the facts.

Once that question is answered, state the procedure in ordinary language. Identify the relevant fact, place it in the appropriate part of the accounting system, and check whether the resulting information agrees with the other records affected by the same event. The check is part of the method.
> A changed situation tests whether the rule has been understood.

Change the amount, date, or setting without changing the underlying principle. If the structure stays the same, the method should remain stable. If the facts change the classification or timing, the treatment should change for that reason. This is how a definition becomes a working accounting idea.

* * *
## Worked Case

> The worked case applies the chapter rules to the documented running case.

Situation. Meghna and Sons, illustrative. May 2024. Credit purchases: 3 May Padma Books Ltd Tk 120,000; 11 May Jamuna Distributors Tk 85,000; 19 May Padma Books Ltd Tk 60,000; 27 May Surma Stationers Tk 45,000 (total Tk 310,000). Credit sales: 4 May Dhaka Public School Tk 70,000; 13 May Green Valley College Tk 95,000; 22 May Notun Library Tk 40,000 (total Tk 205,000). Bank receipts: 9 May cash sales banked Tk 150,000; 20 May Dhaka Public School Tk 70,000; 28 May Green Valley College Tk 95,000 (total Tk 315,000). Bank payments: 15 May Padma Books Ltd, cheque 5001 Tk 120,000; 17 May rent, cheque 5002 Tk 12,000; 25 May wages, cheque 5003 Tk 35,000; 30 May Jamuna Distributors, cheque 5004 Tk 85,000 (total Tk 252,000). Bank balance at 1 May Tk 250,000; cash book balance at 31 May Tk 313,000. Unpaid at 31 May: Padma Books Ltd Tk 60,000 and Surma Stationers Tk 45,000; Notun Library owes Tk 40,000.

> The question is how the chapter method changes the way the case is recorded or understood.

Question. Using only the figures and facts given above, identify the relevant items, apply the rule introduced in the body of the chapter, and keep each step tied to a date or amount.

> The reasoning follows the chapter sequence rather than jumping to the result.

Reasoning. First identify the event or balance. Next classify it using the definitions in this chapter. Then perform the required recording or calculation step. Finally compare the result with the other records that should be affected.

> The case result is accepted only when the records agree with the stated facts.

Conclusion. The figures in the case file provide the boundary for the answer. A correct treatment uses those figures without inventing an additional transaction, date, or amount.

> A worked case is checked against the original facts.

Check. Re-read the case line by line. Confirm each amount, date, and classification. If a result cannot be traced to a stated fact or to an explicitly stated rule, it should not be added to the record.

* * *
> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

> A further check keeps the rule tied to the facts.

Repeat the method with the same kind of information but a different amount or date. The purpose is to separate the structure of the rule from the particular numbers in the example. When the structure stays the same, the method should remain stable. When the facts change the classification or timing, the treatment must change for that reason.

## Summary

> The chapter can be reduced to a small set of working rules.

Special Journals and the Cash Book is easiest to remember as a sequence: identify the fact, use the defined term precisely, apply the stated rule, and check the result against the other records. The examples and the worked case show how the method behaves when the setting changes.


## Think It Through

:q 12.t1 | What is the central problem that this chapter method is designed to solve?
:q 12.t2 | How would the treatment change if one important fact in the case were changed?

## Where People Go Wrong

> A common error is to use a familiar word without checking its accounting meaning.

Correction. Return to the definition, identify the exact item described, and then apply the rule. Another error is to perform a calculation without checking the period or record the number belongs to. Correction. Name the period and record before calculating.


## In History

> The historical case shows why careful records matter beyond a textbook example.

Francesco di Marco Datini, a merchant of Prato (about 1335 to 1410), kept many separate books for his trade; the surviving archive holds hundreds of ledgers and tens of thousands of letters. Search: Datini archive Prato ledgers letters. This note is included as a documented setting in which accounting records or accounting methods had practical consequences. The history illustrates the need for careful method; it does not replace the accounting rule.


## Review Questions

:q 12.r1 | State the main rule in your own words and apply it to a new small example.
:q 12.r2 | What check would you perform before accepting the result?
