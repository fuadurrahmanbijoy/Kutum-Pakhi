:chapter V | Elasticity of Demand
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Teach how to measure how strongly buyers respond, with percentages, and what the answer means for revenue. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch05-plate.svg | a laboratory spring balance with brass weights on a draper's counter, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Teach how to measure how strongly buyers respond, with percentages, and what the answer means for revenue. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic); total revenue Tk 12,000 (60 x 200) to Tk 12,408 (66 x 188). Messier rung: midpoint method gives about 0.65. Second good: a Tk 300 atlas, price cut to Tk 270 raised weekly sales from 20 to 30: -10 per cent price, +50 per cent quantity, elasticity 5 in size (elastic); revenue Tk 6,000 to Tk 8,100. Income elasticity: a household income rose from Tk 30,000 to Tk 33,000 a month and its novels bought rose from 50 to 60 a year: +10 per cent and +20 per cent, elasticity 2. Cross elasticity: a rival shop raised its notebook price from Tk 50 to Tk 55 (+10 per cent) and Meghna and Sons sales of its own notebooks rose from 100 to 108 a week (+8 per cent), cross elasticity 0.8. The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 5.1 | Measuring Responsiveness | technique | 775
> This section asks what measuring responsiveness means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Elasticity | a measure of how strongly one quantity responds when another quantity changes
> Elasticity is the working idea for this part of the chapter.

The term **Elasticity** means a measure of how strongly one quantity responds when another quantity changes. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in measuring responsiveness, before moving to the next step.
@ Percentage change | the size of a change divided by the starting value, multiplied by 100
> Percentage change is the working idea for this part of the chapter.

The term **Percentage change** means the size of a change divided by the starting value, multiplied by 100. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in measuring responsiveness, before moving to the next step.
@ Price elasticity of demand | the percentage change in quantity demanded divided by the percentage change in price
> Price elasticity of demand is the working idea for this part of the chapter.

The term **Price elasticity of demand** means the percentage change in quantity demanded divided by the percentage change in price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in measuring responsiveness, before moving to the next step.
> Measuring Responsiveness is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> Measuring Responsiveness is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Measuring Responsiveness is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in measuring responsiveness to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 5.2 | Forms of Price Elasticity | new idea | 450
> This section asks what forms of price elasticity means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Elastic demand | demand for which the percentage fall in quantity is greater than the percentage rise in price
> Elastic demand is the working idea for this part of the chapter.

The term **Elastic demand** means demand for which the percentage fall in quantity is greater than the percentage rise in price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in forms of price elasticity, before moving to the next step.
@ Inelastic demand | demand for which the percentage fall in quantity is smaller than the percentage rise in price
> Inelastic demand is the working idea for this part of the chapter.

The term **Inelastic demand** means demand for which the percentage fall in quantity is smaller than the percentage rise in price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in forms of price elasticity, before moving to the next step.
@ Unit elastic demand | demand for which the percentage change in quantity equals the percentage change in price
> Unit elastic demand is the working idea for this part of the chapter.

The term **Unit elastic demand** means demand for which the percentage change in quantity equals the percentage change in price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in forms of price elasticity, before moving to the next step.
> Forms of Price Elasticity is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Forms of Price Elasticity is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Forms of Price Elasticity is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in forms of price elasticity to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 5.3 | What Affects Price Elasticity | new idea | 225
> This section asks what what affects price elasticity means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Perfectly elastic demand | demand that vanishes completely for any price rise, however small, shown as a flat curve
> Perfectly elastic demand is the working idea for this part of the chapter.

The term **Perfectly elastic demand** means demand that vanishes completely for any price rise, however small, shown as a flat curve. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what affects price elasticity, before moving to the next step.
@ Perfectly inelastic demand | demand that does not change at all when price changes, shown as a vertical curve
> Perfectly inelastic demand is the working idea for this part of the chapter.

The term **Perfectly inelastic demand** means demand that does not change at all when price changes, shown as a vertical curve. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what affects price elasticity, before moving to the next step.
@ Total revenue | the money a seller receives from sales, found by price multiplied by quantity sold
> Total revenue is the working idea for this part of the chapter.

The term **Total revenue** means the money a seller receives from sales, found by price multiplied by quantity sold. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what affects price elasticity, before moving to the next step.
> What Affects Price Elasticity is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> What Affects Price Elasticity is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in what affects price elasticity to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 5.4 | Income and Cross Elasticity | technique | 550
> This section asks what income and cross elasticity means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Income elasticity of demand | the percentage change in quantity demanded divided by the percentage change in buyers' income
> Income elasticity of demand is the working idea for this part of the chapter.

The term **Income elasticity of demand** means the percentage change in quantity demanded divided by the percentage change in buyers' income. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in income and cross elasticity, before moving to the next step.
@ Cross elasticity of demand | the percentage change in quantity demanded of one good divided by the percentage change in another good's price
> Cross elasticity of demand is the working idea for this part of the chapter.

The term **Cross elasticity of demand** means the percentage change in quantity demanded of one good divided by the percentage change in another good's price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic). In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in income and cross elasticity, before moving to the next step.
> Income and Cross Elasticity is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Income and Cross Elasticity is understood by separating the question into small steps.

The central question in income and cross elasticity is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in income and cross elasticity to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig a steep and a flat demand curve side by side for the same price change | ch05-fig01.svg
:fig five demand curves for the five forms of price elasticity | ch05-fig02.svg
:fig total revenue before and after a price rise for an inelastic and an elastic good | ch05-fig03.svg
:fig a number line placing income elasticity values for necessities, comforts and luxuries | ch05-fig04.svg

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). Price elasticity: 200-page exercise book, price rose from Tk 60 to Tk 66 on 2 March 2026; weekly sales fell from 200 to 188. Clean figures: price change +10 per cent, quantity change -6 per cent, elasticity 0.6 (inelastic); total revenue Tk 12,000 (60 x 200) to Tk 12,408 (66 x 188). Messier rung: midpoint method gives about 0.65. Second good: a Tk 300 atlas, price cut to Tk 270 raised weekly sales from 20 to 30: -10 per cent price, +50 per cent quantity, elasticity 5 in size (elastic); revenue Tk 6,000 to Tk 8,100. Income elasticity: a household income rose from Tk 30,000 to Tk 33,000 a month and its novels bought rose from 50 to 60 a year: +10 per cent and +20 per cent, elasticity 2. Cross elasticity: a rival shop raised its notebook price from Tk 50 to Tk 55 (+10 per cent) and Meghna and Sons sales of its own notebooks rose from 100 to 108 a week (+8 per cent), cross elasticity 0.8. Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Teach how to measure how strongly buyers respond, with percentages, and what the answer means for revenue. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 5.t1 | compute three elasticities from new price-quantity pairs and name each form, say which goods have low elasticity and why, compute income and cross elasticity from new data
:q 5.t2 | a seller wants more revenue — decide from the elasticity whether to cut or raise the price

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to Alfred Marshall introduces elasticity of demand in Principles of Economics, 1890; search: Marshall Principles of Economics 1890 elasticity of demand origin. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Sources
> The chapter uses a small number of historical references to anchor its defining ideas.

Further reading and historical attribution should be checked against the original works and reliable archival or institutional sources. The chapter does not require the reader to accept a historical interpretation merely because it appears in a secondary account.

## Review Questions
:q 5.3 | compute three elasticities from new price-quantity pairs and name each form, say which goods have low elasticity and why, compute income and cross elasticity from new data
:q 5.4 | a seller wants more revenue — decide from the elasticity whether to cut or raise the price
:q 5.5 | after the formula passage and after the revenue passage
:pause 5.p6 | after the formula passage
:pause 5.p7 | the revenue passage

:read Alfred Marshall introduces elasticity of demand in Principles of Economics, 1890, historical case reference
