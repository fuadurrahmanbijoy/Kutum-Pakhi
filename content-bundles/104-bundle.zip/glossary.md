:glossary 01
Economics | the study of how people, firms and societies choose among uses of limited resources to meet wants. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Want | something a person would like to have, whether or not they can pay for it. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Resource | anything used to make goods and services: land, labour, capital and enterprise. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Factor of production | one of the four kinds of resource used in making things: land, labour, capital, enterprise. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Good | a physical thing people buy to satisfy a want, such as a book or a pen. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Service | an activity done for someone, such as binding a thesis or delivering parcels. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Scarcity | the condition in which resources are too few to satisfy all the wants people have. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Choice | picking one option and giving up the others because resources cannot cover every option. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Opportunity cost | the value of the best alternative given up when a choice is made. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Firm | an organisation that uses resources to make goods or services and sell them. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Household | a person or group living together that buys goods and services and supplies resources. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Economic organisation | the way a society or business arranges who decides what is made, how and for whom. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Economic system | the set of rules and institutions a country uses to answer its basic economic problems. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 02
Science | a body of knowledge built by observing facts, forming explanations and testing them. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Art | the skilled use of knowledge to reach a practical aim. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Positive statement | a claim about what is, which can be checked against facts. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Normative statement | a claim about what ought to be, resting on values and opinion. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Ceteris paribus | a Latin phrase meaning other things being equal, used to study one change at a time. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Economic law | a statement of a regular tendency in human choices, true when other things stay equal. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Model | a simplified picture of a situation that keeps only the features needed to answer a question. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Microeconomics | the study of choices made by single households, firms and markets. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Macroeconomics | the study of the economy as a whole, such as total output, jobs and the general price level. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 03
Utility | the satisfaction a person gets from using a good or service. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Consumer | a person who buys or uses goods and services to meet wants. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Total utility | the whole satisfaction from all the units of a good consumed in a period. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Marginal utility | the extra satisfaction gained from consuming one more unit of a good. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Util | an imaginary unit used to count satisfaction in examples. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Cardinal measurement | measuring satisfaction in numbers, such as 20 utils, so amounts can be added and compared. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Ordinal measurement | ranking satisfaction as first, second and third without giving it a number. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Law of diminishing marginal utility | as a person consumes more units of a good, the extra satisfaction from each further unit falls. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Saturation point | the quantity at which marginal utility reaches zero and total utility stops rising. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 04
Demand | the quantity of a good people are willing and able to buy at each possible price, in a given period. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Quantity demanded | the amount people plan to buy at one particular price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Demand schedule | a table listing the quantity demanded at each of several prices. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Demand curve | a line on a graph showing the quantity demanded at each price, other things equal. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Market | any arrangement that brings buyers and sellers of a good together. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Market demand | the sum of all individual buyers' demands for a good at each price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Law of demand | when the price of a good rises, quantity demanded falls, and when it falls, quantity demanded rises, other things equal. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Determinants of demand | the things other than the good's own price that change how much people want to buy. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Normal good | a good for which demand rises when buyers' incomes rise. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Inferior good | a good for which demand falls when buyers' incomes rise. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Substitute goods | goods that can replace each other, so a rise in one's price raises demand for the other. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Complementary goods | goods used together, so a rise in one's price lowers demand for the other. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Giffen good | a rare inferior good for which a price rise leads buyers to buy more of it. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Snob effect | a fall in demand for a good because more people begin to own it. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Bandwagon effect | a rise in demand for a good because more people are seen to buy it. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 05
Elasticity | a measure of how strongly one quantity responds when another quantity changes. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Percentage change | the size of a change divided by the starting value, multiplied by 100. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Price elasticity of demand | the percentage change in quantity demanded divided by the percentage change in price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Elastic demand | demand for which the percentage fall in quantity is greater than the percentage rise in price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Inelastic demand | demand for which the percentage fall in quantity is smaller than the percentage rise in price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Unit elastic demand | demand for which the percentage change in quantity equals the percentage change in price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Perfectly elastic demand | demand that vanishes completely for any price rise, however small, shown as a flat curve. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Perfectly inelastic demand | demand that does not change at all when price changes, shown as a vertical curve. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Total revenue | the money a seller receives from sales, found by price multiplied by quantity sold. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Income elasticity of demand | the percentage change in quantity demanded divided by the percentage change in buyers' income. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Cross elasticity of demand | the percentage change in quantity demanded of one good divided by the percentage change in another good's price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 06
Consumption | the using up of goods and services to meet wants. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Willingness to pay | the highest price a buyer would accept to get one unit of a good. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Consumer surplus | the gap between what a buyer would pay and what is actually paid. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Indifference curve | a line joining bundles of two goods that give a consumer the same satisfaction. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Indifference map | a set of indifference curves, with curves farther from the origin showing more satisfaction. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Marginal rate of substitution | the amount of one good a consumer will give up to gain one more unit of the other. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Budget line | a line showing every bundle of two goods a consumer can exactly afford with a given income. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Consumer equilibrium | the affordable bundle that gives a consumer the greatest satisfaction. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 07
Supply | the quantity of a good sellers are willing and able to offer at each possible price, in a given period. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Quantity supplied | the amount sellers plan to offer at one particular price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Supply schedule | a table listing the quantity supplied at each of several prices. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Supply curve | a line on a graph showing the quantity supplied at each price, other things equal. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Law of supply | when the price of a good rises, quantity supplied rises, and when it falls, quantity supplied falls, other things equal. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Determinants of supply | the things other than the good's own price that change how much sellers offer. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Backward-bending supply curve | a curve showing that beyond some pay level a worker offers fewer hours as pay rises further. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Price elasticity of supply | the percentage change in quantity supplied divided by the percentage change in price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Elastic supply | supply for which quantity responds by a larger percentage than price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Inelastic supply | supply for which quantity responds by a smaller percentage than price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 08
Equilibrium | a state in which nothing pushes the price or quantity to change. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Equilibrium price | the price at which quantity demanded equals quantity supplied. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Equilibrium quantity | the quantity bought and sold at the equilibrium price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Excess demand | the amount by which quantity demanded exceeds quantity supplied at a price below equilibrium. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Excess supply | the amount by which quantity supplied exceeds quantity demanded at a price above equilibrium. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Price ceiling | a legal maximum price that may be charged for a good. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Price floor | a legal minimum price that may be charged for a good. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Producer surplus | the gap between the price a seller receives and the lowest price the seller would accept. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Total surplus | consumer surplus plus producer surplus, a measure of the gain from trade. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 09
Production | the process of turning resources into goods and services. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Input | a resource used in production. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Output | the goods or services produced. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Production function | a rule or table linking the quantities of inputs used to the greatest output they can make. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Short run | a period too short to change at least one input, such as machines or floor space. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Long run | a period long enough to change every input. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Fixed input | an input whose quantity cannot be changed in the short run. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Variable input | an input whose quantity can be changed even in the short run. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Total product | the whole output from a given amount of inputs. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Average product | total product divided by the number of units of the variable input. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Marginal product | the extra output from adding one more unit of the variable input. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Law of diminishing returns | when more of one input is added to fixed inputs, the extra output eventually falls. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Returns to scale | the change in output when all inputs are changed by the same proportion. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Increasing returns to scale | output rises by a larger proportion than inputs. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Constant returns to scale | output rises by the same proportion as inputs. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Decreasing returns to scale | output rises by a smaller proportion than inputs. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 10
Cost | the value of the resources used up in making a good or service. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Explicit cost | a cost paid out in money to others, such as rent or wages. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Implicit cost | the value of resources the owner supplies, such as own time, for which no payment is made. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Fixed cost | a cost that stays the same however much is produced in the short run. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Variable cost | a cost that rises and falls with the amount produced. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Total cost | fixed cost plus variable cost at a given output. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Average cost | total cost divided by the number of units produced. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Marginal cost | the extra cost of producing one more unit. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Prime cost | the direct cost of materials and labour that go into a unit of output. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Supplementary cost | the cost of items apart from prime cost, such as rent and equipment, which remain even when output is nil. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Long-run average cost curve | a curve showing the lowest average cost of each output when every input can be changed. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Isoquant | a curve joining the input combinations that all make the same output. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Isocost line | a line joining the input combinations that all cost the same total. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Least-cost combination | the mix of inputs that makes a given output for the lowest total cost. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 11
Market structure | the features of a market, such as number of sellers, type of product and ease of entry, that shape how firms behave. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Competitive market | a market with many buyers and sellers, so no single one can set the price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Industry | all the firms that make the same or very similar goods. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Price taker | a firm that must accept the market price because it is too small to change it. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Price maker | a firm large enough that its own output choices affect the price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Marginal revenue | the extra revenue gained by selling one more unit. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Perfect competition | a market with many sellers, an identical product, free entry and full information, so each firm takes the price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Pure competition | a market with many sellers, an identical product and free entry, where buyers may lack full information or free movement. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Monopoly | a market with one seller and no close substitute, so that seller sets the price. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Pure monopoly | a monopoly in which one seller supplies the whole market with a product that has no close substitute. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Bilateral monopoly | a market with a single seller facing a single buyer. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Monopolistic competition | a market with many sellers of similar but not identical goods and free entry. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Product differentiation | making a firm's good different from rivals' in quality, design, brand or service. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Oligopoly | a market with a few large sellers, each aware of the others' actions. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Profit maximisation | choosing the output at which the gap between total revenue and total cost is greatest. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary 12
Factor price | the payment a factor of production earns: rent for land, wages for labour, interest for capital, profit for enterprise. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Economic rent | the payment to a factor above the minimum needed to keep it in its present use. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Differential rent | the extra return a better plot earns over the poorest plot in use. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Wage | the payment made to labour for its work. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Nominal wage | the wage counted in money. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Real wage | the amount of goods and services a nominal wage can buy. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Interest | the payment for the use of borrowed money or capital over time. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Rate of interest | the interest paid in a year as a percentage of the amount borrowed. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Profit | the reward of enterprise: what remains of revenue after the other factors are paid. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Economic profit | revenue less all costs, explicit and implicit. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Accounting profit | revenue less explicit costs only. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Normal profit | the least profit that keeps a firm in business, equal to the implicit costs of the owner's own resources. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Risk bearing | taking on the chance of loss when production is uncertain. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.
Marginal productivity theory | the view that each factor is paid in line with the extra output its last unit adds. The chapter uses this definition consistently; the running example shows how the term works before it is applied to a changed situation.

:glossary A1
