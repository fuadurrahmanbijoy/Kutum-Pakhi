:chapter II | Economic Reasoning, Laws and the Scope of Microeconomics
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Teach the reader how economists argue, what an economic law is, and where microeconomics fits. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch02-plate.svg | a lecture-hall demonstrator beside a brass orrery and a slate board, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Teach the reader how economists argue, what an economic law is, and where microeconomics fits. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at Tk 60 and 200 copies sell in a week. Ledger note A, in Shirin Meghna's hand: when the price was raised to Tk 66 on 2 March 2026, weekly sales fell to 188. Ledger note B, in Imran Meghna's hand: students should not have to pay more than Tk 60. Note A can be checked against sales records; note B cannot. Regular tendency recorded over three years: textbook sales rise in the two weeks before each term begins (this holds when the shop's prices stay unchanged). Micro and macro: the shop's price and stock are micro matters; the movement of the average price of all goods in Bangladesh is a macro matter. The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 2.1 | Science, Art and Normative Views | new idea | 550
> This section asks what science, art and normative views means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Science | a body of knowledge built by observing facts, forming explanations and testing them
> Science is the working idea for this part of the chapter.

The term **Science** means a body of knowledge built by observing facts, forming explanations and testing them. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in science, art and normative views, before moving to the next step.
@ Art | the skilled use of knowledge to reach a practical aim
> Art is the working idea for this part of the chapter.

The term **Art** means the skilled use of knowledge to reach a practical aim. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in science, art and normative views, before moving to the next step.
@ Positive statement | a claim about what is, which can be checked against facts
> Positive statement is the working idea for this part of the chapter.

The term **Positive statement** means a claim about what is, which can be checked against facts. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in science, art and normative views, before moving to the next step.
> Science, Art and Normative Views is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> Science, Art and Normative Views is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in science, art and normative views to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 2.2 | Economic Laws | new idea | 550
> This section asks what economic laws means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Normative statement | a claim about what ought to be, resting on values and opinion
> Normative statement is the working idea for this part of the chapter.

The term **Normative statement** means a claim about what ought to be, resting on values and opinion. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in economic laws, before moving to the next step.
@ Ceteris paribus | a Latin phrase meaning other things being equal, used to study one change at a time
> Ceteris paribus is the working idea for this part of the chapter.

The term **Ceteris paribus** means a Latin phrase meaning other things being equal, used to study one change at a time. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in economic laws, before moving to the next step.
@ Economic law | a statement of a regular tendency in human choices, true when other things stay equal
> Economic law is the working idea for this part of the chapter.

The term **Economic law** means a statement of a regular tendency in human choices, true when other things stay equal. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in economic laws, before moving to the next step.
> Economic Laws is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Economic Laws is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in economic laws to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 2.3 | Microeconomics and Macroeconomics | framework | 450
> This section asks what microeconomics and macroeconomics means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Model | a simplified picture of a situation that keeps only the features needed to answer a question
> Model is the working idea for this part of the chapter.

The term **Model** means a simplified picture of a situation that keeps only the features needed to answer a question. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in microeconomics and macroeconomics, before moving to the next step.
@ Microeconomics | the study of choices made by single households, firms and markets
> Microeconomics is the working idea for this part of the chapter.

The term **Microeconomics** means the study of choices made by single households, firms and markets. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in microeconomics and macroeconomics, before moving to the next step.
@ Macroeconomics | the study of the economy as a whole, such as total output, jobs and the general price level
> Macroeconomics is the working idea for this part of the chapter.

The term **Macroeconomics** means the study of the economy as a whole, such as total output, jobs and the general price level. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in microeconomics and macroeconomics, before moving to the next step.
> Microeconomics and Macroeconomics is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Microeconomics and Macroeconomics is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Microeconomics and Macroeconomics is understood by separating the question into small steps.

The central question in microeconomics and macroeconomics is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in microeconomics and macroeconomics to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 2.4 | Scope, Importance and Objectives | framework | 450
> This section asks what scope, importance and objectives means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
> Scope, Importance and Objectives is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Scope, Importance and Objectives is understood by separating the question into small steps.

The central question in scope, importance and objectives is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> Scope, Importance and Objectives is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in scope, importance and objectives to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig a two-branch map of economics showing the questions that belong to microeconomics and to macroeconomics | ch02-fig01.svg

> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). Base facts carried: bookshop in Dhaka, run in 2026 by Shirin and Imran Meghna, restock decision of 12 January 2026 (Chapter 1 facts need not be repeated beyond this). Records of 5 February 2026: a 200-page exercise book sells at Tk 60 and 200 copies sell in a week. Ledger note A, in Shirin Meghna's hand: when the price was raised to Tk 66 on 2 March 2026, weekly sales fell to 188. Ledger note B, in Imran Meghna's hand: students should not have to pay more than Tk 60. Note A can be checked against sales records; note B cannot. Regular tendency recorded over three years: textbook sales rise in the two weeks before each term begins (this holds when the shop's prices stay unchanged). Micro and macro: the shop's price and stock are micro matters; the movement of the average price of all goods in Bangladesh is a macro matter. Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Teach the reader how economists argue, what an economic law is, and where microeconomics fits. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 2.t1 | sort five statements into positive and normative, state a law with its other-things-equal condition, place four decisions under micro or macro
:q 2.t2 | a minister says bread should be cheaper — separate the checkable part from the opinion

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to Great Debasement under Henry VIII, 1544 to 1551, and Thomas Gresham's observation about money; search: Great Debasement Gresham's law. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Review Questions
:q 2.3 | sort five statements into positive and normative, state a law with its other-things-equal condition, place four decisions under micro or macro
:q 2.4 | a minister says bread should be cheaper — separate the checkable part from the opinion
:q 2.5 | after the other-things-equal passage and after the micro-macro split
:pause 2.p6 | after the other-things-equal passage
:pause 2.p7 | the micro-macro split
