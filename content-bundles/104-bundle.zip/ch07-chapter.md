:chapter VII | Supply and Elasticity of Supply
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Build the supply idea from a price table to a curve and measure how strongly sellers respond to price. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch07-plate.svg | a harbour quay with sacks and crates being loaded onto a steamer, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Build the supply idea from a price table to a curve and measure how strongly sellers respond to price. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300; Tk 60, 350. Elasticity from Tk 50 to Tk 55: +10 per cent price, +20 per cent quantity, elasticity 2.0 (elastic). Shift: on 1 April 2026 the printer's paper cost rose and it offered 50 fewer books at every price: 100, 150, 200, 250, 300. Exceptional curve 1: a rare first edition, only one copy exists, supply unchanged at any price. Exceptional curve 2: a part-time binder offers 20 hours a week at Tk 150 an hour, 26 hours at Tk 200, 24 hours at Tk 260. The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 7.1 | The Law of Supply | defining theory | 550
> This section asks what the law of supply means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Supply | the quantity of a good sellers are willing and able to offer at each possible price, in a given period
> Supply is the working idea for this part of the chapter.

The term **Supply** means the quantity of a good sellers are willing and able to offer at each possible price, in a given period. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of supply, before moving to the next step.
@ Quantity supplied | the amount sellers plan to offer at one particular price
> Quantity supplied is the working idea for this part of the chapter.

The term **Quantity supplied** means the amount sellers plan to offer at one particular price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of supply, before moving to the next step.
@ Supply schedule | a table listing the quantity supplied at each of several prices
> Supply schedule is the working idea for this part of the chapter.

The term **Supply schedule** means a table listing the quantity supplied at each of several prices. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of supply, before moving to the next step.
> The Law of Supply is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> The Law of Supply is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in the law of supply to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 7.2 | What Moves the Supply Curve | new idea | 550
> This section asks what what moves the supply curve means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Supply curve | a line on a graph showing the quantity supplied at each price, other things equal
> Supply curve is the working idea for this part of the chapter.

The term **Supply curve** means a line on a graph showing the quantity supplied at each price, other things equal. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what moves the supply curve, before moving to the next step.
@ Law of supply | when the price of a good rises, quantity supplied rises, and when it falls, quantity supplied falls, other things equal
> Law of supply is the working idea for this part of the chapter.

The term **Law of supply** means when the price of a good rises, quantity supplied rises, and when it falls, quantity supplied falls, other things equal. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what moves the supply curve, before moving to the next step.
@ Determinants of supply | the things other than the good's own price that change how much sellers offer
> Determinants of supply is the working idea for this part of the chapter.

The term **Determinants of supply** means the things other than the good's own price that change how much sellers offer. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what moves the supply curve, before moving to the next step.
> What Moves the Supply Curve is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> What Moves the Supply Curve is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in what moves the supply curve to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 7.3 | Exceptions to the Law | framework | 225
> This section asks what exceptions to the law means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Backward-bending supply curve | a curve showing that beyond some pay level a worker offers fewer hours as pay rises further
> Backward-bending supply curve is the working idea for this part of the chapter.

The term **Backward-bending supply curve** means a curve showing that beyond some pay level a worker offers fewer hours as pay rises further. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in exceptions to the law, before moving to the next step.
@ Price elasticity of supply | the percentage change in quantity supplied divided by the percentage change in price
> Price elasticity of supply is the working idea for this part of the chapter.

The term **Price elasticity of supply** means the percentage change in quantity supplied divided by the percentage change in price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in exceptions to the law, before moving to the next step.
@ Elastic supply | supply for which quantity responds by a larger percentage than price
> Elastic supply is the working idea for this part of the chapter.

The term **Elastic supply** means supply for which quantity responds by a larger percentage than price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in exceptions to the law, before moving to the next step.
> Exceptions to the Law is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Exceptions to the Law is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in exceptions to the law to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 7.4 | Elasticity of Supply | technique | 775
> This section asks what elasticity of supply means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Inelastic supply | supply for which quantity responds by a smaller percentage than price
> Inelastic supply is the working idea for this part of the chapter.

The term **Inelastic supply** means supply for which quantity responds by a smaller percentage than price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in elasticity of supply, before moving to the next step.
> Elasticity of Supply is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Elasticity of Supply is understood by separating the question into small steps.

The central question in elasticity of supply is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> Elasticity of Supply is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in elasticity of supply to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig a supply curve drawn from the printer's schedule | ch07-fig01.svg
:fig a shift of the supply curve with its causes labelled | ch07-fig02.svg
:fig a supply curve of labour that bends backward at high pay | ch07-fig03.svg
:fig three supply curves of different elasticity through the same point | ch07-fig04.svg

> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). A local printer supplies 200-page exercise books to the shop at a wholesale price. Weekly quantity offered, 9 March 2026: Tk 40, 150 books; Tk 45, 200; Tk 50, 250; Tk 55, 300; Tk 60, 350. Elasticity from Tk 50 to Tk 55: +10 per cent price, +20 per cent quantity, elasticity 2.0 (elastic). Shift: on 1 April 2026 the printer's paper cost rose and it offered 50 fewer books at every price: 100, 150, 200, 250, 300. Exceptional curve 1: a rare first edition, only one copy exists, supply unchanged at any price. Exceptional curve 2: a part-time binder offers 20 hours a week at Tk 150 an hour, 26 hours at Tk 200, 24 hours at Tk 260. Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Build the supply idea from a price table to a curve and measure how strongly sellers respond to price. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 7.t1 | draw a supply curve from a new schedule, separate five events into movements and shifts, compute and name three elasticities of supply from new data
:q 7.t2 | explain why a farmer's supply of a perishable crop is inelastic in the short run

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to The Lancashire cotton famine of 1861 to 1865 and the rise of cotton exports from Egypt and India; search: Lancashire cotton famine 1861 Egypt India cotton exports. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Review Questions
:q 7.3 | draw a supply curve from a new schedule, separate five events into movements and shifts, compute and name three elasticities of supply from new data
:q 7.4 | explain why a farmer's supply of a perishable crop is inelastic in the short run
:q 7.5 | after the shift passage and after the elasticity-of-supply formula
:pause 7.p6 | after the shift passage
:pause 7.p7 | the elasticity-of-supply formula
