:chapter XII | Distribution: Rent, Wages, Interest and Profit
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Explain how the money earned from production is shared among land, labour, capital and enterprise. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch12-plate.svg | a rent-day gathering in a manor estate office with a steward and tenant farmers, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Explain how the money earned from production is shared among land, labour, capital and enterprise. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000; nil. The shop itself pays Tk 60,000 a month in rent (carried base fact). Wages: shop assistant's nominal wage Tk 18,000 a month; general prices rose 8 per cent in the year; real wage about Tk 16,667 in last year's prices. Interest: a loan of Tk 200,000 at 11 per cent a year costs Tk 22,000 a year. Profit: yearly sales Tk 6,000,000; explicit costs Tk 5,400,000; accounting profit Tk 600,000. Implicit costs: owners' unpaid time Tk 360,000 and return on their own capital Tk 90,000, total Tk 450,000. Economic profit Tk 150,000; normal profit Tk 450,000. The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 12.1 | Rent | defining theory | 225
> This section asks what rent means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Factor price | the payment a factor of production earns: rent for land, wages for labour, interest for capital, profit for enterprise
> Factor price is the working idea for this part of the chapter.

The term **Factor price** means the payment a factor of production earns: rent for land, wages for labour, interest for capital, profit for enterprise. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in rent, before moving to the next step.
@ Economic rent | the payment to a factor above the minimum needed to keep it in its present use
> Economic rent is the working idea for this part of the chapter.

The term **Economic rent** means the payment to a factor above the minimum needed to keep it in its present use. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in rent, before moving to the next step.
@ Differential rent | the extra return a better plot earns over the poorest plot in use
> Differential rent is the working idea for this part of the chapter.

The term **Differential rent** means the extra return a better plot earns over the poorest plot in use. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in rent, before moving to the next step.
@ Wage | the payment made to labour for its work
> Wage is the working idea for this part of the chapter.

The term **Wage** means the payment made to labour for its work. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in rent, before moving to the next step.
> Rent is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> Rent is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in rent to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 12.2 | Wages | framework | 775
> This section asks what wages means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Nominal wage | the wage counted in money
> Nominal wage is the working idea for this part of the chapter.

The term **Nominal wage** means the wage counted in money. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in wages, before moving to the next step.
@ Real wage | the amount of goods and services a nominal wage can buy
> Real wage is the working idea for this part of the chapter.

The term **Real wage** means the amount of goods and services a nominal wage can buy. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in wages, before moving to the next step.
@ Interest | the payment for the use of borrowed money or capital over time
> Interest is the working idea for this part of the chapter.

The term **Interest** means the payment for the use of borrowed money or capital over time. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in wages, before moving to the next step.
@ Rate of interest | the interest paid in a year as a percentage of the amount borrowed
> Rate of interest is the working idea for this part of the chapter.

The term **Rate of interest** means the interest paid in a year as a percentage of the amount borrowed. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in wages, before moving to the next step.
> Wages is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Wages is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Wages is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in wages to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 12.3 | Interest | framework | 225
> This section asks what interest means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Profit | the reward of enterprise: what remains of revenue after the other factors are paid
> Profit is the working idea for this part of the chapter.

The term **Profit** means the reward of enterprise: what remains of revenue after the other factors are paid. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in interest, before moving to the next step.
@ Economic profit | revenue less all costs, explicit and implicit
> Economic profit is the working idea for this part of the chapter.

The term **Economic profit** means revenue less all costs, explicit and implicit. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in interest, before moving to the next step.
@ Accounting profit | revenue less explicit costs only
> Accounting profit is the working idea for this part of the chapter.

The term **Accounting profit** means revenue less explicit costs only. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in interest, before moving to the next step.
@ Normal profit | the least profit that keeps a firm in business, equal to the implicit costs of the owner's own resources
> Normal profit is the working idea for this part of the chapter.

The term **Normal profit** means the least profit that keeps a firm in business, equal to the implicit costs of the owner's own resources. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in interest, before moving to the next step.
> Interest is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Interest is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in interest to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 12.4 | Profit | framework | 775
> This section asks what profit means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Risk bearing | taking on the chance of loss when production is uncertain
> Risk bearing is the working idea for this part of the chapter.

The term **Risk bearing** means taking on the chance of loss when production is uncertain. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in profit, before moving to the next step.
@ Marginal productivity theory | the view that each factor is paid in line with the extra output its last unit adds
> Marginal productivity theory is the working idea for this part of the chapter.

The term **Marginal productivity theory** means the view that each factor is paid in line with the extra output its last unit adds. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in profit, before moving to the next step.
> Profit is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Profit is understood by separating the question into small steps.

The central question in profit is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> Profit is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in profit to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig differential rent on three plots of different yield | ch12-fig01.svg
:fig a labour market with demand and supply setting the wage | ch12-fig02.svg
:fig a loanable-funds diagram setting the rate of interest | ch12-fig03.svg
:fig a stacked bar splitting the shop's yearly sales into costs, normal profit and economic profit | ch12-fig04.svg

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). Rent: three locations for a stall, yearly figures before rent: main road Tk 150,000; side lane Tk 90,000; marginal plot Tk 60,000 (pays no rent). Differential rent: Tk 90,000; Tk 30,000; nil. The shop itself pays Tk 60,000 a month in rent (carried base fact). Wages: shop assistant's nominal wage Tk 18,000 a month; general prices rose 8 per cent in the year; real wage about Tk 16,667 in last year's prices. Interest: a loan of Tk 200,000 at 11 per cent a year costs Tk 22,000 a year. Profit: yearly sales Tk 6,000,000; explicit costs Tk 5,400,000; accounting profit Tk 600,000. Implicit costs: owners' unpaid time Tk 360,000 and return on their own capital Tk 90,000, total Tk 450,000. Economic profit Tk 150,000; normal profit Tk 450,000. Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Explain how the money earned from production is shared among land, labour, capital and enterprise. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 12.t1 | compute differential rents for new plots, compute a real wage from new price data, separate economic profit from accounting profit in a new account
:q 12.t2 | explain why the poorest plot in use earns no rent

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to David Ricardo's rent theory in his 1815 essay and his 1817 Principles, and the Corn Laws repealed in 1846; search: Ricardo rent Corn Laws 1815 repeal 1846. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Sources
> The chapter uses a small number of historical references to anchor its defining ideas.

Further reading and historical attribution should be checked against the original works and reliable archival or institutional sources. The chapter does not require the reader to accept a historical interpretation merely because it appears in a secondary account.

## Review Questions
:q 12.3 | compute differential rents for new plots, compute a real wage from new price data, separate economic profit from accounting profit in a new account
:q 12.4 | explain why the poorest plot in use earns no rent
:q 12.5 | after the differential-rent passage and after the economic-versus-accounting profit passage
:pause 12.p6 | after the differential-rent passage
:pause 12.p7 | the economic-versus-accounting profit passage

:read David Ricardo's rent theory in his 1815 essay and his 1817 Principles, and the Corn Laws repealed in 1846, historical case reference
