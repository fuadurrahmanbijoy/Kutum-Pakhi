:chapter VI | Consumer Choice: Surplus and Indifference Curves
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Show what a buyer gains from a purchase and how a buyer with a fixed budget picks the best bundle. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch06-plate.svg | a draper's shop with a customer weighing two bolts of cloth against a window, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Show what a buyer gains from a purchase and how a buyer with a fixed budget picks the best bundle. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650; four buy and one does not. Surpluses: Tk 250, Tk 150, Tk 50, Tk 0, total Tk 450. Choice: a student's monthly spending plan is Tk 1,200 on prescribed books at Tk 150 each and stationery packs at Tk 100 each. Budget line bundles (books, packs): (0, 12), (2, 9), (4, 6), (6, 3), (8, 0). One indifference curve through (4, 6) also passes through (3, 8) and (6, 4); the slope between (3, 8) and (4, 6) is 2 packs per book, between (4, 6) and (6, 4) it is 1 pack per book. Best bundle: (4, 6), cost Tk 600 plus Tk 600 equals Tk 1,200; the price ratio 150 to 100 equals 1.5 packs per book. The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 6.1 | Consumption and Consumer Surplus | new idea | 550
> This section asks what consumption and consumer surplus means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Consumption | the using up of goods and services to meet wants
> Consumption is the working idea for this part of the chapter.

The term **Consumption** means the using up of goods and services to meet wants. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in consumption and consumer surplus, before moving to the next step.
@ Willingness to pay | the highest price a buyer would accept to get one unit of a good
> Willingness to pay is the working idea for this part of the chapter.

The term **Willingness to pay** means the highest price a buyer would accept to get one unit of a good. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in consumption and consumer surplus, before moving to the next step.
@ Consumer surplus | the gap between what a buyer would pay and what is actually paid
> Consumer surplus is the working idea for this part of the chapter.

The term **Consumer surplus** means the gap between what a buyer would pay and what is actually paid. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in consumption and consumer surplus, before moving to the next step.
> Consumption and Consumer Surplus is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> Consumption and Consumer Surplus is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in consumption and consumer surplus to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 6.2 | Indifference Curves and the Budget Line | framework | 775
> This section asks what indifference curves and the budget line means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Indifference curve | a line joining bundles of two goods that give a consumer the same satisfaction
> Indifference curve is the working idea for this part of the chapter.

The term **Indifference curve** means a line joining bundles of two goods that give a consumer the same satisfaction. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in indifference curves and the budget line, before moving to the next step.
@ Indifference map | a set of indifference curves, with curves farther from the origin showing more satisfaction
> Indifference map is the working idea for this part of the chapter.

The term **Indifference map** means a set of indifference curves, with curves farther from the origin showing more satisfaction. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in indifference curves and the budget line, before moving to the next step.
@ Marginal rate of substitution | the amount of one good a consumer will give up to gain one more unit of the other
> Marginal rate of substitution is the working idea for this part of the chapter.

The term **Marginal rate of substitution** means the amount of one good a consumer will give up to gain one more unit of the other. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in indifference curves and the budget line, before moving to the next step.
> Indifference Curves and the Budget Line is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Indifference Curves and the Budget Line is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Indifference Curves and the Budget Line is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in indifference curves and the budget line to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 6.3 | Consumer Equilibrium | technique | 650
> This section asks what consumer equilibrium means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Budget line | a line showing every bundle of two goods a consumer can exactly afford with a given income
> Budget line is the working idea for this part of the chapter.

The term **Budget line** means a line showing every bundle of two goods a consumer can exactly afford with a given income. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in consumer equilibrium, before moving to the next step.
@ Consumer equilibrium | the affordable bundle that gives a consumer the greatest satisfaction
> Consumer equilibrium is the working idea for this part of the chapter.

The term **Consumer equilibrium** means the affordable bundle that gives a consumer the greatest satisfaction. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in consumer equilibrium, before moving to the next step.
> Consumer Equilibrium is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Consumer Equilibrium is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Consumer Equilibrium is understood by separating the question into small steps.

The central question in consumer equilibrium is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in consumer equilibrium to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig a demand curve with the consumer-surplus triangle shaded | ch06-fig01.svg
:fig a family of indifference curves, convex to the origin | ch06-fig02.svg
:fig a budget line drawn from a spending plan of Tk 1,200 | ch06-fig03.svg
:fig the tangency point of curve and budget line marked as the best bundle | ch06-fig04.svg

> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). Consumer surplus: on 14 March 2026 five customers' highest prices for a dictionary were Tk 900, Tk 800, Tk 700, Tk 650 and Tk 600; shelf price Tk 650; four buy and one does not. Surpluses: Tk 250, Tk 150, Tk 50, Tk 0, total Tk 450. Choice: a student's monthly spending plan is Tk 1,200 on prescribed books at Tk 150 each and stationery packs at Tk 100 each. Budget line bundles (books, packs): (0, 12), (2, 9), (4, 6), (6, 3), (8, 0). One indifference curve through (4, 6) also passes through (3, 8) and (6, 4); the slope between (3, 8) and (4, 6) is 2 packs per book, between (4, 6) and (6, 4) it is 1 pack per book. Best bundle: (4, 6), cost Tk 600 plus Tk 600 equals Tk 1,200; the price ratio 150 to 100 equals 1.5 packs per book. Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Show what a buyer gains from a purchase and how a buyer with a fixed budget picks the best bundle. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 6.t1 | compute consumer surplus from a new price list, draw a budget line from new prices, say why indifference curves do not cross
:q 6.t2 | a student's income doubles with prices unchanged — describe the new budget line and the likely best bundle

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to Jules Dupuit, 1844, on measuring the usefulness of public works such as bridge tolls; search: Dupuit 1844 utility of public works bridge toll. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Sources
> The chapter uses a small number of historical references to anchor its defining ideas.

Further reading and historical attribution should be checked against the original works and reliable archival or institutional sources. The chapter does not require the reader to accept a historical interpretation merely because it appears in a secondary account.

## Review Questions
:q 6.3 | compute consumer surplus from a new price list, draw a budget line from new prices, say why indifference curves do not cross
:q 6.4 | a student's income doubles with prices unchanged — describe the new budget line and the likely best bundle
:q 6.5 | after the first indifference curve is drawn and after the tangency passage
:pause 6.p6 | after the first indifference curve is drawn
:pause 6.p7 | the tangency passage

:read Jules Dupuit, 1844, on measuring the usefulness of public works such as bridge tolls, historical case reference
