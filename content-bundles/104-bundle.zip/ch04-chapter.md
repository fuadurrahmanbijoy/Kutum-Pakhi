:chapter IV | Demand and the Demand Curve
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Build the demand idea from a price table to a curve, and show what moves along it and what shifts it. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch04-plate.svg | a market-day crowd under a covered market hall with a painted price board, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Build the demand idea from a price table to a curve, and show what moves along it and what shifts it. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188; Tk 70, 180. Shock to determinants: schools announced a drawing term on 10 March 2026, and weekly sales at Tk 60 rose from 200 to 230 (a shift of the curve). Complements: when pen-pack price was cut from Tk 100 to Tk 90 on 16 March 2026, notebook sales at Tk 60 rose from 200 to 210 a week. Substitutes: when the price of a second-hand prescribed textbook fell by 20 per cent, weekly sales of the new copy fell from 50 to 44 (new copy price Tk 700). Snob effect: a numbered edition at Tk 2,400 sold out in three days, while the unnumbered Tk 1,200 edition took three weeks. Bandwagon effect: a title at Tk 450 sold 20 copies a week until it topped a public bestseller list, then 85 a week. Giffen good: no case in the shop; explain only in general terms. The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 4.1 | What Demand Means | new idea | 450
> This section asks what what demand means means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Demand | the quantity of a good people are willing and able to buy at each possible price, in a given period
> Demand is the working idea for this part of the chapter.

The term **Demand** means the quantity of a good people are willing and able to buy at each possible price, in a given period. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what demand means, before moving to the next step.
@ Quantity demanded | the amount people plan to buy at one particular price
> Quantity demanded is the working idea for this part of the chapter.

The term **Quantity demanded** means the amount people plan to buy at one particular price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what demand means, before moving to the next step.
@ Demand schedule | a table listing the quantity demanded at each of several prices
> Demand schedule is the working idea for this part of the chapter.

The term **Demand schedule** means a table listing the quantity demanded at each of several prices. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what demand means, before moving to the next step.
@ Demand curve | a line on a graph showing the quantity demanded at each price, other things equal
> Demand curve is the working idea for this part of the chapter.

The term **Demand curve** means a line on a graph showing the quantity demanded at each price, other things equal. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what demand means, before moving to the next step.
> What Demand Means is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> What Demand Means is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> What Demand Means is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in what demand means to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 4.2 | The Law of Demand | defining theory | 550
> This section asks what the law of demand means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Market | any arrangement that brings buyers and sellers of a good together
> Market is the working idea for this part of the chapter.

The term **Market** means any arrangement that brings buyers and sellers of a good together. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of demand, before moving to the next step.
@ Market demand | the sum of all individual buyers' demands for a good at each price
> Market demand is the working idea for this part of the chapter.

The term **Market demand** means the sum of all individual buyers' demands for a good at each price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of demand, before moving to the next step.
@ Law of demand | when the price of a good rises, quantity demanded falls, and when it falls, quantity demanded rises, other things equal
> Law of demand is the working idea for this part of the chapter.

The term **Law of demand** means when the price of a good rises, quantity demanded falls, and when it falls, quantity demanded rises, other things equal. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of demand, before moving to the next step.
@ Determinants of demand | the things other than the good's own price that change how much people want to buy
> Determinants of demand is the working idea for this part of the chapter.

The term **Determinants of demand** means the things other than the good's own price that change how much people want to buy. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of demand, before moving to the next step.
> The Law of Demand is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> The Law of Demand is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in the law of demand to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 4.3 | What Moves the Demand Curve | new idea | 550
> This section asks what what moves the demand curve means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Normal good | a good for which demand rises when buyers' incomes rise
> Normal good is the working idea for this part of the chapter.

The term **Normal good** means a good for which demand rises when buyers' incomes rise. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what moves the demand curve, before moving to the next step.
@ Inferior good | a good for which demand falls when buyers' incomes rise
> Inferior good is the working idea for this part of the chapter.

The term **Inferior good** means a good for which demand falls when buyers' incomes rise. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what moves the demand curve, before moving to the next step.
@ Substitute goods | goods that can replace each other, so a rise in one's price raises demand for the other
> Substitute goods is the working idea for this part of the chapter.

The term **Substitute goods** means goods that can replace each other, so a rise in one's price raises demand for the other. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what moves the demand curve, before moving to the next step.
@ Complementary goods | goods used together, so a rise in one's price lowers demand for the other
> Complementary goods is the working idea for this part of the chapter.

The term **Complementary goods** means goods used together, so a rise in one's price lowers demand for the other. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in what moves the demand curve, before moving to the next step.
> What Moves the Demand Curve is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> What Moves the Demand Curve is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in what moves the demand curve to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 4.4 | Related Goods and Exceptions | new idea | 450
> This section asks what related goods and exceptions means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Giffen good | a rare inferior good for which a price rise leads buyers to buy more of it
> Giffen good is the working idea for this part of the chapter.

The term **Giffen good** means a rare inferior good for which a price rise leads buyers to buy more of it. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in related goods and exceptions, before moving to the next step.
@ Snob effect | a fall in demand for a good because more people begin to own it
> Snob effect is the working idea for this part of the chapter.

The term **Snob effect** means a fall in demand for a good because more people begin to own it. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in related goods and exceptions, before moving to the next step.
@ Bandwagon effect | a rise in demand for a good because more people are seen to buy it
> Bandwagon effect is the working idea for this part of the chapter.

The term **Bandwagon effect** means a rise in demand for a good because more people are seen to buy it. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in related goods and exceptions, before moving to the next step.
> Related Goods and Exceptions is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Related Goods and Exceptions is understood by separating the question into small steps.

The central question in related goods and exceptions is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> Related Goods and Exceptions is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in related goods and exceptions to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig a demand curve drawn from the exercise-book schedule | ch04-fig01.svg
:fig a movement along the curve set beside a shift of the whole curve | ch04-fig02.svg
:fig a rightward and a leftward shift with the causes labelled | ch04-fig03.svg
:fig the curve of an exceptional good that bends upward, with the snob and bandwagon cases beside it | ch04-fig04.svg

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). Five-week trial from 26 January to 27 February 2026, one price per week, 200-page exercise book. Weekly sales: Tk 50, 240 copies; Tk 55, 220; Tk 60, 200; Tk 66, 188; Tk 70, 180. Shock to determinants: schools announced a drawing term on 10 March 2026, and weekly sales at Tk 60 rose from 200 to 230 (a shift of the curve). Complements: when pen-pack price was cut from Tk 100 to Tk 90 on 16 March 2026, notebook sales at Tk 60 rose from 200 to 210 a week. Substitutes: when the price of a second-hand prescribed textbook fell by 20 per cent, weekly sales of the new copy fell from 50 to 44 (new copy price Tk 700). Snob effect: a numbered edition at Tk 2,400 sold out in three days, while the unnumbered Tk 1,200 edition took three weeks. Bandwagon effect: a title at Tk 450 sold 20 copies a week until it topped a public bestseller list, then 85 a week. Giffen good: no case in the shop; explain only in general terms. Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Build the demand idea from a price table to a curve, and show what moves along it and what shifts it. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 4.t1 | draw a curve from a new schedule, tell a movement from a shift in five events, say how a pen-pack price change affects notebook demand
:q 4.t2 | when the price of petrol rises, say what probably happens to demand for natural gas and why

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to Gregory King's table of harvest shortfalls and wheat prices, published by Charles Davenant in 1699; search: Gregory King Davenant 1699 harvest wheat price. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Review Questions
:q 4.3 | draw a curve from a new schedule, tell a movement from a shift in five events, say how a pen-pack price change affects notebook demand
:q 4.4 | when the price of petrol rises, say what probably happens to demand for natural gas and why
:q 4.5 | after the movement-versus-shift passage and after the exceptions passage
:pause 4.p6 | after the movement-versus-shift passage
:pause 4.p7 | the exceptions passage
