:chapter I | Scarcity, Choice and the Economic Problem
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Show why every society and every shop must choose, and give the reader the first working words of economics. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch01-plate.svg | a clerk at a high desk among ledgers, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Show why every society and every shop must choose, and give the reader the first working words of economics. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet; two paid assistants. Record of 12 January 2026: restock fund Tk 400,000 in cash from family savings; shelf space allows one large restock only. Option A, textbooks: purchase cost Tk 400,000; expected sales Tk 560,000; expected sales less purchase cost Tk 160,000. Option B, stationery: purchase cost Tk 400,000; expected sales Tk 540,000; expected sales less purchase cost Tk 140,000. Decision recorded: option A. Opportunity cost of that decision: Tk 140,000. The three problems in shop terms: what to stock (textbooks), how to run the shop (family at the counter plus two assistants), for whom (university students first, schools second). The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 1.1 | Wants, Resources and Scarcity | new idea | 775
> This section asks what wants, resources and scarcity means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Economics | the study of how people, firms and societies choose among uses of limited resources to meet wants
> Economics is the working idea for this part of the chapter.

The term **Economics** means the study of how people, firms and societies choose among uses of limited resources to meet wants. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in wants, resources and scarcity, before moving to the next step.
@ Want | something a person would like to have, whether or not they can pay for it
> Want is the working idea for this part of the chapter.

The term **Want** means something a person would like to have, whether or not they can pay for it. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in wants, resources and scarcity, before moving to the next step.
@ Resource | anything used to make goods and services: land, labour, capital and enterprise
> Resource is the working idea for this part of the chapter.

The term **Resource** means anything used to make goods and services: land, labour, capital and enterprise. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in wants, resources and scarcity, before moving to the next step.
@ Factor of production | one of the four kinds of resource used in making things: land, labour, capital, enterprise
> Factor of production is the working idea for this part of the chapter.

The term **Factor of production** means one of the four kinds of resource used in making things: land, labour, capital, enterprise. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in wants, resources and scarcity, before moving to the next step.
> Wants, Resources and Scarcity is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> Wants, Resources and Scarcity is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Wants, Resources and Scarcity is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in wants, resources and scarcity to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 1.2 | Choice and Opportunity Cost | new idea | 550
> This section asks what choice and opportunity cost means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Good | a physical thing people buy to satisfy a want, such as a book or a pen
> Good is the working idea for this part of the chapter.

The term **Good** means a physical thing people buy to satisfy a want, such as a book or a pen. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in choice and opportunity cost, before moving to the next step.
@ Service | an activity done for someone, such as binding a thesis or delivering parcels
> Service is the working idea for this part of the chapter.

The term **Service** means an activity done for someone, such as binding a thesis or delivering parcels. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in choice and opportunity cost, before moving to the next step.
@ Scarcity | the condition in which resources are too few to satisfy all the wants people have
> Scarcity is the working idea for this part of the chapter.

The term **Scarcity** means the condition in which resources are too few to satisfy all the wants people have. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in choice and opportunity cost, before moving to the next step.
@ Choice | picking one option and giving up the others because resources cannot cover every option
> Choice is the working idea for this part of the chapter.

The term **Choice** means picking one option and giving up the others because resources cannot cover every option. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in choice and opportunity cost, before moving to the next step.
> Choice and Opportunity Cost is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Choice and Opportunity Cost is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in choice and opportunity cost to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 1.3 | The Basic Problems of an Economic Organisation | framework | 550
> This section asks what the basic problems of an economic organisation means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Opportunity cost | the value of the best alternative given up when a choice is made
> Opportunity cost is the working idea for this part of the chapter.

The term **Opportunity cost** means the value of the best alternative given up when a choice is made. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the basic problems of an economic organisation, before moving to the next step.
@ Firm | an organisation that uses resources to make goods or services and sell them
> Firm is the working idea for this part of the chapter.

The term **Firm** means an organisation that uses resources to make goods or services and sell them. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the basic problems of an economic organisation, before moving to the next step.
@ Household | a person or group living together that buys goods and services and supplies resources
> Household is the working idea for this part of the chapter.

The term **Household** means a person or group living together that buys goods and services and supplies resources. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the basic problems of an economic organisation, before moving to the next step.
@ Economic organisation | the way a society or business arranges who decides what is made, how and for whom
> Economic organisation is the working idea for this part of the chapter.

The term **Economic organisation** means the way a society or business arranges who decides what is made, how and for whom. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the basic problems of an economic organisation, before moving to the next step.
> The Basic Problems of an Economic Organisation is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The Basic Problems of an Economic Organisation is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in the basic problems of an economic organisation to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 1.4 | Defining Economics | defining theory | 225
> This section asks what defining economics means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Economic system | the set of rules and institutions a country uses to answer its basic economic problems
> Economic system is the working idea for this part of the chapter.

The term **Economic system** means the set of rules and institutions a country uses to answer its basic economic problems. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in defining economics, before moving to the next step.
> Defining Economics is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Defining Economics is understood by separating the question into small steps.

The central question in defining economics is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in defining economics to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig a pair of bars comparing the forgone return of two stock choices, with the chosen option marked | ch01-fig01.svg

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons is an illustrative documented case file. Base facts (FIXED): a bookshop in Dhaka opened on 4 January 2004 by Abdul Meghna; in 2026 run by his daughter Shirin Meghna and his son Imran Meghna; one shop of 600 square feet; two paid assistants. Record of 12 January 2026: restock fund Tk 400,000 in cash from family savings; shelf space allows one large restock only. Option A, textbooks: purchase cost Tk 400,000; expected sales Tk 560,000; expected sales less purchase cost Tk 160,000. Option B, stationery: purchase cost Tk 400,000; expected sales Tk 540,000; expected sales less purchase cost Tk 140,000. Decision recorded: option A. Opportunity cost of that decision: Tk 140,000. The three problems in shop terms: what to stock (textbooks), how to run the shop (family at the counter plus two assistants), for whom (university students first, schools second). Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Show why every society and every shop must choose, and give the reader the first working words of economics. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 1.t1 | scarcity versus shortage, forgone value of a choice made from a new price list, which of the three problems a given decision belongs to
:q 1.t2 | a student has Tk 9,000 and one free Saturday and must pick between two paid tasks and a course fee — name the opportunity cost

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to US petrol shortage after the October 1973 oil embargo, with queues and the odd-even plate rationing of 1974; search: 1973 oil embargo gasoline lines odd-even rationing. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Sources
> The chapter uses a small number of historical references to anchor its defining ideas.

Further reading and historical attribution should be checked against the original works and reliable archival or institutional sources. The chapter does not require the reader to accept a historical interpretation merely because it appears in a secondary account.

## Review Questions
:q 1.3 | scarcity versus shortage, forgone value of a choice made from a new price list, which of the three problems a given decision belongs to
:q 1.4 | a student has Tk 9,000 and one free Saturday and must pick between two paid tasks and a course fee — name the opportunity cost
:q 1.5 | after the scarcity passage and after the opportunity-cost passage
:pause 1.p6 | after the scarcity passage
:pause 1.p7 | the opportunity-cost passage

:read US petrol shortage after the October 1973 oil embargo, with queues and the odd-even plate rationing of 1974, historical case reference
