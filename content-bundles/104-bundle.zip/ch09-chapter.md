:chapter IX | Production
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Explain how inputs become output, why adding one input yields less and less, and what changes when all inputs grow. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch09-plate.svg | a pin-making workshop with a row of workers at benches, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Explain how inputs become output, why adding one input yields less and less, and what changes when all inputs grow. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12, 12, 11, 9.6, 8. Long run, scale tables (binds a day): one machine and 2 workers, 40; two machines and 4 workers, 90; four machines and 8 workers, 180; eight machines and 16 workers, 300. Types: first doubling gives 2.25 times output (increasing), second doubling gives 2.0 times (constant), third gives about 1.67 times (decreasing). The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 9.1 | The Production Function | new idea | 650
> This section asks what the production function means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Production | the process of turning resources into goods and services
> Production is the working idea for this part of the chapter.

The term **Production** means the process of turning resources into goods and services. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the production function, before moving to the next step.
@ Input | a resource used in production
> Input is the working idea for this part of the chapter.

The term **Input** means a resource used in production. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the production function, before moving to the next step.
@ Output | the goods or services produced
> Output is the working idea for this part of the chapter.

The term **Output** means the goods or services produced. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the production function, before moving to the next step.
@ Production function | a rule or table linking the quantities of inputs used to the greatest output they can make
> Production function is the working idea for this part of the chapter.

The term **Production function** means a rule or table linking the quantities of inputs used to the greatest output they can make. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the production function, before moving to the next step.
> The Production Function is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> The Production Function is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> The Production Function is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in the production function to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 9.2 | Short Run and Long Run | framework | 225
> This section asks what short run and long run means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Short run | a period too short to change at least one input, such as machines or floor space
> Short run is the working idea for this part of the chapter.

The term **Short run** means a period too short to change at least one input, such as machines or floor space. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in short run and long run, before moving to the next step.
@ Long run | a period long enough to change every input
> Long run is the working idea for this part of the chapter.

The term **Long run** means a period long enough to change every input. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in short run and long run, before moving to the next step.
@ Fixed input | an input whose quantity cannot be changed in the short run
> Fixed input is the working idea for this part of the chapter.

The term **Fixed input** means an input whose quantity cannot be changed in the short run. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in short run and long run, before moving to the next step.
@ Variable input | an input whose quantity can be changed even in the short run
> Variable input is the working idea for this part of the chapter.

The term **Variable input** means an input whose quantity can be changed even in the short run. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in short run and long run, before moving to the next step.
> Short Run and Long Run is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Short Run and Long Run is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in short run and long run to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 9.3 | Diminishing Returns | defining theory | 775
> This section asks what diminishing returns means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Total product | the whole output from a given amount of inputs
> Total product is the working idea for this part of the chapter.

The term **Total product** means the whole output from a given amount of inputs. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in diminishing returns, before moving to the next step.
@ Average product | total product divided by the number of units of the variable input
> Average product is the working idea for this part of the chapter.

The term **Average product** means total product divided by the number of units of the variable input. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in diminishing returns, before moving to the next step.
@ Marginal product | the extra output from adding one more unit of the variable input
> Marginal product is the working idea for this part of the chapter.

The term **Marginal product** means the extra output from adding one more unit of the variable input. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in diminishing returns, before moving to the next step.
@ Law of diminishing returns | when more of one input is added to fixed inputs, the extra output eventually falls
> Law of diminishing returns is the working idea for this part of the chapter.

The term **Law of diminishing returns** means when more of one input is added to fixed inputs, the extra output eventually falls. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in diminishing returns, before moving to the next step.
> Diminishing Returns is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Diminishing Returns is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Diminishing Returns is understood by separating the question into small steps.

The central question in diminishing returns is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in diminishing returns to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 9.4 | Returns to Scale | technique | 450
> This section asks what returns to scale means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Returns to scale | the change in output when all inputs are changed by the same proportion
> Returns to scale is the working idea for this part of the chapter.

The term **Returns to scale** means the change in output when all inputs are changed by the same proportion. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in returns to scale, before moving to the next step.
@ Increasing returns to scale | output rises by a larger proportion than inputs
> Increasing returns to scale is the working idea for this part of the chapter.

The term **Increasing returns to scale** means output rises by a larger proportion than inputs. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in returns to scale, before moving to the next step.
@ Constant returns to scale | output rises by the same proportion as inputs
> Constant returns to scale is the working idea for this part of the chapter.

The term **Constant returns to scale** means output rises by the same proportion as inputs. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in returns to scale, before moving to the next step.
@ Decreasing returns to scale | output rises by a smaller proportion than inputs
> Decreasing returns to scale is the working idea for this part of the chapter.

The term **Decreasing returns to scale** means output rises by a smaller proportion than inputs. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in returns to scale, before moving to the next step.
> Returns to Scale is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Returns to Scale is understood by separating the question into small steps.

The central question in returns to scale is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> Returns to Scale is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in returns to scale to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig a total product curve rising then flattening and a marginal product curve peaking then falling | ch09-fig01.svg
:fig average and marginal product on one diagram showing where they meet | ch09-fig02.svg
:fig a time bar marking the short run and the long run | ch09-fig03.svg
:fig three paths of output as scale doubles: more than double, double, less than double | ch09-fig04.svg

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). On 3 March 2026 the shop opened a binding corner for theses with one binding machine. Short run, one machine and 1 to 6 workers, binds a day: 10, 24, 36, 44, 48, 48. Marginal product: 10, 14, 12, 8, 4, 0. Average product: 10, 12, 12, 11, 9.6, 8. Long run, scale tables (binds a day): one machine and 2 workers, 40; two machines and 4 workers, 90; four machines and 8 workers, 180; eight machines and 16 workers, 300. Types: first doubling gives 2.25 times output (increasing), second doubling gives 2.0 times (constant), third gives about 1.67 times (decreasing). Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Explain how inputs become output, why adding one input yields less and less, and what changes when all inputs grow. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 9.t1 | complete average and marginal columns from new data, say where diminishing returns start, classify the returns to scale in a new table
:q 9.t2 | explain why a factory cannot directly add workers forever to raise output

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to Henry Ford's moving assembly line at Highland Park, 1913, and the fall in chassis assembly time; search: Ford moving assembly line 1913 chassis assembly time hours. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Review Questions
:q 9.3 | complete average and marginal columns from new data, say where diminishing returns start, classify the returns to scale in a new table
:q 9.4 | explain why a factory cannot directly add workers forever to raise output
:q 9.5 | after the short-run versus long-run passage and after the marginal-product table
:pause 9.p6 | after the short-run versus long-run passage
:pause 9.p7 | the marginal-product table
