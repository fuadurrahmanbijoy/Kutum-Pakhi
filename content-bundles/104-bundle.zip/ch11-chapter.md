:chapter XI | Market Structures and the Firm
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Compare how firms behave when they face many rivals, one rival or none, and how each structure sets price and output. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch11-plate.svg | a market street with one grand emporium among small stalls, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Compare how firms behave when they face many rivals, one rival or none, and how each structure sets price and output. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70; 50, Tk 80. Profit-maximising output 30 (marginal cost equals Tk 60). Average cost at 30 books Tk 52; profit (60 - 52) x 30 = Tk 240 a day. Entry of new shops lowers price toward average cost in the long run. Monopoly: sole authorised seller of one foreign reference work. Price and weekly quantity: Tk 1,000, 10 copies; Tk 900, 20; Tk 800, 30; Tk 700, 40. Total revenue Tk 10,000; 18,000; 24,000; 28,000. Marginal revenue between steps Tk 800; 600; 400. Marginal cost constant Tk 500. Profit-maximising output 30 copies at Tk 800; profit (800 - 500) x 30 = Tk 9,000. Monopolistic competition: a mystery novel series differentiated by cover and author; price Tk 400; short run average cost Tk 340 at 50 copies a week; profit Tk 3,000. After two more shops enter, the shop sells 40 copies at Tk 380 with average cost Tk 380; profit nil. Pricing: price cut from Tk 60 to Tk 55 for the exercise book raised weekly sales from 200 to 210; revenue Tk 12,000 fell to Tk 11,550 (inelastic). Market structure ranking for the shop: exercise books near perfect competition; the sole-authorised reference work a monopoly; mystery novels monopolistic competition. The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 11.1 | Types of Market | framework | 225
> This section asks what types of market means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Market structure | the features of a market, such as number of sellers, type of product and ease of entry, that shape how firms behave
> Market structure is the working idea for this part of the chapter.

The term **Market structure** means the features of a market, such as number of sellers, type of product and ease of entry, that shape how firms behave. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in types of market, before moving to the next step.
@ Competitive market | a market with many buyers and sellers, so no single one can set the price
> Competitive market is the working idea for this part of the chapter.

The term **Competitive market** means a market with many buyers and sellers, so no single one can set the price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in types of market, before moving to the next step.
@ Industry | all the firms that make the same or very similar goods
> Industry is the working idea for this part of the chapter.

The term **Industry** means all the firms that make the same or very similar goods. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in types of market, before moving to the next step.
> Types of Market is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> Types of Market is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in types of market to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 11.2 | Perfect Competition | new idea | 775
> This section asks what perfect competition means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Price taker | a firm that must accept the market price because it is too small to change it
> Price taker is the working idea for this part of the chapter.

The term **Price taker** means a firm that must accept the market price because it is too small to change it. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in perfect competition, before moving to the next step.
@ Price maker | a firm large enough that its own output choices affect the price
> Price maker is the working idea for this part of the chapter.

The term **Price maker** means a firm large enough that its own output choices affect the price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in perfect competition, before moving to the next step.
@ Marginal revenue | the extra revenue gained by selling one more unit
> Marginal revenue is the working idea for this part of the chapter.

The term **Marginal revenue** means the extra revenue gained by selling one more unit. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in perfect competition, before moving to the next step.
> Perfect Competition is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Perfect Competition is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Perfect Competition is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in perfect competition to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 11.3 | Monopoly | new idea | 550
> This section asks what monopoly means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Perfect competition | a market with many sellers, an identical product, free entry and full information, so each firm takes the price
> Perfect competition is the working idea for this part of the chapter.

The term **Perfect competition** means a market with many sellers, an identical product, free entry and full information, so each firm takes the price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in monopoly, before moving to the next step.
@ Pure competition | a market with many sellers, an identical product and free entry, where buyers may lack full information or free movement
> Pure competition is the working idea for this part of the chapter.

The term **Pure competition** means a market with many sellers, an identical product and free entry, where buyers may lack full information or free movement. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in monopoly, before moving to the next step.
@ Monopoly | a market with one seller and no close substitute, so that seller sets the price
> Monopoly is the working idea for this part of the chapter.

The term **Monopoly** means a market with one seller and no close substitute, so that seller sets the price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in monopoly, before moving to the next step.
> Monopoly is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Monopoly is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in monopoly to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 11.4 | Monopolistic Competition | new idea | 550
> This section asks what monopolistic competition means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Pure monopoly | a monopoly in which one seller supplies the whole market with a product that has no close substitute
> Pure monopoly is the working idea for this part of the chapter.

The term **Pure monopoly** means a monopoly in which one seller supplies the whole market with a product that has no close substitute. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in monopolistic competition, before moving to the next step.
@ Bilateral monopoly | a market with a single seller facing a single buyer
> Bilateral monopoly is the working idea for this part of the chapter.

The term **Bilateral monopoly** means a market with a single seller facing a single buyer. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in monopolistic competition, before moving to the next step.
@ Monopolistic competition | a market with many sellers of similar but not identical goods and free entry
> Monopolistic competition is the working idea for this part of the chapter.

The term **Monopolistic competition** means a market with many sellers of similar but not identical goods and free entry. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in monopolistic competition, before moving to the next step.
> Monopolistic Competition is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Monopolistic Competition is understood by separating the question into small steps.

The central question in monopolistic competition is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in monopolistic competition to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 11.5 | Pricing and the Firm's Goal | framework | 225
> This section asks what pricing and the firm's goal means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Product differentiation | making a firm's good different from rivals' in quality, design, brand or service
> Product differentiation is the working idea for this part of the chapter.

The term **Product differentiation** means making a firm's good different from rivals' in quality, design, brand or service. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in pricing and the firm's goal, before moving to the next step.
@ Oligopoly | a market with a few large sellers, each aware of the others' actions
> Oligopoly is the working idea for this part of the chapter.

The term **Oligopoly** means a market with a few large sellers, each aware of the others' actions. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in pricing and the firm's goal, before moving to the next step.
@ Profit maximisation | choosing the output at which the gap between total revenue and total cost is greatest
> Profit maximisation is the working idea for this part of the chapter.

The term **Profit maximisation** means choosing the output at which the gap between total revenue and total cost is greatest. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in pricing and the firm's goal, before moving to the next step.
> Pricing and the Firm's Goal is understood by separating the question into small steps.

The central question in pricing and the firm's goal is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> Pricing and the Firm's Goal is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in pricing and the firm's goal to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig a table-diagram of the market structures by number of sellers, product type and entry | ch11-fig01.svg
:fig a perfectly competitive firm at the point where marginal cost equals price, with industry beside it | ch11-fig02.svg
:fig a monopolist's demand and marginal revenue curves with the profit rectangle | ch11-fig03.svg
:fig a monopolistic competitor's short-run profit and long-run zero profit side by side | ch11-fig04.svg
:fig a revenue comparison of a price cut for an elastic good and an inelastic good | ch11-fig05.svg

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). Perfect competition: exercise books, market price Tk 60. Firm marginal cost by daily output: 10 books, Tk 40; 20, Tk 50; 30, Tk 60; 40, Tk 70; 50, Tk 80. Profit-maximising output 30 (marginal cost equals Tk 60). Average cost at 30 books Tk 52; profit (60 - 52) x 30 = Tk 240 a day. Entry of new shops lowers price toward average cost in the long run. Monopoly: sole authorised seller of one foreign reference work. Price and weekly quantity: Tk 1,000, 10 copies; Tk 900, 20; Tk 800, 30; Tk 700, 40. Total revenue Tk 10,000; 18,000; 24,000; 28,000. Marginal revenue between steps Tk 800; 600; 400. Marginal cost constant Tk 500. Profit-maximising output 30 copies at Tk 800; profit (800 - 500) x 30 = Tk 9,000. Monopolistic competition: a mystery novel series differentiated by cover and author; price Tk 400; short run average cost Tk 340 at 50 copies a week; profit Tk 3,000. After two more shops enter, the shop sells 40 copies at Tk 380 with average cost Tk 380; profit nil. Pricing: price cut from Tk 60 to Tk 55 for the exercise book raised weekly sales from 200 to 210; revenue Tk 12,000 fell to Tk 11,550 (inelastic). Market structure ranking for the shop: exercise books near perfect competition; the sole-authorised reference work a monopoly; mystery novels monopolistic competition. Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Compare how firms behave when they face many rivals, one rival or none, and how each structure sets price and output. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 11.t1 | find the profit-maximising output from a new cost table in each of three structures, name the structure from a list of features, decide whether a price cut helps revenue
:q 11.t2 | assess the view that firms always aim to maximise profit

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to The 1911 US Supreme Court decision to break up Standard Oil; search: Standard Oil 1911 Supreme Court dissolution. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Review Questions
:q 11.3 | find the profit-maximising output from a new cost table in each of three structures, name the structure from a list of features, decide whether a price cut helps revenue
:q 11.4 | assess the view that firms always aim to maximise profit
:q 11.5 | after the price-taker passage and after the monopoly marginal-revenue table
:pause 11.p6 | after the price-taker passage
:pause 11.p7 | the monopoly marginal-revenue table
