:chapter X | Costs of Production
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Show what costs a firm counts, how they change with output, and how to reach a given output at the lowest cost. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch10-plate.svg | a foundry floor with a tilting converter and ladles of molten metal, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Show what costs a firm counts, how they change with output, and how to reach a given output at the lowest cost. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Output (binds a month) 100, 200, 300, 400, 500, 600, 700 with variable cost Tk 4,000; 7,000; 9,000; 12,000; 17,000; 24,000; 34,000. Total cost Tk 24,000; 27,000; 29,000; 32,000; 37,000; 44,000; 54,000. Average cost Tk 240; 135; 96.67; 80; 74; 73.33; 77.14. Marginal cost per bind between steps: Tk 40; 30; 20; 30; 50; 70; 100 (marginal cost crosses average cost near 600 binds, where average cost is lowest at Tk 73.33). Long run: with one machine lowest average cost Tk 73.33 at 600 binds; with two machines Tk 66 at 1,200; with three machines Tk 70 at 1,800. Least-cost combination for 400 binds a day, wage Tk 600 a day and machine rent Tk 1,200 a day: 10 workers and 5 machines cost Tk 12,000; 16 workers and 3 machines Tk 13,200; 8 workers and 8 machines Tk 14,400; 24 workers and 2 machines Tk 16,800; least cost Tk 12,000, where marginal product of labour is 30 and of a machine 60 (30 over 600 equals 60 over 1,200). The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 10.1 | Cost Concepts | framework | 450
> This section asks what cost concepts means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Cost | the value of the resources used up in making a good or service
> Cost is the working idea for this part of the chapter.

The term **Cost** means the value of the resources used up in making a good or service. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in cost concepts, before moving to the next step.
@ Explicit cost | a cost paid out in money to others, such as rent or wages
> Explicit cost is the working idea for this part of the chapter.

The term **Explicit cost** means a cost paid out in money to others, such as rent or wages. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in cost concepts, before moving to the next step.
@ Implicit cost | the value of resources the owner supplies, such as own time, for which no payment is made
> Implicit cost is the working idea for this part of the chapter.

The term **Implicit cost** means the value of resources the owner supplies, such as own time, for which no payment is made. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in cost concepts, before moving to the next step.
@ Fixed cost | a cost that stays the same however much is produced in the short run
> Fixed cost is the working idea for this part of the chapter.

The term **Fixed cost** means a cost that stays the same however much is produced in the short run. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in cost concepts, before moving to the next step.
> Cost Concepts is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> Cost Concepts is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Cost Concepts is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in cost concepts to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 10.2 | Short-Run Cost Curves | technique | 775
> This section asks what short-run cost curves means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Variable cost | a cost that rises and falls with the amount produced
> Variable cost is the working idea for this part of the chapter.

The term **Variable cost** means a cost that rises and falls with the amount produced. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in short-run cost curves, before moving to the next step.
@ Total cost | fixed cost plus variable cost at a given output
> Total cost is the working idea for this part of the chapter.

The term **Total cost** means fixed cost plus variable cost at a given output. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in short-run cost curves, before moving to the next step.
@ Average cost | total cost divided by the number of units produced
> Average cost is the working idea for this part of the chapter.

The term **Average cost** means total cost divided by the number of units produced. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in short-run cost curves, before moving to the next step.
@ Marginal cost | the extra cost of producing one more unit
> Marginal cost is the working idea for this part of the chapter.

The term **Marginal cost** means the extra cost of producing one more unit. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in short-run cost curves, before moving to the next step.
> Short-Run Cost Curves is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Short-Run Cost Curves is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Short-Run Cost Curves is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in short-run cost curves to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 10.3 | Long-Run Cost Curves | new idea | 225
> This section asks what long-run cost curves means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Prime cost | the direct cost of materials and labour that go into a unit of output
> Prime cost is the working idea for this part of the chapter.

The term **Prime cost** means the direct cost of materials and labour that go into a unit of output. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in long-run cost curves, before moving to the next step.
@ Supplementary cost | the cost of items apart from prime cost, such as rent and equipment, which remain even when output is nil
> Supplementary cost is the working idea for this part of the chapter.

The term **Supplementary cost** means the cost of items apart from prime cost, such as rent and equipment, which remain even when output is nil. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in long-run cost curves, before moving to the next step.
@ Long-run average cost curve | a curve showing the lowest average cost of each output when every input can be changed
> Long-run average cost curve is the working idea for this part of the chapter.

The term **Long-run average cost curve** means a curve showing the lowest average cost of each output when every input can be changed. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in long-run cost curves, before moving to the next step.
@ Isoquant | a curve joining the input combinations that all make the same output
> Isoquant is the working idea for this part of the chapter.

The term **Isoquant** means a curve joining the input combinations that all make the same output. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in long-run cost curves, before moving to the next step.
> Long-Run Cost Curves is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Long-Run Cost Curves is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in long-run cost curves to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 10.4 | Least-Cost Combination | technique | 550
> This section asks what least-cost combination means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Isocost line | a line joining the input combinations that all cost the same total
> Isocost line is the working idea for this part of the chapter.

The term **Isocost line** means a line joining the input combinations that all cost the same total. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in least-cost combination, before moving to the next step.
@ Least-cost combination | the mix of inputs that makes a given output for the lowest total cost
> Least-cost combination is the working idea for this part of the chapter.

The term **Least-cost combination** means the mix of inputs that makes a given output for the lowest total cost. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Outpu. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in least-cost combination, before moving to the next step.
> Least-Cost Combination is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Least-Cost Combination is understood by separating the question into small steps.

The central question in least-cost combination is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in least-cost combination to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig fixed, variable and total cost curves on one diagram | ch10-fig01.svg
:fig average cost and marginal cost curves, with marginal cost cutting average cost at its lowest point | ch10-fig02.svg
:fig three short-run average cost curves with the long-run curve enveloping them | ch10-fig03.svg
:fig an isocost line touching an isoquant at the least-cost point | ch10-fig04.svg

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). Binding corner monthly, 2026. Fixed cost Tk 20,000 (corner rent Tk 12,000 plus machine instalment Tk 8,000). Implicit cost: owners' unpaid time Tk 15,000 a month. Prime cost is materials and labour, equal to variable cost. Output (binds a month) 100, 200, 300, 400, 500, 600, 700 with variable cost Tk 4,000; 7,000; 9,000; 12,000; 17,000; 24,000; 34,000. Total cost Tk 24,000; 27,000; 29,000; 32,000; 37,000; 44,000; 54,000. Average cost Tk 240; 135; 96.67; 80; 74; 73.33; 77.14. Marginal cost per bind between steps: Tk 40; 30; 20; 30; 50; 70; 100 (marginal cost crosses average cost near 600 binds, where average cost is lowest at Tk 73.33). Long run: with one machine lowest average cost Tk 73.33 at 600 binds; with two machines Tk 66 at 1,200; with three machines Tk 70 at 1,800. Least-cost combination for 400 binds a day, wage Tk 600 a day and machine rent Tk 1,200 a day: 10 workers and 5 machines cost Tk 12,000; 16 workers and 3 machines Tk 13,200; 8 workers and 8 machines Tk 14,400; 24 workers and 2 machines Tk 16,800; least cost Tk 12,000, where marginal product of labour is 30 and of a machine 60 (30 over 600 equals 60 over 1,200). Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Show what costs a firm counts, how they change with output, and how to reach a given output at the lowest cost. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 10.t1 | complete the cost columns from new data, find where marginal cost crosses average cost, choose the cheapest input mix from three priced options
:q 10.t2 | explain why a family business should count its own unpaid time as a cost when judging success

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to Henry Bessemer's converter process, 1856, and the fall in the price of steel; search: Bessemer process 1856 steel price fall per ton. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Review Questions
:q 10.3 | complete the cost columns from new data, find where marginal cost crosses average cost, choose the cheapest input mix from three priced options
:q 10.4 | explain why a family business should count its own unpaid time as a cost when judging success
:q 10.5 | after the average-versus-marginal passage and after the least-cost rule
:pause 10.p6 | after the average-versus-marginal passage
:pause 10.p7 | the least-cost rule
