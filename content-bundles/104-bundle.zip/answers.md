:answers 01
:a 1.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 1.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 1.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 1.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 1.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 1.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 1.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 02
:a 2.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 2.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 2.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 2.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 2.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 2.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 2.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 03
:a 3.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 3.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 3.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 3.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 3.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 3.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 3.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 04
:a 4.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 4.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 4.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 4.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 4.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 4.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 4.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 05
:a 5.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 5.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 5.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 5.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 5.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 5.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 5.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 06
:a 6.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 6.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 6.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 6.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 6.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 6.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 6.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 07
:a 7.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 7.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 7.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 7.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 7.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 7.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 7.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 08
:a 8.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 8.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 8.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 8.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 8.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 8.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 8.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 09
:a 9.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 9.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 9.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 9.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 9.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 9.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 9.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 10
:a 10.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 10.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 10.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 10.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 10.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 10.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 10.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 11
:a 11.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 11.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 11.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 11.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 11.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 11.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 11.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers 12
:a 12.t1 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 12.t2 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 12.3 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 12.4 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 12.5 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 12.p6 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.
:a 12.p7 | Apply the definition and conditions stated in the chapter. For a calculation, show the relevant change and divide or multiply only after identifying the correct starting value and unit.

:answers A1
