:chapter III | Utility and Diminishing Marginal Utility
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Explain satisfaction as the root of demand and give the first law the reader can test. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch03-plate.svg | a still life of a loaf, a cup and a spoon on a worn kitchen table, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Explain satisfaction as the root of demand and give the first law the reader can test. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): total utility 20, 34, 43, 48, 50; marginal utility 20, 14, 9, 5, 2. A sixth notebook is rated 0 and a seventh would lower satisfaction by 3. Conditions noted on the card: all notebooks of the same kind, bought in a single visit, no change in taste. Notebook price Tk 60 (carried from the shop's price list). The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 3.1 | Utility and Satisfaction | new idea | 775
> This section asks what utility and satisfaction means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Utility | the satisfaction a person gets from using a good or service
> Utility is the working idea for this part of the chapter.

The term **Utility** means the satisfaction a person gets from using a good or service. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): t. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in utility and satisfaction, before moving to the next step.
@ Consumer | a person who buys or uses goods and services to meet wants
> Consumer is the working idea for this part of the chapter.

The term **Consumer** means a person who buys or uses goods and services to meet wants. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): t. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in utility and satisfaction, before moving to the next step.
@ Total utility | the whole satisfaction from all the units of a good consumed in a period
> Total utility is the working idea for this part of the chapter.

The term **Total utility** means the whole satisfaction from all the units of a good consumed in a period. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): t. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in utility and satisfaction, before moving to the next step.
> Utility and Satisfaction is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> Utility and Satisfaction is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Utility and Satisfaction is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in utility and satisfaction to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 3.2 | The Law of Diminishing Marginal Utility | defining theory | 775
> This section asks what the law of diminishing marginal utility means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Marginal utility | the extra satisfaction gained from consuming one more unit of a good
> Marginal utility is the working idea for this part of the chapter.

The term **Marginal utility** means the extra satisfaction gained from consuming one more unit of a good. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): t. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of diminishing marginal utility, before moving to the next step.
@ Util | an imaginary unit used to count satisfaction in examples
> Util is the working idea for this part of the chapter.

The term **Util** means an imaginary unit used to count satisfaction in examples. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): t. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of diminishing marginal utility, before moving to the next step.
@ Cardinal measurement | measuring satisfaction in numbers, such as 20 utils, so amounts can be added and compared
> Cardinal measurement is the working idea for this part of the chapter.

The term **Cardinal measurement** means measuring satisfaction in numbers, such as 20 utils, so amounts can be added and compared. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): t. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in the law of diminishing marginal utility, before moving to the next step.
> The Law of Diminishing Marginal Utility is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> The Law of Diminishing Marginal Utility is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The Law of Diminishing Marginal Utility is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in the law of diminishing marginal utility to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 3.3 | Limitations of the Law | framework | 450
> This section asks what limitations of the law means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Ordinal measurement | ranking satisfaction as first, second and third without giving it a number
> Ordinal measurement is the working idea for this part of the chapter.

The term **Ordinal measurement** means ranking satisfaction as first, second and third without giving it a number. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): t. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in limitations of the law, before moving to the next step.
@ Law of diminishing marginal utility | as a person consumes more units of a good, the extra satisfaction from each further unit falls
> Law of diminishing marginal utility is the working idea for this part of the chapter.

The term **Law of diminishing marginal utility** means as a person consumes more units of a good, the extra satisfaction from each further unit falls. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): t. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in limitations of the law, before moving to the next step.
@ Saturation point | the quantity at which marginal utility reaches zero and total utility stops rising
> Saturation point is the working idea for this part of the chapter.

The term **Saturation point** means the quantity at which marginal utility reaches zero and total utility stops rising. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): t. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in limitations of the law, before moving to the next step.
> Limitations of the Law is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Limitations of the Law is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Limitations of the Law is understood by separating the question into small steps.

The central question in limitations of the law is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in limitations of the law to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig the total utility curve rising and flattening against units consumed | ch03-fig01.svg
:fig the marginal utility curve falling to zero against the same units | ch03-fig02.svg
:fig one panel pairing total and marginal utility so the reader sees their link | ch03-fig03.svg

> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). Survey card of 10 February 2026 for one regular customer, satisfaction scored in utils for notebooks bought in one visit: first notebook 20 utils, second 14, third 9, fourth 5, fifth 2. Derived (by code in the writer's check): total utility 20, 34, 43, 48, 50; marginal utility 20, 14, 9, 5, 2. A sixth notebook is rated 0 and a seventh would lower satisfaction by 3. Conditions noted on the card: all notebooks of the same kind, bought in a single visit, no change in taste. Notebook price Tk 60 (carried from the shop's price list). Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Explain satisfaction as the root of demand and give the first law the reader can test. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 3.t1 | complete a total-and-marginal table from new scores, state the law with its conditions, give one apparent exception and say why it is not one
:q 3.t2 | a diner eats from a buffet — find where marginal utility reaches zero and say what a sensible diner does next

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to The marginal revolution of 1871 to 1874: Jevons, Menger and Walras explain the diamond-and-water puzzle; search: marginal revolution 1871 Jevons Menger diamond water paradox. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Sources
> The chapter uses a small number of historical references to anchor its defining ideas.

Further reading and historical attribution should be checked against the original works and reliable archival or institutional sources. The chapter does not require the reader to accept a historical interpretation merely because it appears in a secondary account.

## Review Questions
:q 3.3 | complete a total-and-marginal table from new scores, state the law with its conditions, give one apparent exception and say why it is not one
:q 3.4 | a diner eats from a buffet — find where marginal utility reaches zero and say what a sensible diner does next
:q 3.5 | after the total-versus-marginal passage and after the reasons-it-falls passage
:pause 3.p6 | after the total-versus-marginal passage
:pause 3.p7 | the reasons-it-falls passage

:read The marginal revolution of 1871 to 1874: Jevons, Menger and Walras explain the diamond-and-water puzzle, historical case reference
