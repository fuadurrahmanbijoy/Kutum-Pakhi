:chapter VIII | How Markets Find a Price
:mood What does this chapter let us explain that the earlier ideas could not explain alone?
:desc Bring demand and supply together to find a price, show why a market is pulled toward it, and measure who gains. The chapter builds the idea in small stages, then applies it to the running case. The examples keep the stated conditions visible so the reasoning can be checked.
:plate ch08-plate.svg | a corn exchange floor with traders around a chalk price board, 1880s

> The opening question sets up the problem before the rule is named.

Suppose you have to make a decision with a limited amount of money, time, space or equipment. Two choices may both be sensible, yet the same resources cannot serve both at once. The economic question is not whether one choice sounds attractive in isolation. It is what follows when the available resource is limited and a choice must be made. Bring demand and supply together to find a price, show why a market is pulled toward it, and measure who gains. This chapter develops that reasoning from a concrete setting to a general rule, then returns to the case so the rule can be checked.
> The reader first separates the objects of the analysis.

Ask what is being chosen, who is making the choice, which quantity is being measured, and which conditions are being held fixed. This order prevents a common mistake: answering a different question from the one the evidence can answer. A price, a quantity, a cost, an input or a payment may appear in the same record, but each has a distinct role. The chapter therefore introduces each working term at its first necessary point and keeps its meaning stable afterwards.
> The running case provides records rather than invented narrative.

Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70: Qd 750, Qs 1,150, excess supply 400. Supply shift: paper cost rises, supply becomes Qs = 25P - 760; new equilibrium P = Tk 64, Q = 840. Demand intercept price is Tk 120; supply intercept price is Tk 24 before the shift. Consumer surplus at equilibrium: 0.5 x (120 - 60) x 900 = Tk 27,000 a week; producer surplus: 0.5 x (60 - 24) x 900 = Tk 16,200 a week. After the shift: consumer surplus 0.5 x (120 - 64) x 840 = Tk 23,520; producer surplus 0.5 x (64 - 30.4) x 840 = Tk 14,112. Substitute-goods link: when the price of petrol rises, demand for natural gas shifts right (kept as a general example, not shop data). The case is illustrative, so it is used to show how the method works rather than to suggest facts beyond the record. Dates, amounts and decisions are treated as given data. When a conclusion depends on a condition, that condition is stated. When the case does not supply evidence for a claim, the discussion stays at the general level instead of creating a new fact.
* * *
## 8.1 | Markets and Market Equilibrium | framework | 550
> This section asks what markets and market equilibrium means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Equilibrium | a state in which nothing pushes the price or quantity to change
> Equilibrium is the working idea for this part of the chapter.

The term **Equilibrium** means a state in which nothing pushes the price or quantity to change. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70:. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in markets and market equilibrium, before moving to the next step.
@ Equilibrium price | the price at which quantity demanded equals quantity supplied
> Equilibrium price is the working idea for this part of the chapter.

The term **Equilibrium price** means the price at which quantity demanded equals quantity supplied. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70:. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in markets and market equilibrium, before moving to the next step.
@ Equilibrium quantity | the quantity bought and sold at the equilibrium price
> Equilibrium quantity is the working idea for this part of the chapter.

The term **Equilibrium quantity** means the quantity bought and sold at the equilibrium price. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70:. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in markets and market equilibrium, before moving to the next step.
> Markets and Market Equilibrium is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> Markets and Market Equilibrium is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in markets and market equilibrium to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 8.2 | Forces Toward Equilibrium | new idea | 550
> This section asks what forces toward equilibrium means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Excess demand | the amount by which quantity demanded exceeds quantity supplied at a price below equilibrium
> Excess demand is the working idea for this part of the chapter.

The term **Excess demand** means the amount by which quantity demanded exceeds quantity supplied at a price below equilibrium. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70:. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in forces toward equilibrium, before moving to the next step.
@ Excess supply | the amount by which quantity supplied exceeds quantity demanded at a price above equilibrium
> Excess supply is the working idea for this part of the chapter.

The term **Excess supply** means the amount by which quantity supplied exceeds quantity demanded at a price above equilibrium. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70:. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in forces toward equilibrium, before moving to the next step.
@ Price ceiling | a legal maximum price that may be charged for a good
> Price ceiling is the working idea for this part of the chapter.

The term **Price ceiling** means a legal maximum price that may be charged for a good. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70:. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in forces toward equilibrium, before moving to the next step.
> Forces Toward Equilibrium is understood by separating the question into small steps.

The running case gives the idea a concrete setting without requiring a story or invented motives. The records identify dates, quantities and prices, so the reader can reproduce the reasoning. Where the case gives a number, the number is retained; where it gives a general rule, the explanation remains general rather than creating an unsupported shop record.
> Forces Toward Equilibrium is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in forces toward equilibrium to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 8.3 | Shifts and New Equilibria | technique | 450
> This section asks what shifts and new equilibria means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
@ Price floor | a legal minimum price that may be charged for a good
> Price floor is the working idea for this part of the chapter.

The term **Price floor** means a legal minimum price that may be charged for a good. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70:. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in shifts and new equilibria, before moving to the next step.
@ Producer surplus | the gap between the price a seller receives and the lowest price the seller would accept
> Producer surplus is the working idea for this part of the chapter.

The term **Producer surplus** means the gap between the price a seller receives and the lowest price the seller would accept. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70:. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in shifts and new equilibria, before moving to the next step.
@ Total surplus | consumer surplus plus producer surplus, a measure of the gain from trade
> Total surplus is the working idea for this part of the chapter.

The term **Total surplus** means consumer surplus plus producer surplus, a measure of the gain from trade. For the running case, the record gives a concrete numerical or organisational setting in which this idea can be seen. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70:. In this chapter, the term matters because it lets the reader state precisely what is being measured or compared in shifts and new equilibria, before moving to the next step.
> Shifts and New Equilibria is understood by separating the question into small steps.

The same reasoning can be transferred to another setting. A household, market stall, workshop or larger firm may have different numbers, but the analytical sequence remains: identify the decision, state the relevant condition, apply the rule, and inspect the result. This transfer is important because an economic idea is useful only when it can be recognised outside its first example.
> Shifts and New Equilibria is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Shifts and New Equilibria is understood by separating the question into small steps.

The central question in shifts and new equilibria is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in shifts and new equilibria to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *
## 8.4 | Consumer and Producer Surplus in Practice | new idea | 450
> This section asks what consumer and producer surplus in practice means before applying it.

The section is organised around a question that can be answered from the definitions, the case record and the stated conditions. Start with the smallest version of the problem. Then add the detail that changes the result. This order makes the reasoning visible and reduces the temptation to memorise a formula without understanding what its parts represent.
> Consumer and Producer Surplus in Practice is understood by separating the question into small steps.

There is also a limit to the rule. Economic relationships describe tendencies under stated conditions, not mechanical laws that ignore every other fact. If a condition changes, the result may change as well. A careful reader therefore states the condition before applying the rule and checks whether the new situation still satisfies it.
> Consumer and Producer Surplus in Practice is understood by separating the question into small steps.

The central question in consumer and producer surplus in practice is how a decision follows from limited information and a stated rule. A useful first step is to name the objects being compared, then keep the conditions fixed while one relationship is examined. This prevents several different causes from being mixed together. The result is a description that can be checked against the figures or the stated situation.
> Consumer and Producer Surplus in Practice is understood by separating the question into small steps.

A beginner can read this idea in two stages. First, ask what changes and what stays unchanged. Next, ask what the change does to the quantity, cost, price, satisfaction or output under discussion. The distinction is small in wording but large in analysis, because the same numerical change can have different meanings when the underlying condition is different.
> The section closes by restating the condition that controls the result.

Before moving on, keep one question in view: what must remain true for the rule in consumer and producer surplus in practice to apply? The answer is contained in the definitions and examples above. If the condition changes, do not reuse the conclusion automatically. Re-state the problem, identify the new condition, and then apply the rule again.
* * *

:fig demand and supply curves crossing at the equilibrium point | ch08-fig01.svg
:fig a ceiling below and a floor above equilibrium with the shortage and surplus gaps marked | ch08-fig02.svg
:fig two panels: a supply shift left and a demand shift right with the new equilibria | ch08-fig03.svg
:fig consumer surplus and producer surplus shaded on one diagram | ch08-fig04.svg

> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.
> The same method remains useful when the surrounding details change.

The reader should separate the starting condition from the change being examined, then identify the quantity that responds. This prevents a movement from being confused with a shift, a total from being confused with a marginal amount, or a descriptive fact from being confused with a judgement. The running case provides fixed figures, but the reasoning is broader: identify the relevant definition, state the condition, apply the relationship, and check the result against the original data. If one condition changes, the analysis must be repeated rather than carried over unchanged. This disciplined sequence is the main practical skill developed by the chapter.

## Worked Case: The Running Record
> The worked case applies the chapter without adding facts to the record.

Situation. Meghna and Sons (illustrative). Neighbourhood market for 200-page exercise books, weekly: demand Qd = 1,800 - 15P and supply Qs = 25P - 600, with P in taka. Equilibrium: P = Tk 60, Q = 900. Ceiling at Tk 50: Qd 1,050, Qs 650, excess demand 400. Floor at Tk 70: Qd 750, Qs 1,150, excess supply 400. Supply shift: paper cost rises, supply becomes Qs = 25P - 760; new equilibrium P = Tk 64, Q = 840. Demand intercept price is Tk 120; supply intercept price is Tk 24 before the shift. Consumer surplus at equilibrium: 0.5 x (120 - 60) x 900 = Tk 27,000 a week; producer surplus: 0.5 x (60 - 24) x 900 = Tk 16,200 a week. After the shift: consumer surplus 0.5 x (120 - 64) x 840 = Tk 23,520; producer surplus 0.5 x (64 - 30.4) x 840 = Tk 14,112. Substitute-goods link: when the price of petrol rises, demand for natural gas shifts right (kept as a general example, not shop data). Question. What does the record show when the chapter's central rule is applied to these facts?
> The reasoning follows the data rather than an invented story.

Reasoning. Begin by listing the given figures and identifying the relationship that the chapter explains. Where arithmetic is needed, write the starting figures first, then the change, then the result. Where the issue is descriptive, name the category and give the condition that places the case in that category. This keeps the method reproducible: another reader should be able to follow the same sequence and reach the same conclusion from the stated record.
> The conclusion is limited to what the case supports.

Conclusion. The record illustrates the chapter's central relationship in a controlled setting. It does not prove that the same result must occur in every market, firm or household. The value of the worked case is that it shows how a general idea is applied while the assumptions remain visible.
> A final check asks whether the result fits the original data.

Check. Re-read the quantities, prices, costs or inputs used in the calculation. Confirm that units and periods match and that no figure has been silently changed. If the result contradicts a stated fact, return to the earlier step rather than adjusting the conclusion to fit the expected answer.
* * *
## Summary
> The chapter has built one connected chain of reasoning.

Bring demand and supply together to find a price, show why a market is pulled toward it, and measure who gains. The key terms now have fixed meanings, the running case has shown their use, and the limits of the rules have been kept visible. The next chapter can therefore treat these ideas as working tools rather than introduce them again from the beginning.

## Think It Through
:q 8.t1 | find equilibrium from new equations, describe the adjustment from a price above or below it, trace the effect of a shift
:q 8.t2 | a government sets a price ceiling below equilibrium for a staple — describe who gains and who loses

## Where People Go Wrong
> A common error is to apply a rule after its condition has changed.

Correction. State the condition first. Then decide whether the new situation still satisfies it. If it does, the rule can be applied again; if it does not, the analysis must be adjusted.
> Another error is to confuse a numerical result with the meaning of that result.

Correction. A number becomes useful only after its unit, period and economic meaning are identified. Always say what the result measures and which figures produced it.

## In History
> The historical case shows the chapter idea in a documented setting.

The entry directs attention to Diocletian's Edict on Maximum Prices, AD 301; search: Diocletian Edict on Maximum Prices 301 shortages. This account is used only for the historical connection specified by the chapter. It illustrates why the economic problem mattered in practice, while the chapter's analytical rules remain separate from the historical narrative.

## Review Questions
:q 8.3 | find equilibrium from new equations, describe the adjustment from a price above or below it, trace the effect of a shift
:q 8.4 | a government sets a price ceiling below equilibrium for a staple — describe who gains and who loses
:q 8.5 | after the equilibrium solution and after the shortage-and-surplus passage
:pause 8.p6 | after the equilibrium solution
:pause 8.p7 | the shortage-and-surplus passage
