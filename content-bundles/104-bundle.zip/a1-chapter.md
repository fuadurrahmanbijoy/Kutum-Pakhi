:chapter A1 | Maths You Will Use
> This reference keeps the arithmetic used later in one place.

The reader can return here whenever a calculation needs a percentage, ratio, average, rearranged equation or graph reading. Each method starts with the smallest useful example and then moves to a slightly less tidy one.
* * *
## A1.1 | Percentages and percentage change | technique | 250
> Percentages and percentage change is a tool for checking numerical relationships.

In percentages and percentage change, write the given numbers before choosing an operation. Keep the units visible, carry the arithmetic line by line, and round only at the point required by the question. For a percentage change, compare the change with the starting value. For an average, add the values and divide by their count. For an equation, perform the same operation on both sides. For a graph, read the axes before reading a point.
> A tiny worked example makes the procedure concrete.

Given a price of Tk 60 rising to Tk 66, the change is Tk 6. The percentage change is 6 ÷ 60 × 100 = 10 per cent. The important check is that the starting value is 60, not 66. The same discipline applies to ratios, equations and graphs: identify the reference quantity before calculating.
* * *
## A1.2 | Ratios, averages and rounding | technique | 250
> Ratios, averages and rounding is a tool for checking numerical relationships.

In ratios, averages and rounding, write the given numbers before choosing an operation. Keep the units visible, carry the arithmetic line by line, and round only at the point required by the question. For a percentage change, compare the change with the starting value. For an average, add the values and divide by their count. For an equation, perform the same operation on both sides. For a graph, read the axes before reading a point.
> A tiny worked example makes the procedure concrete.

Given a price of Tk 60 rising to Tk 66, the change is Tk 6. The percentage change is 6 ÷ 60 × 100 = 10 per cent. The important check is that the starting value is 60, not 66. The same discipline applies to ratios, equations and graphs: identify the reference quantity before calculating.
* * *
## A1.3 | Rearranging an equation | technique | 250
> Rearranging an equation is a tool for checking numerical relationships.

In rearranging an equation, write the given numbers before choosing an operation. Keep the units visible, carry the arithmetic line by line, and round only at the point required by the question. For a percentage change, compare the change with the starting value. For an average, add the values and divide by their count. For an equation, perform the same operation on both sides. For a graph, read the axes before reading a point.
> A tiny worked example makes the procedure concrete.

Given a price of Tk 60 rising to Tk 66, the change is Tk 6. The percentage change is 6 ÷ 60 × 100 = 10 per cent. The important check is that the starting value is 60, not 66. The same discipline applies to ratios, equations and graphs: identify the reference quantity before calculating.
* * *
## A1.4 | Reading a graph | technique | 250
> Reading a graph is a tool for checking numerical relationships.

In reading a graph, write the given numbers before choosing an operation. Keep the units visible, carry the arithmetic line by line, and round only at the point required by the question. For a percentage change, compare the change with the starting value. For an average, add the values and divide by their count. For an equation, perform the same operation on both sides. For a graph, read the axes before reading a point.
> A tiny worked example makes the procedure concrete.

Given a price of Tk 60 rising to Tk 66, the change is Tk 6. The percentage change is 6 ÷ 60 × 100 = 10 per cent. The important check is that the starting value is 60, not 66. The same discipline applies to ratios, equations and graphs: identify the reference quantity before calculating.
