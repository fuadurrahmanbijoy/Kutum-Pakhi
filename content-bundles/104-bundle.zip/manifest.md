:bundle
status: ok
failures: 0
chapters: 12
appendix: a1
changed-duplicates-resolved: 0
glossary-duplicates-removed: 0
chapter | ch01 | I | Scarcity, Choice and the Economic Problem | 3378 | 1 | 13 | 7
chapter | ch02 | II | Economic Reasoning, Laws and the Scope of Microeconomics | 3257 | 1 | 9 | 7
chapter | ch03 | III | Utility and Diminishing Marginal Utility | 3231 | 3 | 9 | 7
chapter | ch04 | IV | Demand and the Demand Curve | 3574 | 4 | 15 | 7
chapter | ch05 | V | Elasticity of Demand | 3259 | 4 | 11 | 7
chapter | ch06 | VI | Consumer Choice: Surplus and Indifference Curves | 3188 | 4 | 8 | 7
chapter | ch07 | VII | Supply and Elasticity of Supply | 3211 | 4 | 10 | 7
chapter | ch08 | VIII | How Markets Find a Price | 3259 | 4 | 9 | 7
chapter | ch09 | IX | Production | 3763 | 4 | 16 | 7
chapter | ch10 | X | Costs of Production | 3563 | 4 | 14 | 7
chapter | ch11 | XI | Market Structures and the Firm | 3760 | 5 | 15 | 7
chapter | ch12 | XII | Distribution: Rent, Wages, Interest and Profit | 3308 | 4 | 14 | 7
chapter | a1 | A1 | Maths You Will Use | 553 | 0 | 0 | 0
