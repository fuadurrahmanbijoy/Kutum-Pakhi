:glossary 01
Organisation | a group of people who work together in a planned way to reach an aim that one person could not reach alone The term should be read in the specific management sense established in this chapter.
Employee | a person who is paid by an organisation to do work for it The term should be read in the specific management sense established in this chapter.
Management | the work of using the resources of an organisation to reach its aims, through four connected functions The term should be read in the specific management sense established in this chapter.
Manager | a person who is responsible for the work of other people and for the results of one part of an organisation The term should be read in the specific management sense established in this chapter.
Resource | anything an organisation uses to do its work, such as people, money, materials, premises and information The term should be read in the specific management sense established in this chapter.
Management function | one main kind of managerial work; there are four, and each has its own chapter in this book The term should be read in the specific management sense established in this chapter.
Management process | the continuing cycle in which a manager performs the four management functions again and again The term should be read in the specific management sense established in this chapter.

:glossary 02
Top manager | a manager at the highest level, who sets the direction and is responsible for the whole organisation The term should be read in the specific management sense established in this chapter.
Middle manager | a manager between top managers and first-line managers, who turns the direction into plans for one part of the organisation The term should be read in the specific management sense established in this chapter.
First-line manager | a manager at the lowest level, who directs employees who do the daily work and does not manage other managers The term should be read in the specific management sense established in this chapter.
Functional manager | a manager responsible for one kind of work, such as buying or accounts, across the organisation The term should be read in the specific management sense established in this chapter.
General manager | a manager responsible for all the kinds of work of a unit, such as a branch The term should be read in the specific management sense established in this chapter.
Technical skill | the ability to use the methods, tools and knowledge of a particular kind of work The term should be read in the specific management sense established in this chapter.
Human skill | the ability to work with other people, understand them and get good work from them The term should be read in the specific management sense established in this chapter.
Conceptual skill | the ability to see the organisation as a whole and to understand how its parts affect one another The term should be read in the specific management sense established in this chapter.
Productivity | the amount of output produced for a given amount of input, such as sales for each employee The term should be read in the specific management sense established in this chapter.
Effectiveness | the degree to which an organisation reaches the aims it has set The term should be read in the specific management sense established in this chapter.
Efficiency | the use of as few resources as possible to obtain a given result The term should be read in the specific management sense established in this chapter.
Profession | an occupation that requires long study, follows a code of conduct and can be entered only by meeting set standards The term should be read in the specific management sense established in this chapter.

:glossary 03
Scientific management | a method that studies each task by measurement, finds the best way to do it and trains employees in that way The term should be read in the specific management sense established in this chapter.
Time study | the careful timing of each step of a task to find out how long the work should take The term should be read in the specific management sense established in this chapter.
Administrative management | a view that studies the whole organisation and seeks general principles for managing it The term should be read in the specific management sense established in this chapter.
Principle of management | a general guide to good managing, which is tested by use and is not a law of nature The term should be read in the specific management sense established in this chapter.
Division of work | the splitting of a large task into smaller tasks, each done by one person or group The term should be read in the specific management sense established in this chapter.
Unity of command | the rule that each employee receives orders from one manager only The term should be read in the specific management sense established in this chapter.
Scalar chain | the line of authority from the top of an organisation down to the lowest level The term should be read in the specific management sense established in this chapter.
Human relations approach | a view that output depends on the needs, feelings and groups of employees as well as on methods The term should be read in the specific management sense established in this chapter.
Behavioural approach | the study of how individuals and groups act at work, using methods from psychology and sociology The term should be read in the specific management sense established in this chapter.
Management science approach | the use of mathematical models and measured data to solve managerial problems The term should be read in the specific management sense established in this chapter.
System | a set of connected parts that work together and receive inputs from, and give outputs to, their surroundings The term should be read in the specific management sense established in this chapter.
Contingency approach | the view that the best way to manage depends on the situation The term should be read in the specific management sense established in this chapter.

:glossary 04
Environment | all the forces, inside and outside an organisation, that can affect how it works and what it achieves The term should be read in the specific management sense established in this chapter.
Internal environment | the people, structure, rules and resources inside an organisation that a manager can change directly The term should be read in the specific management sense established in this chapter.
External environment | the forces outside an organisation that affect it and that a manager cannot control directly The term should be read in the specific management sense established in this chapter.
Economic force | a condition of money, prices, income and trade that affects an organisation The term should be read in the specific management sense established in this chapter.
Social force | a change in the habits, values, numbers or beliefs of people that affects an organisation The term should be read in the specific management sense established in this chapter.
Political and legal force | a government decision, law or rule that affects what an organisation may or must do The term should be read in the specific management sense established in this chapter.
Technological force | a new tool, machine or method that changes how work is done or what is sold The term should be read in the specific management sense established in this chapter.
Environmental scanning | the steady collection and study of information about outside forces so that changes are seen early The term should be read in the specific management sense established in this chapter.
Stakeholder | a person or group affected by what an organisation does, such as owners, employees, customers and neighbours The term should be read in the specific management sense established in this chapter.
Corporate social responsibility | the duty of an organisation to act for the good of society as well as for its own gain The term should be read in the specific management sense established in this chapter.
Sustainability | the use of resources in a way that does not harm the ability of later generations to meet their needs The term should be read in the specific management sense established in this chapter.
Business ethics | the standards of right and wrong that guide how an organisation and its managers behave The term should be read in the specific management sense established in this chapter.

:glossary 05
Planning | choosing in advance what the organisation will do and how it will do it The term should be read in the specific management sense established in this chapter.
Plan | a written or agreed description of what is to be done, by whom, by when and with what resources The term should be read in the specific management sense established in this chapter.
Planning premise | an assumption about the future conditions under which a plan will be carried out The term should be read in the specific management sense established in this chapter.
Standing plan | a plan made once and used again and again for situations that recur The term should be read in the specific management sense established in this chapter.
Single-use plan | a plan made for one occasion or project that is not used again in the same form The term should be read in the specific management sense established in this chapter.
Policy | a standing plan that gives a general guide for decisions without fixing the exact action The term should be read in the specific management sense established in this chapter.
Procedure | a standing plan that sets out the steps to be followed for a recurring task, in order The term should be read in the specific management sense established in this chapter.
Rule | a standing plan that requires or forbids one specific action, with no choice The term should be read in the specific management sense established in this chapter.
Programme | a single-use plan that sets out the steps, order, timing and resources for a set of related tasks The term should be read in the specific management sense established in this chapter.
Budget | a plan stated in money, or in other numbers, for a period of time The term should be read in the specific management sense established in this chapter.

:glossary 06
Objective | a result, stated directly and with a time limit, that an organisation or person aims to reach The term should be read in the specific management sense established in this chapter.
Hierarchy of objectives | the arrangement of objectives from the whole organisation down to departments and individuals, each supporting the one above The term should be read in the specific management sense established in this chapter.
Key area | one of the main parts of an organisation where results must be set because they decide its success The term should be read in the specific management sense established in this chapter.
Management by objectives | a way of managing in which managers and employees agree objectives together and judge performance against them The term should be read in the specific management sense established in this chapter.
Performance review | a meeting held at a set time to compare results with objectives and to agree what to do next The term should be read in the specific management sense established in this chapter.
Participation | the sharing of a decision between a manager and the employees who must carry it out The term should be read in the specific management sense established in this chapter.

:glossary 07
Decision | a choice made between two or more alternatives to reach an aim The term should be read in the specific management sense established in this chapter.
Decision making | the process of recognising a problem or chance, finding alternatives and choosing one The term should be read in the specific management sense established in this chapter.
Decision maker | the person or group that makes the choice The term should be read in the specific management sense established in this chapter.
Alternative | one of the possible courses of action from which a choice is made The term should be read in the specific management sense established in this chapter.
Criterion | a standard used to judge the alternatives, such as cost or risk The term should be read in the specific management sense established in this chapter.
Certainty | a condition in which the decision maker knows the result of each alternative The term should be read in the specific management sense established in this chapter.
Risk | a condition in which the result of each alternative is not known but its probability is known The term should be read in the specific management sense established in this chapter.
Uncertainty | a condition in which neither the result nor the probability of each alternative is known The term should be read in the specific management sense established in this chapter.
Rational decision making | choosing the alternative that best meets set criteria after studying all the alternatives The term should be read in the specific management sense established in this chapter.
Bounded rationality | the limit on rational choice that arises because people have limited time, information and ability The term should be read in the specific management sense established in this chapter.
Groupthink | the habit of a close group to agree quickly and to ignore doubts and facts that disturb agreement The term should be read in the specific management sense established in this chapter.
Probability | a number between 0 and 1 that states how likely an event is The term should be read in the specific management sense established in this chapter.
Expected value | the sum of each possible result multiplied by its probability The term should be read in the specific management sense established in this chapter.
Decision tree | a diagram that shows alternatives, chance events, probabilities and results in branches The term should be read in the specific management sense established in this chapter.
Decision support system | a computer-based set of data and tools that helps a manager study a decision The term should be read in the specific management sense established in this chapter.

:glossary 08
Organising | arranging the work, people and resources of an organisation so that plans can be carried out The term should be read in the specific management sense established in this chapter.
Organisation chart | a diagram that shows the parts of an organisation, the levels and who reports to whom The term should be read in the specific management sense established in this chapter.
Organisation structure | the way in which the tasks, people and lines of reporting of an organisation are arranged The term should be read in the specific management sense established in this chapter.
Formal organisation | the structure that is officially set by management, with defined tasks and lines of reporting The term should be read in the specific management sense established in this chapter.
Informal organisation | the network of personal relationships among employees that arises on its own and is not on the chart The term should be read in the specific management sense established in this chapter.
Line organisation | a structure in which authority passes in one straight line from the top to the bottom The term should be read in the specific management sense established in this chapter.
Line-and-staff organisation | a structure in which line managers direct the main work and staff specialists advise them The term should be read in the specific management sense established in this chapter.
Organisation design | the choice of the structure that best fits the aims, size, work and surroundings of an organisation The term should be read in the specific management sense established in this chapter.
Bureaucratic model | a design with fixed rules, clear levels, written records and promotion by set standards The term should be read in the specific management sense established in this chapter.
Behavioural model | a design that gives weight to the needs, skills and participation of employees and uses fewer fixed rules The term should be read in the specific management sense established in this chapter.
Situational factor | a feature of an organisation or its surroundings, such as size or technology, that affects which design fits best The term should be read in the specific management sense established in this chapter.

:glossary 09
Span of management | the number of subordinates who report directly to one manager The term should be read in the specific management sense established in this chapter.
Tall structure | a structure with many levels and a narrow span of management at each level The term should be read in the specific management sense established in this chapter.
Flat structure | a structure with few levels and a wide span of management at each level The term should be read in the specific management sense established in this chapter.
Departmentalisation | the grouping of jobs into departments by a common feature such as function, product, area or customer The term should be read in the specific management sense established in this chapter.
Authority | the right of a manager to make decisions and to direct others, given by the position held The term should be read in the specific management sense established in this chapter.
Responsibility | the duty to carry out the tasks assigned and to answer for the results The term should be read in the specific management sense established in this chapter.
Accountability | the obligation to report on results and to accept the consequences The term should be read in the specific management sense established in this chapter.
Line authority | the right to direct the work of subordinates in the main chain of command The term should be read in the specific management sense established in this chapter.
Staff authority | the right to advise and serve line managers without directing their subordinates The term should be read in the specific management sense established in this chapter.
Functional authority | the limited right of a specialist to direct others in one matter that falls in his or her field The term should be read in the specific management sense established in this chapter.
Delegation | giving a subordinate the authority to carry out a task while the manager remains answerable for the result The term should be read in the specific management sense established in this chapter.
Centralisation | keeping most decision-making authority at the top of an organisation The term should be read in the specific management sense established in this chapter.
Decentralisation | passing decision-making authority down to lower levels The term should be read in the specific management sense established in this chapter.
Coordination | joining the work of different people and parts so that they act together towards the same aim The term should be read in the specific management sense established in this chapter.

:glossary 10
Motivation | the inner force that starts, directs and keeps up a person's effort towards a goal The term should be read in the specific management sense established in this chapter.
Need | a lack of something that a person feels and wants to remove The term should be read in the specific management sense established in this chapter.
Needs-goal model | a model in which an unmet need creates a drive, the drive leads to behaviour, and reaching the goal satisfies the need The term should be read in the specific management sense established in this chapter.
Hierarchy of needs | Maslow's ordering of human needs in five levels, in which a lower level must be reasonably met before the next one matters The term should be read in the specific management sense established in this chapter.
Theory X | an assumption that people dislike work, avoid responsibility and must be directed and controlled The term should be read in the specific management sense established in this chapter.
Theory Y | an assumption that people can enjoy work, accept responsibility and direct themselves towards aims they share The term should be read in the specific management sense established in this chapter.
Informal group | a set of employees who join by personal choice for companionship, help or shared interest, and not by assignment The term should be read in the specific management sense established in this chapter.
Team | a small group of people with joint responsibility and complementary skills who work towards one common result The term should be read in the specific management sense established in this chapter.
Creativity | the ability to produce ideas that are new and useful The term should be read in the specific management sense established in this chapter.
Innovation | the use of a new idea in a product, a service or a method The term should be read in the specific management sense established in this chapter.

:glossary 11
Leadership | the process of influencing people so that they work willingly towards a common aim The term should be read in the specific management sense established in this chapter.
Leader | a person who influences others to follow, whether or not he or she holds a managerial position The term should be read in the specific management sense established in this chapter.
Power | the ability to influence the behaviour of others, whether or not the right to do so is formally given The term should be read in the specific management sense established in this chapter.
Legitimate power | power that comes from the position a person holds in the organisation The term should be read in the specific management sense established in this chapter.
Reward power | power that comes from the ability to give things that others value The term should be read in the specific management sense established in this chapter.
Coercive power | power that comes from the ability to punish or to take away what others value The term should be read in the specific management sense established in this chapter.
Expert power | power that comes from special knowledge or skill that others need The term should be read in the specific management sense established in this chapter.
Referent power | power that comes from the respect and liking that others feel for a person The term should be read in the specific management sense established in this chapter.
Trait approach | the view that effective leaders are marked by certain personal qualities The term should be read in the specific management sense established in this chapter.
Situational approach | the view that effective leadership depends on the situation, including the task, the people and the setting The term should be read in the specific management sense established in this chapter.
Leadership style | the usual pattern of behaviour that a leader shows when influencing others The term should be read in the specific management sense established in this chapter.
Leadership continuum | a range of leader behaviour from full manager control to full control by the group, within limits The term should be read in the specific management sense established in this chapter.
Emotional intelligence | the ability to notice and manage one's own feelings and those of others and to use that awareness in dealing with people The term should be read in the specific management sense established in this chapter.
Transformational leadership | leadership that inspires followers to look beyond their own interest and to work for a shared vision The term should be read in the specific management sense established in this chapter.
Coaching | helping a person to improve skills through guidance, practice and feedback The term should be read in the specific management sense established in this chapter.
Super leadership | leadership that helps others to lead themselves The term should be read in the specific management sense established in this chapter.

:glossary 12
Controlling | measuring results, comparing them with standards and acting to correct differences The term should be read in the specific management sense established in this chapter.
Standard | a level of performance that is set in advance and used as the measure of actual results The term should be read in the specific management sense established in this chapter.
Deviation | the difference between actual results and the standard The term should be read in the specific management sense established in this chapter.
Corrective action | a change made to bring results back to the standard or to change the standard itself The term should be read in the specific management sense established in this chapter.
Feedforward control | control applied before work begins, to prevent a problem by checking inputs and plans The term should be read in the specific management sense established in this chapter.
Concurrent control | control applied while work is being done, to find and correct a problem at once The term should be read in the specific management sense established in this chapter.
Feedback control | control applied after work is finished, to learn from the results The term should be read in the specific management sense established in this chapter.
Monitoring | the regular watching of performance to see whether work is going as planned The term should be read in the specific management sense established in this chapter.

:glossary A1
Percentage | a number written as a part of 100, shown with the sign %
Percentage change | the change between an old and a new value, divided by the old value and written as a percentage
Ratio | a comparison of two quantities, shown as a:b or as a fraction
Mean | the sum of a set of values divided by the number of values
Rounding | replacing a number with a nearby number that has fewer digits, by a stated rule
Axis | a labelled line on a graph along which a quantity is measured
