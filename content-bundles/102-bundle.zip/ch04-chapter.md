:chapter IV | Environment, Ethics and Social Responsibility
:mood What becomes easier when the manager names the problem precisely?
:desc A first-year reader meets the chapter through a concrete management question. The ideas move from plain language to precise terms. The running case supplies recorded facts for application. The historical case provides a dated context.
:plate ch04-plate.svg | a harbour quay with ships, warehouses and a weather vane, 1870s

* * *
## Internal and External Environment

> The section begins with the practical question behind internal and external environment.
Suppose a manager must deal with internal and external environment. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers environment of an organisation internal and external environment compared as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Environment  gives this paragraph its precise focus.
@ Environment  |  all the forces, inside and outside an organisation, that can affect how it works and what it achieves
At the centre of the discussion is **Environment **.  all the forces, inside and outside an organisation, that can affect how it works and what it achieves. Environment of an organisation The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Internal environment  gives this paragraph its precise focus.
@ Internal environment  |  the people, structure, rules and resources inside an organisation that a manager can change directly
At the centre of the discussion is **Internal environment **.  the people, structure, rules and resources inside an organisation that a manager can change directly. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> External environment  gives this paragraph its precise focus.
@ External environment  |  the forces outside an organisation that affect it and that a manager cannot control directly
At the centre of the discussion is **External environment **.  the forces outside an organisation that affect it and that a manager cannot control directly. Internal and external environment compared The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Internal and External Environment is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of internal and external environment in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Forces in the External Environment

> The section begins with the practical question behind forces in the external environment.
Suppose a manager must deal with forces in the external environment. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers economic, social, political, legal and technological forces as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Economic force  gives this paragraph its precise focus.
@ Economic force  |  a condition of money, prices, income and trade that affects an organisation
At the centre of the discussion is **Economic force **.  a condition of money, prices, income and trade that affects an organisation. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Social force  gives this paragraph its precise focus.
@ Social force  |  a change in the habits, values, numbers or beliefs of people that affects an organisation
At the centre of the discussion is **Social force **.  a change in the habits, values, numbers or beliefs of people that affects an organisation. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Political and legal force  gives this paragraph its precise focus.
@ Political and legal force  |  a government decision, law or rule that affects what an organisation may or must do
At the centre of the discussion is **Political and legal force **.  a government decision, law or rule that affects what an organisation may or must do. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Forces in the External Environment is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of forces in the external environment in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Managing and Adapting to the Environment

> The section begins with the practical question behind managing and adapting to the environment.
Suppose a manager must deal with managing and adapting to the environment. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers scanning the environment responding and adapting as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Technological force  gives this paragraph its precise focus.
@ Technological force  |  a new tool, machine or method that changes how work is done or what is sold
At the centre of the discussion is **Technological force **.  a new tool, machine or method that changes how work is done or what is sold. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Environmental scanning  gives this paragraph its precise focus.
@ Environmental scanning  |  the steady collection and study of information about outside forces so that changes are seen early
At the centre of the discussion is **Environmental scanning **.  the steady collection and study of information about outside forces so that changes are seen early. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Stakeholder  gives this paragraph its precise focus.
@ Stakeholder  |  a person or group affected by what an organisation does, such as owners, employees, customers and neighbours
At the centre of the discussion is **Stakeholder **.  a person or group affected by what an organisation does, such as owners, employees, customers and neighbours. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Managing and Adapting to the Environment is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of managing and adapting to the environment in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Social Responsibility and Sustainability

> The section begins with the practical question behind social responsibility and sustainability.
Suppose a manager must deal with social responsibility and sustainability. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers social responsibility and stakeholders davis's view of responsibility and power sustainability as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Corporate social responsibility  gives this paragraph its precise focus.
@ Corporate social responsibility  |  the duty of an organisation to act for the good of society as well as for its own gain
At the centre of the discussion is **Corporate social responsibility **.  the duty of an organisation to act for the good of society as well as for its own gain. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Sustainability  gives this paragraph its precise focus.
@ Sustainability  |  the use of resources in a way that does not harm the ability of later generations to meet their needs
At the centre of the discussion is **Sustainability **.  the use of resources in a way that does not harm the ability of later generations to meet their needs. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Business ethics  gives this paragraph its precise focus.
@ Business ethics  |  the standards of right and wrong that guide how an organisation and its managers behave
At the centre of the discussion is **Business ethics **.  the standards of right and wrong that guide how an organisation and its managers behave. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Social Responsibility and Sustainability is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of social responsibility and sustainability in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Business Ethics

> The section begins with the practical question behind business ethics.
Suppose a manager must deal with business ethics. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers ethics in business ethical conduct and ethical codes as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Business Ethics is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of business ethics in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *


:fig an organisation drawn inside two rings: the internal environment and the external forces around it | ch04-fig01.svg
:fig the groups of stakeholders drawn around one organisation, with what each expects | ch04-fig02.svg

## Worked Case

> The worked case applies several chapter ideas to one documented set of facts.
:case Case file, illustrative. Case file, illustrative. Meghna and Sons, Dhanmondi, Dhaka; owner Harun Meghna; 2025 profit Tk 1,240,000; 13 employees and the owner. Economic: paper cost rose 12% between 1 July 2025 and 1 January 2026; a notebook that cost Tk 80 now costs Tk 89.60; the shop raised the selling price from Tk 100 to Tk 108 (8%) on 1 January 2026. Political and legal: the shop recorded on 15 December 2025 that a revised school curriculum is announced for the 2027 school year, which means new titles for school books. Social: in December 2025, 3 of every 10 customer enquiries (30%) asked for home delivery. Technological: mobile payment was introduced on 1 October 2025; in December 2025, 22% of sales were paid this way. Social responsibility: on 15 January 2026 the shop gave 2% of the 2025 profit, Tk 24,800, to a school library. Sustainability: from 1 March 2026 paper bags replace plastic bags; 30,000 bags are used in a year; a plastic bag costs Tk 1.50 and a paper bag Tk 4.00; the extra cost is Tk 75,000 a year. Ethics: on 11 November 2025 a distributor offered Imran Meghna a personal cash payment of Tk 40,000 for placing a larger order; he refused and reported it to the owner the same day.

> The case is examined through situation, question, reasoning, conclusion and check.
Situation. Identify the recorded facts. Question. Select the relevant chapter concepts. Reasoning. Match each fact to the definitions and compare the conditions, alternatives, responsibilities or results that the record provides. Conclusion. State only what the facts support. Check. Identify any conclusion that would require information not contained in the case.

* * *
## Summary

> The chapter joins its definitions, examples and limits into one management framework.
The chapter began with environment, ethics and social responsibility. It defined the assigned terms, applied them to the running case, and considered the conditions that limit their use. The main habit is to move from evidence to concept, from concept to comparison, and from comparison to a supported conclusion.

## Think It Through

> These questions ask for application rather than a memorised phrase.
:q 04.t1 | A small organisation records a situation that resembles this chapter's main problem. What should the manager identify first?

:q 04.t2 | A manager applies a familiar rule without checking its conditions. What should the manager revisit?

## Where People Go Wrong

> Most errors come from confusing a term with an everyday meaning or ignoring the limits of a rule.
A reader may use a familiar word without its management meaning, treat one example as universal, or describe a result without connecting it to the relevant process. The correction is to define the term, identify the evidence, apply the principle, and check the conditions that limit it.

## In History

> The historical case gives a dated setting in which the chapter's ideas can be examined.
The chapter's historical case concerns The collapse of the Rana Plaza building in Savar, Bangladesh, on 24 April 2013, and the Accord on Fire and Building Safety in Bangladesh, signed from 15 May 2013: a case of social responsibility in a supply chain. Use only dated, widely reported facts and avoid figures that sources dispute. This account is used only to illuminate the management idea. It does not turn the historical event into a model for every organisation. The relevant lesson is the documented connection between the event and the management question raised in this chapter.
> The history is evidence for a management question, not a replacement for the general rule.
The case should also be read with its limits. Historical organisations operated under conditions that may differ from a modern organisation in law, technology, scale, and social expectations. A reader can therefore use the case to understand how an idea developed or appeared in practice while avoiding claims that the same arrangement must work today.
> Historical evidence needs its original setting before it is applied to a modern organisation.

## Sources

> The chapter keeps its source trail short and tied to the ideas it defines.
The named works and historical sources in the catalogue entry provide fuller context. The chapter uses brief attribution and avoids long quotations so that the main explanation remains readable.

## Review Questions

> The final questions return to the chapter's definitions and applications.
:q 04.1 | In your own words, what is the central management idea of this chapter?

:q 04.2 | Give one concrete example from a small organisation that illustrates the central idea.

:pause 04.p1 | What fact or condition should be checked before applying the chapter's main rule?

:read Environment, Ethics and Social Responsibility background and the historical source named in the chapter entry
