:chapter I | What Management Is
:mood What becomes easier when the manager names the problem precisely?
:desc A first-year reader meets the chapter through a concrete management question. The ideas move from plain language to precise terms. The running case supplies recorded facts for application. The historical case provides a dated context.
:plate ch01-plate.svg | a bookseller behind a counter among shelves of leather-bound volumes, 1880s

* * *
## Why Organisations Need Management

> The section begins with the practical question behind why organisations need management.
Suppose a manager must deal with why organisations need management. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers organisations and their aims purpose of management importance of management as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Organisation  gives this paragraph its precise focus.
@ Organisation  |  a group of people who work together in a planned way to reach an aim that one person could not reach alone
At the centre of the discussion is **Organisation **.  a group of people who work together in a planned way to reach an aim that one person could not reach alone. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Employee  gives this paragraph its precise focus.
@ Employee  |  a person who is paid by an organisation to do work for it
At the centre of the discussion is **Employee **.  a person who is paid by an organisation to do work for it. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Why Organisations Need Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of why organisations need management in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Defining Management

> The section begins with the practical question behind defining management.
Suppose a manager must deal with defining management. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers management defined as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Management  gives this paragraph its precise focus.
@ Management  |  the work of using the resources of an organisation to reach its aims, through four connected functions
At the centre of the discussion is **Management **.  the work of using the resources of an organisation to reach its aims, through four connected functions. Management defined The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Manager  gives this paragraph its precise focus.
@ Manager  |  a person who is responsible for the work of other people and for the results of one part of an organisation
At the centre of the discussion is **Manager **.  a person who is responsible for the work of other people and for the results of one part of an organisation. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Defining Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of defining management in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Resources and Results

> The section begins with the practical question behind resources and results.
Suppose a manager must deal with resources and results. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers resources a manager uses results as the test of management as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Resource  gives this paragraph its precise focus.
@ Resource  |  anything an organisation uses to do its work, such as people, money, materials, premises and information
At the centre of the discussion is **Resource **.  anything an organisation uses to do its work, such as people, money, materials, premises and information. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Management function  gives this paragraph its precise focus.
@ Management function  |  one main kind of managerial work; there are four, and each has its own chapter in this book
At the centre of the discussion is **Management function **.  one main kind of managerial work; there are four, and each has its own chapter in this book. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Resources and Results is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of resources and results in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## The Management Process

> The section begins with the practical question behind the management process.
Suppose a manager must deal with the management process. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers the four management functions management as a continuing cycle as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Management process  gives this paragraph its precise focus.
@ Management process  |  the continuing cycle in which a manager performs the four management functions again and again
At the centre of the discussion is **Management process **.  the continuing cycle in which a manager performs the four management functions again and again. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> The Management Process is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of the management process in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
> Why Organisations Need Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Defining Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Resources and Results is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> The Management Process is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Why Organisations Need Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Defining Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Resources and Results is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> The Management Process is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Why Organisations Need Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Defining Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Resources and Results is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> The Management Process is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Why Organisations Need Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Defining Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Resources and Results is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.



:fig the four management functions drawn as a cycle around the resources of an organisation | ch01-fig01.svg

## Worked Case

> The worked case applies several chapter ideas to one documented set of facts.
:case Case file, illustrative. Case file, illustrative. Meghna and Sons, a family-run bookshop in Dhanmondi, Dhaka, founded 3 February 1996 by Harun Meghna (owner). Position at 1 January 2026: 14 people (the owner and 13 employees); shop floor 2,400 square feet; rent Tk 200,000 per month. Results for 2025: sales Tk 18,600,000; profit Tk 1,240,000. Resources at 31 December 2025: people, 14; money, cash reserve Tk 1,500,000; materials, stock held at cost Tk 6,200,000; premises, the rented shop; information, a daily sales ledger and a stock list kept on a spreadsheet. Record of the four functions for 2025: on 8 December 2024 the owner wrote the 2025 sales plan, Tk 19,000,000 (planning); on 2 January 2025 he assigned each product section to a section leader (organising); a staff meeting was held every Monday at 9:30 (leading); sales were compared with the plan at the end of each month (controlling). Outcome: sales Tk 18,600,000 against the plan of Tk 19,000,000.

> The case is examined through situation, question, reasoning, conclusion and check.
Situation. Identify the recorded facts. Question. Select the relevant chapter concepts. Reasoning. Match each fact to the definitions and compare the conditions, alternatives, responsibilities or results that the record provides. Conclusion. State only what the facts support. Check. Identify any conclusion that would require information not contained in the case.

* * *
## Summary

> The chapter joins its definitions, examples and limits into one management framework.
The chapter began with what management is. It defined the assigned terms, applied them to the running case, and considered the conditions that limit their use. The main habit is to move from evidence to concept, from concept to comparison, and from comparison to a supported conclusion.

## Think It Through

> These questions ask for application rather than a memorised phrase.
:q 01.t1 | A small organisation records a situation that resembles this chapter's main problem. What should the manager identify first?

:q 01.t2 | A manager applies a familiar rule without checking its conditions. What should the manager revisit?

## Where People Go Wrong

> Most errors come from confusing a term with an everyday meaning or ignoring the limits of a rule.
A reader may use a familiar word without its management meaning, treat one example as universal, or describe a result without connecting it to the relevant process. The correction is to define the term, identify the evidence, apply the principle, and check the conditions that limit it.

## In History

> The historical case gives a dated setting in which the chapter's ideas can be examined.
The chapter's historical case concerns Josiah Wedgwood's pottery works at Etruria, Staffordshire, opened 1769: planned division of work, set standards and close checking of quality under one managing owner. This account is used only to illuminate the management idea. It does not turn the historical event into a model for every organisation. The relevant lesson is the documented connection between the event and the management question raised in this chapter.
> The history is evidence for a management question, not a replacement for the general rule.
The case should also be read with its limits. Historical organisations operated under conditions that may differ from a modern organisation in law, technology, scale, and social expectations. A reader can therefore use the case to understand how an idea developed or appeared in practice while avoiding claims that the same arrangement must work today.
> Historical evidence needs its original setting before it is applied to a modern organisation.

## Review Questions

> The final questions return to the chapter's definitions and applications.
:q 01.1 | In your own words, what is the central management idea of this chapter?

:q 01.2 | Give one concrete example from a small organisation that illustrates the central idea.

:pause 01.p1 | What fact or condition should be checked before applying the chapter's main rule?

:read What Management Is background and the historical source named in the chapter entry
