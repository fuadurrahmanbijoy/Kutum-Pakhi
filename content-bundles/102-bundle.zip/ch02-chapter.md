:chapter II | Managers: Levels, Skills and Standing
:mood What becomes easier when the manager names the problem precisely?
:desc A first-year reader meets the chapter through a concrete management question. The ideas move from plain language to precise terms. The running case supplies recorded facts for application. The historical case provides a dated context.
:plate ch02-plate.svg | a foreman, a manager and a proprietor in three connected offices of a mill, 1870s

* * *
## Levels and Types of Managers

> The section begins with the practical question behind levels and types of managers.
Suppose a manager must deal with levels and types of managers. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers three levels of managers functional and general managers as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Top manager  gives this paragraph its precise focus.
@ Top manager  |  a manager at the highest level, who sets the direction and is responsible for the whole organisation
At the centre of the discussion is **Top manager **.  a manager at the highest level, who sets the direction and is responsible for the whole organisation. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Middle manager  gives this paragraph its precise focus.
@ Middle manager  |  a manager between top managers and first-line managers, who turns the direction into plans for one part of the organisation
At the centre of the discussion is **Middle manager **.  a manager between top managers and first-line managers, who turns the direction into plans for one part of the organisation. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> First-line manager  gives this paragraph its precise focus.
@ First-line manager  |  a manager at the lowest level, who directs employees who do the daily work and does not manage other managers
At the centre of the discussion is **First-line manager **.  a manager at the lowest level, who directs employees who do the daily work and does not manage other managers. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Levels and Types of Managers is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of levels and types of managers in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Skills Managers Need

> The section begins with the practical question behind skills managers need.
Suppose a manager must deal with skills managers need. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers technical, human and conceptual skills skills in the classic and the contemporary view as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Functional manager  gives this paragraph its precise focus.
@ Functional manager  |  a manager responsible for one kind of work, such as buying or accounts, across the organisation
At the centre of the discussion is **Functional manager **.  a manager responsible for one kind of work, such as buying or accounts, across the organisation. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> General manager  gives this paragraph its precise focus.
@ General manager  |  a manager responsible for all the kinds of work of a unit, such as a branch
At the centre of the discussion is **General manager **.  a manager responsible for all the kinds of work of a unit, such as a branch. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Technical skill  gives this paragraph its precise focus.
@ Technical skill  |  the ability to use the methods, tools and knowledge of a particular kind of work
At the centre of the discussion is **Technical skill **.  the ability to use the methods, tools and knowledge of a particular kind of work. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Skills Managers Need is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of skills managers need in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Productivity, Effectiveness and Efficiency

> The section begins with the practical question behind productivity, effectiveness and efficiency.
Suppose a manager must deal with productivity, effectiveness and efficiency. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers telling productivity, effectiveness and efficiency apart as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Human skill  gives this paragraph its precise focus.
@ Human skill  |  the ability to work with other people, understand them and get good work from them
At the centre of the discussion is **Human skill **.  the ability to work with other people, understand them and get good work from them. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Conceptual skill  gives this paragraph its precise focus.
@ Conceptual skill  |  the ability to see the organisation as a whole and to understand how its parts affect one another
At the centre of the discussion is **Conceptual skill **.  the ability to see the organisation as a whole and to understand how its parts affect one another. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Productivity  gives this paragraph its precise focus.
@ Productivity  |  the amount of output produced for a given amount of input, such as sales for each employee
At the centre of the discussion is **Productivity **.  the amount of output produced for a given amount of input, such as sales for each employee. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Productivity, Effectiveness and Efficiency is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of productivity, effectiveness and efficiency in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Science, Art or Profession

> The section begins with the practical question behind science, art or profession.
Suppose a manager must deal with science, art or profession. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers management as a science management as an art management as a profession as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Effectiveness  gives this paragraph its precise focus.
@ Effectiveness  |  the degree to which an organisation reaches the aims it has set
At the centre of the discussion is **Effectiveness **.  the degree to which an organisation reaches the aims it has set. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Efficiency  gives this paragraph its precise focus.
@ Efficiency  |  the use of as few resources as possible to obtain a given result
At the centre of the discussion is **Efficiency **.  the use of as few resources as possible to obtain a given result. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Profession  gives this paragraph its precise focus.
@ Profession  |  an occupation that requires long study, follows a code of conduct and can be entered only by meeting set standards
At the centre of the discussion is **Profession **.  an occupation that requires long study, follows a code of conduct and can be entered only by meeting set standards. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Science, Art or Profession is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of science, art or profession in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
> Levels and Types of Managers is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Skills Managers Need is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Productivity, Effectiveness and Efficiency is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Science, Art or Profession is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.



:fig three levels of managers drawn as a triangle with the skill mix at each level | ch02-fig01.svg
:fig productivity, effectiveness and efficiency shown side by side as inputs, outputs and aims | ch02-fig02.svg

## Worked Case

> The worked case applies several chapter ideas to one documented set of facts.
:case Case file, illustrative. Case file, illustrative. Meghna and Sons, Dhanmondi, Dhaka; owner Harun Meghna. Structure at 1 January 2026 (14 people): top level, the owner; middle level, three managers (Imran Meghna, purchasing; Nasrin Akter, shop floor; Rubel Hossain, accounts); first level, four section leaders (school books, general books, stationery, orders and parcels); six shop assistants. Sales: 2024 Tk 17,100,000 with 13 people; 2025 Tk 18,600,000 with 14 people. Sales for each person: 2024 Tk 1,315,385; 2025 Tk 1,328,571. Plan for 2025: Tk 19,000,000; achieved Tk 18,600,000, which is 97.9% of the plan. Unsold stock written off: 2024 Tk 310,000 (1.8% of sales); 2025 Tk 186,000 (1.0% of sales). Skill record for 2025: Imran judged which titles would sell (technical); Nasrin arranged shift rotas that all employees accepted (human); the owner decided on 8 December 2024 how the three sections and the accounts fit one plan (conceptual).

> The case is examined through situation, question, reasoning, conclusion and check.
Situation. Identify the recorded facts. Question. Select the relevant chapter concepts. Reasoning. Match each fact to the definitions and compare the conditions, alternatives, responsibilities or results that the record provides. Conclusion. State only what the facts support. Check. Identify any conclusion that would require information not contained in the case.

* * *
## Summary

> The chapter joins its definitions, examples and limits into one management framework.
The chapter began with managers: levels, skills and standing. It defined the assigned terms, applied them to the running case, and considered the conditions that limit their use. The main habit is to move from evidence to concept, from concept to comparison, and from comparison to a supported conclusion.

## Think It Through

> These questions ask for application rather than a memorised phrase.
:q 02.t1 | A small organisation records a situation that resembles this chapter's main problem. What should the manager identify first?

:q 02.t2 | A manager applies a familiar rule without checking its conditions. What should the manager revisit?

## Where People Go Wrong

> Most errors come from confusing a term with an everyday meaning or ignoring the limits of a rule.
A reader may use a familiar word without its management meaning, treat one example as universal, or describe a result without connecting it to the relevant process. The correction is to define the term, identify the evidence, apply the principle, and check the conditions that limit it.

## In History

> The historical case gives a dated setting in which the chapter's ideas can be examined.
The chapter's historical case concerns Robert L. Katz, 'Skills of an Effective Administrator', Harvard Business Review, 1955: the three-skill view, drawn from his observation of managers. This account is used only to illuminate the management idea. It does not turn the historical event into a model for every organisation. The relevant lesson is the documented connection between the event and the management question raised in this chapter.
> The history is evidence for a management question, not a replacement for the general rule.
The case should also be read with its limits. Historical organisations operated under conditions that may differ from a modern organisation in law, technology, scale, and social expectations. A reader can therefore use the case to understand how an idea developed or appeared in practice while avoiding claims that the same arrangement must work today.
> Historical evidence needs its original setting before it is applied to a modern organisation.

## Sources

> The chapter keeps its source trail short and tied to the ideas it defines.
The named works and historical sources in the catalogue entry provide fuller context. The chapter uses brief attribution and avoids long quotations so that the main explanation remains readable.

## Review Questions

> The final questions return to the chapter's definitions and applications.
:q 02.1 | In your own words, what is the central management idea of this chapter?

:q 02.2 | Give one concrete example from a small organisation that illustrates the central idea.

:pause 02.p1 | What fact or condition should be checked before applying the chapter's main rule?

:read Managers: Levels, Skills and Standing background and the historical source named in the chapter entry
