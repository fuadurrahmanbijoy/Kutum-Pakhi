:chapter A1 | Maths You Will Use
> This appendix is a compact reference for the arithmetic used throughout the book.
It gives small examples that can be checked by hand. It is a reference, not a lesson.

:fig a simple line graph with labelled axes and one marked point | a1-fig01.svg
## Percentages and Percentage Change

> Percentages and Percentage Change is handled by a short procedure and a check.
Start by writing the numbers exactly as given. State what is being found, choose the operation that matches the question, calculate one line at a time, and check the size and units of the result. For percentage change, compare the change with the old value. For ratios, compare like quantities. For an equation, perform the same operation on both sides. For a graph, read both axes before reading a point.

> Percentage  gives the numerical idea its exact meaning.
@ Percentage  |  a number written as a part of 100, shown with the sign %
**Percentage ** means  a number written as a part of 100, shown with the sign %. Use the definition before choosing an operation. Example. If the numbers are 100 and 120, write the old value and new value explicitly before calculating.

> Percentage change  gives the numerical idea its exact meaning.
@ Percentage change  |  the change between an old and a new value, divided by the old value and written as a percentage
**Percentage change ** means  the change between an old and a new value, divided by the old value and written as a percentage. Use the definition before choosing an operation. Example. If the numbers are 100 and 120, write the old value and new value explicitly before calculating.

> The numerical example shows the operation and the check in one small case.
Example. If sales rise from Tk 100 to Tk 120, the change is Tk 20 and the percentage change is (20 ÷ 100) × 100 = 20%. The check is that Tk 20 is one fifth of Tk 100.

* * *
## Ratios, Averages and Rounding

> Ratios, Averages and Rounding is handled by a short procedure and a check.
Start by writing the numbers exactly as given. State what is being found, choose the operation that matches the question, calculate one line at a time, and check the size and units of the result. For percentage change, compare the change with the old value. For ratios, compare like quantities. For an equation, perform the same operation on both sides. For a graph, read both axes before reading a point.

> Ratio  gives the numerical idea its exact meaning.
@ Ratio  |  a comparison of two quantities, shown as a:b or as a fraction
**Ratio ** means  a comparison of two quantities, shown as a:b or as a fraction. Use the definition before choosing an operation. Example. If the numbers are 100 and 120, write the old value and new value explicitly before calculating.

> Mean  gives the numerical idea its exact meaning.
@ Mean  |  the sum of a set of values divided by the number of values
**Mean ** means  the sum of a set of values divided by the number of values. Use the definition before choosing an operation. Example. If the numbers are 100 and 120, write the old value and new value explicitly before calculating.

> The numerical example shows the operation and the check in one small case.
Example. If sales rise from Tk 100 to Tk 120, the change is Tk 20 and the percentage change is (20 ÷ 100) × 100 = 20%. The check is that Tk 20 is one fifth of Tk 100.

* * *
## Rearranging an Equation

> Rearranging an Equation is handled by a short procedure and a check.
Start by writing the numbers exactly as given. State what is being found, choose the operation that matches the question, calculate one line at a time, and check the size and units of the result. For percentage change, compare the change with the old value. For ratios, compare like quantities. For an equation, perform the same operation on both sides. For a graph, read both axes before reading a point.

> Rounding  gives the numerical idea its exact meaning.
@ Rounding  |  replacing a number with a nearby number that has fewer digits, by a stated rule
**Rounding ** means  replacing a number with a nearby number that has fewer digits, by a stated rule. Use the definition before choosing an operation. Example. If the numbers are 100 and 120, write the old value and new value explicitly before calculating.

> Axis  gives the numerical idea its exact meaning.
@ Axis  |  a labelled line on a graph along which a quantity is measured
**Axis ** means  a labelled line on a graph along which a quantity is measured. Use the definition before choosing an operation. Example. If the numbers are 100 and 120, write the old value and new value explicitly before calculating.

> The numerical example shows the operation and the check in one small case.
Example. If sales rise from Tk 100 to Tk 120, the change is Tk 20 and the percentage change is (20 ÷ 100) × 100 = 20%. The check is that Tk 20 is one fifth of Tk 100.

* * *
## Reading a Graph

> Reading a Graph is handled by a short procedure and a check.
Start by writing the numbers exactly as given. State what is being found, choose the operation that matches the question, calculate one line at a time, and check the size and units of the result. For percentage change, compare the change with the old value. For ratios, compare like quantities. For an equation, perform the same operation on both sides. For a graph, read both axes before reading a point.

> The numerical example shows the operation and the check in one small case.
Example. If sales rise from Tk 100 to Tk 120, the change is Tk 20 and the percentage change is (20 ÷ 100) × 100 = 20%. The check is that Tk 20 is one fifth of Tk 100.

* * *
