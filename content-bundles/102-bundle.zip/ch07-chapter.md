:chapter VII | Decision Making
:mood What becomes easier when the manager names the problem precisely?
:desc A first-year reader meets the chapter through a concrete management question. The ideas move from plain language to precise terms. The running case supplies recorded facts for application. The historical case provides a dated context.
:plate ch07-plate.svg | a pair of brass scales on a counting-house table with coins and a quill, 1880s

* * *
## The Decision-Making Process

> The section begins with the practical question behind the decision-making process.
Suppose a manager must deal with the decision-making process. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers steps of the rational decision-making process as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Decision  gives this paragraph its precise focus.
@ Decision  |  a choice made between two or more alternatives to reach an aim
At the centre of the discussion is **Decision **.  a choice made between two or more alternatives to reach an aim. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Decision making  gives this paragraph its precise focus.
@ Decision making  |  the process of recognising a problem or chance, finding alternatives and choosing one
At the centre of the discussion is **Decision making **.  the process of recognising a problem or chance, finding alternatives and choosing one. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Decision maker  gives this paragraph its precise focus.
@ Decision maker  |  the person or group that makes the choice
At the centre of the discussion is **Decision maker **.  the person or group that makes the choice. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Alternative  gives this paragraph its precise focus.
@ Alternative  |  one of the possible courses of action from which a choice is made
At the centre of the discussion is **Alternative **.  one of the possible courses of action from which a choice is made. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> The Decision-Making Process is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of the decision-making process in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Elements and Conditions of a Decision

> The section begins with the practical question behind elements and conditions of a decision.
Suppose a manager must deal with elements and conditions of a decision. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers elements of a decision situation certainty, risk and uncertainty as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Criterion  gives this paragraph its precise focus.
@ Criterion  |  a standard used to judge the alternatives, such as cost or risk
At the centre of the discussion is **Criterion **.  a standard used to judge the alternatives, such as cost or risk. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Certainty  gives this paragraph its precise focus.
@ Certainty  |  a condition in which the decision maker knows the result of each alternative
At the centre of the discussion is **Certainty **.  a condition in which the decision maker knows the result of each alternative. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Risk  gives this paragraph its precise focus.
@ Risk  |  a condition in which the result of each alternative is not known but its probability is known
At the centre of the discussion is **Risk **.  a condition in which the result of each alternative is not known but its probability is known. Certainty, risk and uncertainty The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Uncertainty  gives this paragraph its precise focus.
@ Uncertainty  |  a condition in which neither the result nor the probability of each alternative is known
At the centre of the discussion is **Uncertainty **.  a condition in which neither the result nor the probability of each alternative is known. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Elements and Conditions of a Decision is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of elements and conditions of a decision in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Groups and Real-World Constraints

> The section begins with the practical question behind groups and real-world constraints.
Suppose a manager must deal with groups and real-world constraints. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers nature of managerial decision making and its limits group decision making: gains and costs other influences on a decision as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Rational decision making  gives this paragraph its precise focus.
@ Rational decision making  |  choosing the alternative that best meets set criteria after studying all the alternatives
At the centre of the discussion is **Rational decision making **.  choosing the alternative that best meets set criteria after studying all the alternatives. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Bounded rationality  gives this paragraph its precise focus.
@ Bounded rationality  |  the limit on rational choice that arises because people have limited time, information and ability
At the centre of the discussion is **Bounded rationality **.  the limit on rational choice that arises because people have limited time, information and ability. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Groupthink  gives this paragraph its precise focus.
@ Groupthink  |  the habit of a close group to agree quickly and to ignore doubts and facts that disturb agreement
At the centre of the discussion is **Groupthink **.  the habit of a close group to agree quickly and to ignore doubts and facts that disturb agreement. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Probability  gives this paragraph its precise focus.
@ Probability  |  a number between 0 and 1 that states how likely an event is
At the centre of the discussion is **Probability **.  a number between 0 and 1 that states how likely an event is. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Groups and Real-World Constraints is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of groups and real-world constraints in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Tools: Probability, Decision Trees and Support Systems

> The section begins with the practical question behind tools: probability, decision trees and support systems.
Suppose a manager must deal with tools: probability, decision trees and support systems. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers probability and expected value decision trees decision support systems as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Expected value  gives this paragraph its precise focus.
@ Expected value  |  the sum of each possible result multiplied by its probability
At the centre of the discussion is **Expected value **.  the sum of each possible result multiplied by its probability. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Decision tree  gives this paragraph its precise focus.
@ Decision tree  |  a diagram that shows alternatives, chance events, probabilities and results in branches
At the centre of the discussion is **Decision tree **.  a diagram that shows alternatives, chance events, probabilities and results in branches. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Decision support system  gives this paragraph its precise focus.
@ Decision support system  |  a computer-based set of data and tools that helps a manager study a decision
At the centre of the discussion is **Decision support system **.  a computer-based set of data and tools that helps a manager study a decision. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Tools: Probability, Decision Trees and Support Systems is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of tools: probability, decision trees and support systems in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
> The Decision-Making Process is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.



:fig the steps of the rational decision-making process as a flow with a return path | ch07-fig01.svg
:fig a decision tree with two options, chance branches, probabilities and expected values | ch07-fig02.svg

## Worked Case

> The worked case applies several chapter ideas to one documented set of facts.
:case Case file, illustrative. Case file, illustrative. Meghna and Sons, Dhanmondi, Dhaka; owner Harun Meghna. Meeting of 20 January 2026 (95 minutes; the owner and 3 managers). Cash reserve Tk 1,500,000. Problem: sales growth of 10% (Tk 20,460,000) cannot come from walk-in customers alone. Alternatives: A, open a second branch, cost Tk 2,400,000 (Tk 900,000 more than the cash reserve); B, begin online ordering, cost Tk 600,000; C, change nothing. Criteria: cost within the cash reserve; expected value over three years; risk. Demand, with probabilities: branch, strong 0.5 giving extra profit Tk 1,200,000 a year, weak 0.5 giving Tk 200,000 a year; online, strong 0.6 giving Tk 700,000 a year, weak 0.4 giving Tk 150,000 a year. Expected profit a year: A Tk 700,000; B Tk 480,000. Over three years: A Tk 2,100,000, less cost Tk 2,400,000, net Tk -300,000; B Tk 1,440,000, less cost Tk 600,000, net Tk 840,000; C Tk 0. Before the meeting 2 of the 4 favoured the branch; after it all 4 favoured online ordering. Rent Tk 200,000 a month is a certain figure; the 2027 curriculum is an uncertain one. Data came from a sales spreadsheet covering two years only. Decision recorded on 21 January 2026: begin online ordering.

> The case is examined through situation, question, reasoning, conclusion and check.
Situation. Identify the recorded facts. Question. Select the relevant chapter concepts. Reasoning. Match each fact to the definitions and compare the conditions, alternatives, responsibilities or results that the record provides. Conclusion. State only what the facts support. Check. Identify any conclusion that would require information not contained in the case.

* * *
## Summary

> The chapter joins its definitions, examples and limits into one management framework.
The chapter began with decision making. It defined the assigned terms, applied them to the running case, and considered the conditions that limit their use. The main habit is to move from evidence to concept, from concept to comparison, and from comparison to a supported conclusion.

## Think It Through

> These questions ask for application rather than a memorised phrase.
:q 07.t1 | A small organisation records a situation that resembles this chapter's main problem. What should the manager identify first?

:q 07.t2 | A manager applies a familiar rule without checking its conditions. What should the manager revisit?

## Where People Go Wrong

> Most errors come from confusing a term with an everyday meaning or ignoring the limits of a rule.
A reader may use a familiar word without its management meaning, treat one example as universal, or describe a result without connecting it to the relevant process. The correction is to define the term, identify the evidence, apply the principle, and check the conditions that limit it.

## In History

> The historical case gives a dated setting in which the chapter's ideas can be examined.
The chapter's historical case concerns The decision to launch the space shuttle Challenger on 28 January 1986 and the findings of the Rogers Commission (1986); group pressure and the handling of risk. Use only dated facts that sources agree on. This account is used only to illuminate the management idea. It does not turn the historical event into a model for every organisation. The relevant lesson is the documented connection between the event and the management question raised in this chapter.
> The history is evidence for a management question, not a replacement for the general rule.
The case should also be read with its limits. Historical organisations operated under conditions that may differ from a modern organisation in law, technology, scale, and social expectations. A reader can therefore use the case to understand how an idea developed or appeared in practice while avoiding claims that the same arrangement must work today.
> Historical evidence needs its original setting before it is applied to a modern organisation.

## Review Questions

> The final questions return to the chapter's definitions and applications.
:q 07.1 | In your own words, what is the central management idea of this chapter?

:q 07.2 | Give one concrete example from a small organisation that illustrates the central idea.

:pause 07.p1 | What fact or condition should be checked before applying the chapter's main rule?

:read Decision Making background and the historical source named in the chapter entry
