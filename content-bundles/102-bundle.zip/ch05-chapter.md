:chapter V | Planning
:mood What becomes easier when the manager names the problem precisely?
:desc A first-year reader meets the chapter through a concrete management question. The ideas move from plain language to precise terms. The running case supplies recorded facts for application. The historical case provides a dated context.
:plate ch05-plate.svg | a draughtsman at a drawing board with plans and a T-square, 1880s

* * *
## Meaning, Nature and Purpose

> The section begins with the practical question behind meaning, nature and purpose.
Suppose a manager must deal with meaning, nature and purpose. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers what planning is nature of planning purposes of planning as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Planning  gives this paragraph its precise focus.
@ Planning  |  choosing in advance what the organisation will do and how it will do it
At the centre of the discussion is **Planning **.  choosing in advance what the organisation will do and how it will do it. What planning is The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Plan  gives this paragraph its precise focus.
@ Plan  |  a written or agreed description of what is to be done, by whom, by when and with what resources
At the centre of the discussion is **Plan **.  a written or agreed description of what is to be done, by whom, by when and with what resources. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Planning premise  gives this paragraph its precise focus.
@ Planning premise  |  an assumption about the future conditions under which a plan will be carried out
At the centre of the discussion is **Planning premise **.  an assumption about the future conditions under which a plan will be carried out. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Meaning, Nature and Purpose is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of meaning, nature and purpose in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Types of Plans

> The section begins with the practical question behind types of plans.
Suppose a manager must deal with types of plans. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers standing plans and single-use plans as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Standing plan  gives this paragraph its precise focus.
@ Standing plan  |  a plan made once and used again and again for situations that recur
At the centre of the discussion is **Standing plan **.  a plan made once and used again and again for situations that recur. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Single-use plan  gives this paragraph its precise focus.
@ Single-use plan  |  a plan made for one occasion or project that is not used again in the same form
At the centre of the discussion is **Single-use plan **.  a plan made for one occasion or project that is not used again in the same form. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Policy  gives this paragraph its precise focus.
@ Policy  |  a standing plan that gives a general guide for decisions without fixing the exact action
At the centre of the discussion is **Policy **.  a standing plan that gives a general guide for decisions without fixing the exact action. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Types of Plans is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of types of plans in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## The Planning Process

> The section begins with the practical question behind the planning process.
Suppose a manager must deal with the planning process. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers planning premises steps of the planning process as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Procedure  gives this paragraph its precise focus.
@ Procedure  |  a standing plan that sets out the steps to be followed for a recurring task, in order
At the centre of the discussion is **Procedure **.  a standing plan that sets out the steps to be followed for a recurring task, in order. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Rule  gives this paragraph its precise focus.
@ Rule  |  a standing plan that requires or forbids one specific action, with no choice
At the centre of the discussion is **Rule **.  a standing plan that requires or forbids one specific action, with no choice. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Programme  gives this paragraph its precise focus.
@ Programme  |  a single-use plan that sets out the steps, order, timing and resources for a set of related tasks
At the centre of the discussion is **Programme **.  a single-use plan that sets out the steps, order, timing and resources for a set of related tasks. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> The Planning Process is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of the planning process in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Limits and Effectiveness

> The section begins with the practical question behind limits and effectiveness.
Suppose a manager must deal with limits and effectiveness. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers limits of planning and why plans fail making planning effective as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Budget  gives this paragraph its precise focus.
@ Budget  |  a plan stated in money, or in other numbers, for a period of time
At the centre of the discussion is **Budget **.  a plan stated in money, or in other numbers, for a period of time. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Limits and Effectiveness is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of limits and effectiveness in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
> Meaning, Nature and Purpose is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Types of Plans is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> The Planning Process is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Limits and Effectiveness is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Meaning, Nature and Purpose is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Types of Plans is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> The Planning Process is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.



:fig the steps of the planning process in order, with the feedback line from review back to the premises | ch05-fig01.svg
:fig standing plans and single-use plans shown as two branches with their parts | ch05-fig02.svg

## Worked Case

> The worked case applies several chapter ideas to one documented set of facts.
:case Case file, illustrative. Case file, illustrative. Meghna and Sons, Dhanmondi, Dhaka; owner Harun Meghna. Planning meeting of 6 January 2026. Result for 2025: sales Tk 18,600,000. Sales objective for 2026: Tk 20,460,000, which is 10% above 2025. Premises recorded: paper cost up 12% between 1 July 2025 and 1 January 2026; school enrolment unchanged; rent unchanged at Tk 200,000 per month; employee pay up 5% from 1 January 2026, so yearly pay for the 13 employees rises from Tk 5,100,000 to Tk 5,355,000. Alternatives listed: longer opening hours; online ordering; a second branch; no change. Online ordering and the second branch were carried forward for study. Standing plans in use: policy, books in good condition are exchanged within 7 days; procedure, four steps for receiving new stock; rule, no stock leaves the shop without a record. Single-use plan: the January school-term rush programme of 1 to 31 January 2026, with extra stock of Tk 900,000 ordered on 10 December 2025. A failed plan of 2024: 1,200 copies of one guide book were ordered on the premise that the school curriculum would not change; it was revised three months later; 400 copies sold; 800 unsold copies at Tk 180 each, Tk 144,000, were written off.

> The case is examined through situation, question, reasoning, conclusion and check.
Situation. Identify the recorded facts. Question. Select the relevant chapter concepts. Reasoning. Match each fact to the definitions and compare the conditions, alternatives, responsibilities or results that the record provides. Conclusion. State only what the facts support. Check. Identify any conclusion that would require information not contained in the case.

* * *
## Summary

> The chapter joins its definitions, examples and limits into one management framework.
The chapter began with planning. It defined the assigned terms, applied them to the running case, and considered the conditions that limit their use. The main habit is to move from evidence to concept, from concept to comparison, and from comparison to a supported conclusion.

## Think It Through

> These questions ask for application rather than a memorised phrase.
:q 05.t1 | A small organisation records a situation that resembles this chapter's main problem. What should the manager identify first?

:q 05.t2 | A manager applies a familiar rule without checking its conditions. What should the manager revisit?

## Where People Go Wrong

> Most errors come from confusing a term with an everyday meaning or ignoring the limits of a rule.
A reader may use a familiar word without its management meaning, treat one example as universal, or describe a result without connecting it to the relevant process. The correction is to define the term, identify the evidence, apply the principle, and check the conditions that limit it.

## In History

> The historical case gives a dated setting in which the chapter's ideas can be examined.
The chapter's historical case concerns Eastman Kodak: its engineer Steven Sasson built a digital camera in 1975, the company's plans kept its film business at the centre, and Kodak filed for bankruptcy protection on 19 January 2012. Use only dated facts that sources agree on. This account is used only to illuminate the management idea. It does not turn the historical event into a model for every organisation. The relevant lesson is the documented connection between the event and the management question raised in this chapter.
> The history is evidence for a management question, not a replacement for the general rule.
The case should also be read with its limits. Historical organisations operated under conditions that may differ from a modern organisation in law, technology, scale, and social expectations. A reader can therefore use the case to understand how an idea developed or appeared in practice while avoiding claims that the same arrangement must work today.
> Historical evidence needs its original setting before it is applied to a modern organisation.

## Review Questions

> The final questions return to the chapter's definitions and applications.
:q 05.1 | In your own words, what is the central management idea of this chapter?

:q 05.2 | Give one concrete example from a small organisation that illustrates the central idea.

:pause 05.p1 | What fact or condition should be checked before applying the chapter's main rule?

:read Planning background and the historical source named in the chapter entry
