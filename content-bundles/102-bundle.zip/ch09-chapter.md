:chapter IX | Span, Departments, Authority and Coordination
:mood What becomes easier when the manager names the problem precisely?
:desc A first-year reader meets the chapter through a concrete management question. The ideas move from plain language to precise terms. The running case supplies recorded facts for application. The historical case provides a dated context.
:plate ch09-plate.svg | a lattice-girder bridge over a river with several spans, 1880s

* * *
## Span of Management

> The section begins with the practical question behind span of management.
Suppose a manager must deal with span of management. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers span of management factors that decide the span as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Span of management  gives this paragraph its precise focus.
@ Span of management  |  the number of subordinates who report directly to one manager
At the centre of the discussion is **Span of management **.  the number of subordinates who report directly to one manager. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Tall structure  gives this paragraph its precise focus.
@ Tall structure  |  a structure with many levels and a narrow span of management at each level
At the centre of the discussion is **Tall structure **.  a structure with many levels and a narrow span of management at each level. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Flat structure  gives this paragraph its precise focus.
@ Flat structure  |  a structure with few levels and a wide span of management at each level
At the centre of the discussion is **Flat structure **.  a structure with few levels and a wide span of management at each level. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Span of Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of span of management in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Departmentalisation

> The section begins with the practical question behind departmentalisation.
Suppose a manager must deal with departmentalisation. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers departmentalisation as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Departmentalisation  gives this paragraph its precise focus.
@ Departmentalisation  |  the grouping of jobs into departments by a common feature such as function, product, area or customer
At the centre of the discussion is **Departmentalisation **.  the grouping of jobs into departments by a common feature such as function, product, area or customer. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Authority  gives this paragraph its precise focus.
@ Authority  |  the right of a manager to make decisions and to direct others, given by the position held
At the centre of the discussion is **Authority **.  the right of a manager to make decisions and to direct others, given by the position held. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Responsibility  gives this paragraph its precise focus.
@ Responsibility  |  the duty to carry out the tasks assigned and to answer for the results
At the centre of the discussion is **Responsibility **.  the duty to carry out the tasks assigned and to answer for the results. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Departmentalisation is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of departmentalisation in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Authority, Responsibility and Delegation

> The section begins with the practical question behind authority, responsibility and delegation.
Suppose a manager must deal with authority, responsibility and delegation. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers authority, responsibility and accountability line, staff and functional authority delegation and its obstacles as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Accountability  gives this paragraph its precise focus.
@ Accountability  |  the obligation to report on results and to accept the consequences
At the centre of the discussion is **Accountability **.  the obligation to report on results and to accept the consequences. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Line authority  gives this paragraph its precise focus.
@ Line authority  |  the right to direct the work of subordinates in the main chain of command
At the centre of the discussion is **Line authority **.  the right to direct the work of subordinates in the main chain of command. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Staff authority  gives this paragraph its precise focus.
@ Staff authority  |  the right to advise and serve line managers without directing their subordinates
At the centre of the discussion is **Staff authority **.  the right to advise and serve line managers without directing their subordinates. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Authority, Responsibility and Delegation is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of authority, responsibility and delegation in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Centralisation and Decentralisation

> The section begins with the practical question behind centralisation and decentralisation.
Suppose a manager must deal with centralisation and decentralisation. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers centralisation and decentralisation as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Functional authority  gives this paragraph its precise focus.
@ Functional authority  |  the limited right of a specialist to direct others in one matter that falls in his or her field
At the centre of the discussion is **Functional authority **.  the limited right of a specialist to direct others in one matter that falls in his or her field. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Delegation  gives this paragraph its precise focus.
@ Delegation  |  giving a subordinate the authority to carry out a task while the manager remains answerable for the result
At the centre of the discussion is **Delegation **.  giving a subordinate the authority to carry out a task while the manager remains answerable for the result. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Centralisation  gives this paragraph its precise focus.
@ Centralisation  |  keeping most decision-making authority at the top of an organisation
At the centre of the discussion is **Centralisation **.  keeping most decision-making authority at the top of an organisation. Centralisation and decentralisation The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Centralisation and Decentralisation is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of centralisation and decentralisation in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Coordination

> The section begins with the practical question behind coordination.
Suppose a manager must deal with coordination. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers coordination and why divided work needs it structural and activity coordination as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Decentralisation  gives this paragraph its precise focus.
@ Decentralisation  |  passing decision-making authority down to lower levels
At the centre of the discussion is **Decentralisation **.  passing decision-making authority down to lower levels. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Coordination  gives this paragraph its precise focus.
@ Coordination  |  joining the work of different people and parts so that they act together towards the same aim
At the centre of the discussion is **Coordination **.  joining the work of different people and parts so that they act together towards the same aim. Coordination and why divided work needs it The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Coordination is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of coordination in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *


:fig a tall structure and a flat structure for the same 17 people, drawn side by side | ch09-fig01.svg
:fig authority and decision rights shown on a line from centralised to decentralised | ch09-fig02.svg

## Worked Case

> The worked case applies several chapter ideas to one documented set of facts.
:case Case file, illustrative. Case file, illustrative. Meghna and Sons, Dhanmondi, Dhaka; owner Harun Meghna; structure from 1 April 2026 (17 people): owner; four managers (Imran Meghna, purchasing, 1 assistant; Nasrin Akter, shop floor; Rubel Hossain, accounts, 1 assistant; Farhan Meghna, online, 2 assistants); four section leaders under Nasrin Akter (school books with 2 assistants; general books with 1; stationery with 1; orders and parcels with none). Spans: owner 4; Nasrin Akter 4; Farhan Meghna 2; Imran Meghna 1; Rubel Hossain 1. Grouping: by function (purchasing, shop floor, accounts, online); inside the shop floor, by product (school books, general books, stationery) and by process (orders and parcels). Rubel Hossain also holds functional authority over spending forms in every section. Delegation on 1 April 2026: the owner moves the approval of purchase orders up to Tk 100,000 to Imran Meghna (it was Tk 20,000 before); larger orders still need the owner's signature; the owner remains answerable for purchasing results; Imran reports on orders to the owner each month. Record for April 2026: 18 orders approved by Imran Meghna; 2 above Tk 100,000 went to the owner. Coordination: a Monday meeting of the four managers at 9:30 for 30 minutes; a stock list updated each day by 18:00; online parcels reach the orders and parcels section before 14:00.

> The case is examined through situation, question, reasoning, conclusion and check.
Situation. Identify the recorded facts. Question. Select the relevant chapter concepts. Reasoning. Match each fact to the definitions and compare the conditions, alternatives, responsibilities or results that the record provides. Conclusion. State only what the facts support. Check. Identify any conclusion that would require information not contained in the case.

* * *
## Summary

> The chapter joins its definitions, examples and limits into one management framework.
The chapter began with span, departments, authority and coordination. It defined the assigned terms, applied them to the running case, and considered the conditions that limit their use. The main habit is to move from evidence to concept, from concept to comparison, and from comparison to a supported conclusion.

## Think It Through

> These questions ask for application rather than a memorised phrase.
:q 09.t1 | A small organisation records a situation that resembles this chapter's main problem. What should the manager identify first?

:q 09.t2 | A manager applies a familiar rule without checking its conditions. What should the manager revisit?

## Where People Go Wrong

> Most errors come from confusing a term with an everyday meaning or ignoring the limits of a rule.
A reader may use a familiar word without its management meaning, treat one example as universal, or describe a result without connecting it to the relevant process. The correction is to define the term, identify the evidence, apply the principle, and check the conditions that limit it.

## In History

> The historical case gives a dated setting in which the chapter's ideas can be examined.
The chapter's historical case concerns General Motors in the 1920s: Alfred P. Sloan's organisation study of 1920 and the policy of decentralised operations with central control of finance and policy. Use only dated facts that sources agree on. This account is used only to illuminate the management idea. It does not turn the historical event into a model for every organisation. The relevant lesson is the documented connection between the event and the management question raised in this chapter.
> The history is evidence for a management question, not a replacement for the general rule.
The case should also be read with its limits. Historical organisations operated under conditions that may differ from a modern organisation in law, technology, scale, and social expectations. A reader can therefore use the case to understand how an idea developed or appeared in practice while avoiding claims that the same arrangement must work today.
> Historical evidence needs its original setting before it is applied to a modern organisation.

## Review Questions

> The final questions return to the chapter's definitions and applications.
:q 09.1 | In your own words, what is the central management idea of this chapter?

:q 09.2 | Give one concrete example from a small organisation that illustrates the central idea.

:pause 09.p1 | What fact or condition should be checked before applying the chapter's main rule?

:read Span, Departments, Authority and Coordination background and the historical source named in the chapter entry
