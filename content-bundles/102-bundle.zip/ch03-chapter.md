:chapter III | How Management Thought Developed
:mood What becomes easier when the manager names the problem precisely?
:desc A first-year reader meets the chapter through a concrete management question. The ideas move from plain language to precise terms. The running case supplies recorded facts for application. The historical case provides a dated context.
:plate ch03-plate.svg | a mill floor with a timekeeper holding a pocket watch beside a loom, 1880s

* * *
## Early Ideas and Scientific Management

> The section begins with the practical question behind early ideas and scientific management.
Suppose a manager must deal with early ideas and scientific management. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers why early industry needed new methods scientific management as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Scientific management  gives this paragraph its precise focus.
@ Scientific management  |  a method that studies each task by measurement, finds the best way to do it and trains employees in that way
At the centre of the discussion is **Scientific management **.  a method that studies each task by measurement, finds the best way to do it and trains employees in that way. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Time study  gives this paragraph its precise focus.
@ Time study  |  the careful timing of each step of a task to find out how long the work should take
At the centre of the discussion is **Time study **.  the careful timing of each step of a task to find out how long the work should take. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Administrative management  gives this paragraph its precise focus.
@ Administrative management  |  a view that studies the whole organisation and seeks general principles for managing it
At the centre of the discussion is **Administrative management **.  a view that studies the whole organisation and seeks general principles for managing it. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Early Ideas and Scientific Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of early ideas and scientific management in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Fayol and Administrative Principles

> The section begins with the practical question behind fayol and administrative principles.
Suppose a manager must deal with fayol and administrative principles. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers fayol's administrative principles as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Principle of management  gives this paragraph its precise focus.
@ Principle of management  |  a general guide to good managing, which is tested by use and is not a law of nature
At the centre of the discussion is **Principle of management **.  a general guide to good managing, which is tested by use and is not a law of nature. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Division of work  gives this paragraph its precise focus.
@ Division of work  |  the splitting of a large task into smaller tasks, each done by one person or group
At the centre of the discussion is **Division of work **.  the splitting of a large task into smaller tasks, each done by one person or group. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Unity of command  gives this paragraph its precise focus.
@ Unity of command  |  the rule that each employee receives orders from one manager only
At the centre of the discussion is **Unity of command **.  the rule that each employee receives orders from one manager only. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Fayol and Administrative Principles is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of fayol and administrative principles in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Human Relations and Behavioural Thought

> The section begins with the practical question behind human relations and behavioural thought.
Suppose a manager must deal with human relations and behavioural thought. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers human relations and behavioural thought as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Scalar chain  gives this paragraph its precise focus.
@ Scalar chain  |  the line of authority from the top of an organisation down to the lowest level
At the centre of the discussion is **Scalar chain **.  the line of authority from the top of an organisation down to the lowest level. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Human relations approach  gives this paragraph its precise focus.
@ Human relations approach  |  a view that output depends on the needs, feelings and groups of employees as well as on methods
At the centre of the discussion is **Human relations approach **.  a view that output depends on the needs, feelings and groups of employees as well as on methods. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Behavioural approach  gives this paragraph its precise focus.
@ Behavioural approach  |  the study of how individuals and groups act at work, using methods from psychology and sociology
At the centre of the discussion is **Behavioural approach **.  the study of how individuals and groups act at work, using methods from psychology and sociology. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Human Relations and Behavioural Thought is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of human relations and behavioural thought in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Management Science, Systems and Contingency

> The section begins with the practical question behind management science, systems and contingency.
Suppose a manager must deal with management science, systems and contingency. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers management science approach systems approach contingency approach as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Management science approach  gives this paragraph its precise focus.
@ Management science approach  |  the use of mathematical models and measured data to solve managerial problems
At the centre of the discussion is **Management science approach **.  the use of mathematical models and measured data to solve managerial problems. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> System  gives this paragraph its precise focus.
@ System  |  a set of connected parts that work together and receive inputs from, and give outputs to, their surroundings
At the centre of the discussion is **System **.  a set of connected parts that work together and receive inputs from, and give outputs to, their surroundings. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Contingency approach  gives this paragraph its precise focus.
@ Contingency approach  |  the view that the best way to manage depends on the situation
At the centre of the discussion is **Contingency approach **.  the view that the best way to manage depends on the situation. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Management Science, Systems and Contingency is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of management science, systems and contingency in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
> Early Ideas and Scientific Management is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Fayol and Administrative Principles is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Human Relations and Behavioural Thought is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.



:fig a timeline of five approaches to managing, with the period of each and its main idea | ch03-fig01.svg

## Worked Case

> The worked case applies several chapter ideas to one documented set of facts.
:case Case file, illustrative. Case file, illustrative. Meghna and Sons, Dhanmondi, Dhaka; owner Harun Meghna; 13 employees and the owner at 1 December 2025. Time study of 10 November 2025 (by Imran Meghna): packing a parcel of three books, ten parcels timed for each of three methods; averages per parcel: method A 9 minutes, method B 7 minutes, method C 6 minutes. Method C was adopted on 1 December 2025; the orders and parcels section packs 40 parcels each day, so the saving is 3 minutes x 40 = 120 minutes each day against method A. Conflicting orders on 15 December 2025: a shop assistant received different orders from the stationery section leader and from the shop floor manager at the same time; shelving of 300 items was delayed by 2 hours; from 16 December 2025 each assistant receives orders from one section leader only. Reorder rule of 20 December 2025 (Rubel Hossain): a school notebook sells 60 a day and delivery takes 5 days, so the shop reorders when stock falls to 300 notebooks. The same rule is not used in the January rush, when daily sales are higher.

> The case is examined through situation, question, reasoning, conclusion and check.
Situation. Identify the recorded facts. Question. Select the relevant chapter concepts. Reasoning. Match each fact to the definitions and compare the conditions, alternatives, responsibilities or results that the record provides. Conclusion. State only what the facts support. Check. Identify any conclusion that would require information not contained in the case.

* * *
## Summary

> The chapter joins its definitions, examples and limits into one management framework.
The chapter began with how management thought developed. It defined the assigned terms, applied them to the running case, and considered the conditions that limit their use. The main habit is to move from evidence to concept, from concept to comparison, and from comparison to a supported conclusion.

## Think It Through

> These questions ask for application rather than a memorised phrase.
:q 03.t1 | A small organisation records a situation that resembles this chapter's main problem. What should the manager identify first?

:q 03.t2 | A manager applies a familiar rule without checking its conditions. What should the manager revisit?

## Where People Go Wrong

> Most errors come from confusing a term with an everyday meaning or ignoring the limits of a rule.
A reader may use a familiar word without its management meaning, treat one example as universal, or describe a result without connecting it to the relevant process. The correction is to define the term, identify the evidence, apply the principle, and check the conditions that limit it.

## In History

> The historical case gives a dated setting in which the chapter's ideas can be examined.
The chapter's historical case concerns Frederick W. Taylor's work at Bethlehem Steel, Pennsylvania, 1898 to 1901, on handling pig iron and on shovelling, and the criticism it met; use only facts that sources agree on and date every figure. This account is used only to illuminate the management idea. It does not turn the historical event into a model for every organisation. The relevant lesson is the documented connection between the event and the management question raised in this chapter.
> The history is evidence for a management question, not a replacement for the general rule.
The case should also be read with its limits. Historical organisations operated under conditions that may differ from a modern organisation in law, technology, scale, and social expectations. A reader can therefore use the case to understand how an idea developed or appeared in practice while avoiding claims that the same arrangement must work today.
> Historical evidence needs its original setting before it is applied to a modern organisation.

## Sources

> The chapter keeps its source trail short and tied to the ideas it defines.
The named works and historical sources in the catalogue entry provide fuller context. The chapter uses brief attribution and avoids long quotations so that the main explanation remains readable.

## Review Questions

> The final questions return to the chapter's definitions and applications.
:q 03.1 | In your own words, what is the central management idea of this chapter?

:q 03.2 | Give one concrete example from a small organisation that illustrates the central idea.

:pause 03.p1 | What fact or condition should be checked before applying the chapter's main rule?

:read How Management Thought Developed background and the historical source named in the chapter entry
