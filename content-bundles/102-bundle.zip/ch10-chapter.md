:chapter X | People, Motivation and Creativity
:mood What becomes easier when the manager names the problem precisely?
:desc A first-year reader meets the chapter through a concrete management question. The ideas move from plain language to precise terms. The running case supplies recorded facts for application. The historical case provides a dated context.
:plate ch10-plate.svg | a potter's workshop with workers at wheels and a master inspecting a vase, 1870s

* * *
## Human Factors and Assumptions about People

> The section begins with the practical question behind human factors and assumptions about people.
Suppose a manager must deal with human factors and assumptions about people. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers human factors that affect management theory x and theory y as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Motivation  gives this paragraph its precise focus.
@ Motivation  |  the inner force that starts, directs and keeps up a person's effort towards a goal
At the centre of the discussion is **Motivation **.  the inner force that starts, directs and keeps up a person's effort towards a goal. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Need  gives this paragraph its precise focus.
@ Need  |  a lack of something that a person feels and wants to remove
At the centre of the discussion is **Need **.  a lack of something that a person feels and wants to remove. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Needs-goal model  gives this paragraph its precise focus.
@ Needs-goal model  |  a model in which an unmet need creates a drive, the drive leads to behaviour, and reaching the goal satisfies the need
At the centre of the discussion is **Needs-goal model **.  a model in which an unmet need creates a drive, the drive leads to behaviour, and reaching the goal satisfies the need. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Human Factors and Assumptions about People is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of human factors and assumptions about people in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Motivation

> The section begins with the practical question behind motivation.
Suppose a manager must deal with motivation. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers motivation and why managers must understand it the needs-goal model the hierarchy of needs as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Hierarchy of needs  gives this paragraph its precise focus.
@ Hierarchy of needs  |  Maslow's ordering of human needs in five levels, in which a lower level must be reasonably met before the next one matters
At the centre of the discussion is **Hierarchy of needs **.  Maslow's ordering of human needs in five levels, in which a lower level must be reasonably met before the next one matters. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Theory X  gives this paragraph its precise focus.
@ Theory X  |  an assumption that people dislike work, avoid responsibility and must be directed and controlled
At the centre of the discussion is **Theory X **.  an assumption that people dislike work, avoid responsibility and must be directed and controlled. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Theory Y  gives this paragraph its precise focus.
@ Theory Y  |  an assumption that people can enjoy work, accept responsibility and direct themselves towards aims they share
At the centre of the discussion is **Theory Y **.  an assumption that people can enjoy work, accept responsibility and direct themselves towards aims they share. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Motivation is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of motivation in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Informal Groups and Teams

> The section begins with the practical question behind informal groups and teams.
Suppose a manager must deal with informal groups and teams. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers informal groups and teams as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Informal group  gives this paragraph its precise focus.
@ Informal group  |  a set of employees who join by personal choice for companionship, help or shared interest, and not by assignment
At the centre of the discussion is **Informal group **.  a set of employees who join by personal choice for companionship, help or shared interest, and not by assignment. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Team  gives this paragraph its precise focus.
@ Team  |  a small group of people with joint responsibility and complementary skills who work towards one common result
At the centre of the discussion is **Team **.  a small group of people with joint responsibility and complementary skills who work towards one common result. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Creativity  gives this paragraph its precise focus.
@ Creativity  |  the ability to produce ideas that are new and useful
At the centre of the discussion is **Creativity **.  the ability to produce ideas that are new and useful. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Informal Groups and Teams is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of informal groups and teams in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Creativity and Innovation

> The section begins with the practical question behind creativity and innovation.
Suppose a manager must deal with creativity and innovation. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers creativity and innovation in an organisation as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Innovation  gives this paragraph its precise focus.
@ Innovation  |  the use of a new idea in a product, a service or a method
At the centre of the discussion is **Innovation **.  the use of a new idea in a product, a service or a method. Creativity and innovation in an organisation The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Creativity and Innovation is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of creativity and innovation in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
> Human Factors and Assumptions about People is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Motivation is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Informal Groups and Teams is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.



:fig the hierarchy of needs as a five-step staircase with an example of each step | ch10-fig01.svg
:fig the needs-goal model as a loop from need to behaviour, goal and satisfaction | ch10-fig02.svg

## Worked Case

> The worked case applies several chapter ideas to one documented set of facts.
:case Case file, illustrative. Case file, illustrative. Meghna and Sons, Dhanmondi, Dhaka; owner Harun Meghna; 13 employees and the owner; monthly pay Tk 22,000 for an assistant, Tk 32,000 for a section leader, Tk 55,000 for a manager. In 2025 two employees left: a school-books assistant who accepted Tk 25,000 a month elsewhere, and a section leader who gave no promotion path as the reason. Two practices recorded on 16 February 2026: a signing-in sheet every morning (Theory X) and permission for assistants to choose shelf layout inside their section (Theory Y). Needs record, 16 February 2026: pay and a monthly bonus (physical and safety needs); a written contract and a fixed holiday (safety); the lunch group and the Monday meeting (belonging); a monthly mention of the best section (esteem); a place on a training course (self-development). From 1 March 2026 each employee in a section that meets its monthly sales plan receives Tk 1,000. Informal group: five employees (two section leaders and three assistants) have eaten lunch together since 2024 and cover one another's shifts. Creativity: on 12 February 2026 an assistant proposed a Book of the Week shelf; trial from 2 March 2026; the featured titles sold 18 copies a week on average before and 31 after, an increase of 13 copies, 72%.

> The case is examined through situation, question, reasoning, conclusion and check.
Situation. Identify the recorded facts. Question. Select the relevant chapter concepts. Reasoning. Match each fact to the definitions and compare the conditions, alternatives, responsibilities or results that the record provides. Conclusion. State only what the facts support. Check. Identify any conclusion that would require information not contained in the case.

* * *
## Summary

> The chapter joins its definitions, examples and limits into one management framework.
The chapter began with people, motivation and creativity. It defined the assigned terms, applied them to the running case, and considered the conditions that limit their use. The main habit is to move from evidence to concept, from concept to comparison, and from comparison to a supported conclusion.

## Think It Through

> These questions ask for application rather than a memorised phrase.
:q 10.t1 | A small organisation records a situation that resembles this chapter's main problem. What should the manager identify first?

:q 10.t2 | A manager applies a familiar rule without checking its conditions. What should the manager revisit?

## Where People Go Wrong

> Most errors come from confusing a term with an everyday meaning or ignoring the limits of a rule.
A reader may use a familiar word without its management meaning, treat one example as universal, or describe a result without connecting it to the relevant process. The correction is to define the term, identify the evidence, apply the principle, and check the conditions that limit it.

## In History

> The historical case gives a dated setting in which the chapter's ideas can be examined.
The chapter's historical case concerns 3M under William L. McKnight: the 1948 rule that technical staff may spend part of their time on their own projects, and the Post-it note that grew from such work from 1974 to 1980. Use only dated facts that sources agree on. This account is used only to illuminate the management idea. It does not turn the historical event into a model for every organisation. The relevant lesson is the documented connection between the event and the management question raised in this chapter.
> The history is evidence for a management question, not a replacement for the general rule.
The case should also be read with its limits. Historical organisations operated under conditions that may differ from a modern organisation in law, technology, scale, and social expectations. A reader can therefore use the case to understand how an idea developed or appeared in practice while avoiding claims that the same arrangement must work today.
> Historical evidence needs its original setting before it is applied to a modern organisation.

## Sources

> The chapter keeps its source trail short and tied to the ideas it defines.
The named works and historical sources in the catalogue entry provide fuller context. The chapter uses brief attribution and avoids long quotations so that the main explanation remains readable.

## Review Questions

> The final questions return to the chapter's definitions and applications.
:q 10.1 | In your own words, what is the central management idea of this chapter?

:q 10.2 | Give one concrete example from a small organisation that illustrates the central idea.

:pause 10.p1 | What fact or condition should be checked before applying the chapter's main rule?

:read People, Motivation and Creativity background and the historical source named in the chapter entry
