:chapter XI | Leadership
:mood What becomes easier when the manager names the problem precisely?
:desc A first-year reader meets the chapter through a concrete management question. The ideas move from plain language to precise terms. The running case supplies recorded facts for application. The historical case provides a dated context.
:plate ch11-plate.svg | a ship's captain at the wheel on the bridge of a steamship, 1890s

* * *
## Leadership and Management Compared

> The section begins with the practical question behind leadership and management compared.
Suppose a manager must deal with leadership and management compared. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers leadership and how it differs from management as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Leadership  gives this paragraph its precise focus.
@ Leadership  |  the process of influencing people so that they work willingly towards a common aim
At the centre of the discussion is **Leadership **.  the process of influencing people so that they work willingly towards a common aim. Leadership and how it differs from management The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Leader  gives this paragraph its precise focus.
@ Leader  |  a person who influences others to follow, whether or not he or she holds a managerial position
At the centre of the discussion is **Leader **.  a person who influences others to follow, whether or not he or she holds a managerial position. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Power  gives this paragraph its precise focus.
@ Power  |  the ability to influence the behaviour of others, whether or not the right to do so is formally given
At the centre of the discussion is **Power **.  the ability to influence the behaviour of others, whether or not the right to do so is formally given. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Legitimate power  gives this paragraph its precise focus.
@ Legitimate power  |  power that comes from the position a person holds in the organisation
At the centre of the discussion is **Legitimate power **.  power that comes from the position a person holds in the organisation. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Leadership and Management Compared is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of leadership and management compared in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Power and Authority Bases

> The section begins with the practical question behind power and authority bases.
Suppose a manager must deal with power and authority bases. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers sources of power and how power differs from authority as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Reward power  gives this paragraph its precise focus.
@ Reward power  |  power that comes from the ability to give things that others value
At the centre of the discussion is **Reward power **.  power that comes from the ability to give things that others value. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Coercive power  gives this paragraph its precise focus.
@ Coercive power  |  power that comes from the ability to punish or to take away what others value
At the centre of the discussion is **Coercive power **.  power that comes from the ability to punish or to take away what others value. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Expert power  gives this paragraph its precise focus.
@ Expert power  |  power that comes from special knowledge or skill that others need
At the centre of the discussion is **Expert power **.  power that comes from special knowledge or skill that others need. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Referent power  gives this paragraph its precise focus.
@ Referent power  |  power that comes from the respect and liking that others feel for a person
At the centre of the discussion is **Referent power **.  power that comes from the respect and liking that others feel for a person. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Power and Authority Bases is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of power and authority bases in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Trait, Situational and Continuum Approaches

> The section begins with the practical question behind trait, situational and continuum approaches.
Suppose a manager must deal with trait, situational and continuum approaches. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers trait approach and situational approach styles of leadership the leadership continuum as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Trait approach  gives this paragraph its precise focus.
@ Trait approach  |  the view that effective leaders are marked by certain personal qualities
At the centre of the discussion is **Trait approach **.  the view that effective leaders are marked by certain personal qualities. Trait approach and situational approach The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Situational approach  gives this paragraph its precise focus.
@ Situational approach  |  the view that effective leadership depends on the situation, including the task, the people and the setting
At the centre of the discussion is **Situational approach **.  the view that effective leadership depends on the situation, including the task, the people and the setting. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Leadership style  gives this paragraph its precise focus.
@ Leadership style  |  the usual pattern of behaviour that a leader shows when influencing others
At the centre of the discussion is **Leadership style **.  the usual pattern of behaviour that a leader shows when influencing others. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Leadership continuum  gives this paragraph its precise focus.
@ Leadership continuum  |  a range of leader behaviour from full manager control to full control by the group, within limits
At the centre of the discussion is **Leadership continuum **.  a range of leader behaviour from full manager control to full control by the group, within limits. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Trait, Situational and Continuum Approaches is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of trait, situational and continuum approaches in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *
## Styles and Modern Leadership

> The section begins with the practical question behind styles and modern leadership.
Suppose a manager must deal with styles and modern leadership. The first task is to identify the facts that describe the situation. The next task is to connect those facts with the management idea being taught. The final task is to consider the conditions under which the idea may not give a complete answer. This order gives a beginner a stable way to read the subject.

> The section covers emotional intelligence of a leader transformational leadership coaching and super leadership as connected parts of one management question.
The catalogue groups these ideas together because they answer related questions. A reader can therefore ask what the idea is, why it exists, how it works in a real organisation, and where it may fail. The running case supplies the concrete setting; the general explanation supplies the rule. Neither should be read without the other.

> Emotional intelligence  gives this paragraph its precise focus.
@ Emotional intelligence  |  the ability to notice and manage one's own feelings and those of others and to use that awareness in dealing with people
At the centre of the discussion is **Emotional intelligence **.  the ability to notice and manage one's own feelings and those of others and to use that awareness in dealing with people. Emotional intelligence of a leader The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Transformational leadership  gives this paragraph its precise focus.
@ Transformational leadership  |  leadership that inspires followers to look beyond their own interest and to work for a shared vision
At the centre of the discussion is **Transformational leadership **.  leadership that inspires followers to look beyond their own interest and to work for a shared vision. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Coaching  gives this paragraph its precise focus.
@ Coaching  |  helping a person to improve skills through guidance, practice and feedback
At the centre of the discussion is **Coaching **.  helping a person to improve skills through guidance, practice and feedback. Coaching and super leadership The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Super leadership  gives this paragraph its precise focus.
@ Super leadership  |  leadership that helps others to lead themselves
At the centre of the discussion is **Super leadership **.  leadership that helps others to lead themselves. The idea gives the manager a precise vocabulary for the situation. The reader should first identify the recorded fact, then ask why the term fits it, and finally check what the term does not establish. For Meghna and Sons, the documented case provides the setting.
> The definition connects the term to a concrete management fact.
The practical use follows from the definition. A manager should not treat a familiar word as sufficient evidence. The manager identifies the relevant record, compares it with the meaning of the term, and then asks what further information is needed. This keeps the management concept tied to observable work.
> The term is useful when its meaning is tested against evidence and its limits are recognised.

> Styles and Modern Leadership is easier to understand when the reader moves from the concrete case to the general rule.
The practical question is what a manager would notice first. The answer begins with the information already available: people, resources, records, timing, results, or the stated arrangement. The manager then separates the relevant fact from assumptions that have not been established. This is important because a management idea is useful only when it can guide attention to a real feature of work.

> Before moving on, the reader should be able to state the main point of styles and modern leadership in plain words.
*Before moving on.* The section has moved from a practical question to a precise rule, then to an application and a limit. The definition should remain connected to the evidence.

* * *


:fig the leadership continuum from a manager who decides alone to a group that decides within limits | ch11-fig01.svg
:fig five bases of power drawn as five roots of one tree, each with an example | ch11-fig02.svg

## Worked Case

> The worked case applies several chapter ideas to one documented set of facts.
:case Case file, illustrative. Case file, illustrative. Meghna and Sons, Dhanmondi, Dhaka; owner Harun Meghna; 13 employees and the owner (later 17). Continuum record: until 2025 the owner decided the opening hours and told the staff. On 5 February 2026 he put the question of closing at 20:00 or 21:00 to all 13 employees; 9 of 13 chose 21:00; the owner kept 21:00 for a trial of three months and set the review for 5 May 2026. Power record: legitimate, the owner's position; reward, the monthly Tk 1,000 section bonus; coercive, one written warning issued in 2025; expert, Imran Meghna's knowledge of publishers and supply; referent, Nasrin Akter, whom shop assistants consult first. Emotional intelligence record: on 24 February 2026 a customer complained about a wrong textbook edition; Nasrin Akter exchanged the book the same day and recorded the cause; no repeat in the next 30 days. Transformational leadership: on 2 March 2026 the owner issued a written aim to all employees: any book in Dhaka within 24 hours. Coaching: from 10 March 2026 Nasrin Akter held one hour a week with each of the 2 newest assistants. Super leadership: from 1 March 2026 the school-books section leader sets the weekly plan of her section without approval.

> The case is examined through situation, question, reasoning, conclusion and check.
Situation. Identify the recorded facts. Question. Select the relevant chapter concepts. Reasoning. Match each fact to the definitions and compare the conditions, alternatives, responsibilities or results that the record provides. Conclusion. State only what the facts support. Check. Identify any conclusion that would require information not contained in the case.

* * *
## Summary

> The chapter joins its definitions, examples and limits into one management framework.
The chapter began with leadership. It defined the assigned terms, applied them to the running case, and considered the conditions that limit their use. The main habit is to move from evidence to concept, from concept to comparison, and from comparison to a supported conclusion.

## Think It Through

> These questions ask for application rather than a memorised phrase.
:q 11.t1 | A small organisation records a situation that resembles this chapter's main problem. What should the manager identify first?

:q 11.t2 | A manager applies a familiar rule without checking its conditions. What should the manager revisit?

## Where People Go Wrong

> Most errors come from confusing a term with an everyday meaning or ignoring the limits of a rule.
A reader may use a familiar word without its management meaning, treat one example as universal, or describe a result without connecting it to the relevant process. The correction is to define the term, identify the evidence, apply the principle, and check the conditions that limit it.

## In History

> The historical case gives a dated setting in which the chapter's ideas can be examined.
The chapter's historical case concerns Ernest Shackleton and the Imperial Trans-Antarctic Expedition, 1914 to 1917: the loss of the Endurance and the return of all members of the party. Use only dated facts that sources agree on. This account is used only to illuminate the management idea. It does not turn the historical event into a model for every organisation. The relevant lesson is the documented connection between the event and the management question raised in this chapter.
> The history is evidence for a management question, not a replacement for the general rule.
The case should also be read with its limits. Historical organisations operated under conditions that may differ from a modern organisation in law, technology, scale, and social expectations. A reader can therefore use the case to understand how an idea developed or appeared in practice while avoiding claims that the same arrangement must work today.
> Historical evidence needs its original setting before it is applied to a modern organisation.

## Sources

> The chapter keeps its source trail short and tied to the ideas it defines.
The named works and historical sources in the catalogue entry provide fuller context. The chapter uses brief attribution and avoids long quotations so that the main explanation remains readable.

## Review Questions

> The final questions return to the chapter's definitions and applications.
:q 11.1 | In your own words, what is the central management idea of this chapter?

:q 11.2 | Give one concrete example from a small organisation that illustrates the central idea.

:pause 11.p1 | What fact or condition should be checked before applying the chapter's main rule?

:read Leadership background and the historical source named in the chapter entry
