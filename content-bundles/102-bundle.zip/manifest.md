:bundle
status: ok
failures: 0
chapters: 12
appendix: a1
changed-duplicates-resolved: 0
glossary-duplicates-removed: 0
chapter | ch01 | I | What Management Is | 3041 | 1 | 7 | 5
chapter | ch02 | II | Managers: Levels, Skills and Standing | 2986 | 2 | 12 | 5
chapter | ch03 | III | How Management Thought Developed | 2980 | 1 | 12 | 5
chapter | ch04 | IV | Environment, Ethics and Social Responsibility | 3036 | 2 | 12 | 5
chapter | ch05 | V | Planning | 2949 | 2 | 10 | 5
chapter | ch06 | VI | Objectives and Management by Objectives | 2768 | 2 | 6 | 5
chapter | ch07 | VII | Decision Making | 3146 | 2 | 15 | 5
chapter | ch08 | VIII | Organising: Process and Structure | 3027 | 2 | 11 | 5
chapter | ch09 | IX | Span, Departments, Authority and Coordination | 3183 | 2 | 14 | 5
chapter | ch10 | X | People, Motivation and Creativity | 2759 | 2 | 10 | 5
chapter | ch11 | XI | Leadership | 3228 | 2 | 16 | 5
chapter | ch12 | XII | Controlling | 2753 | 2 | 8 | 5
chapter | a1 | A1 | Maths You Will Use | 706 | 1 | 6 | 0
